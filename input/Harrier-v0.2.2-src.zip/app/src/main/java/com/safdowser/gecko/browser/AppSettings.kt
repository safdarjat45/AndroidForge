package com.safdowser.gecko.browser

import android.content.Context

/** Search engines the user can pick in Settings. */
enum class SearchEngine(val label: String, val template: String, val home: String) {
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q=", "https://duckduckgo.com"),
    GOOGLE("Google", "https://www.google.com/search?q=", "https://www.google.com"),
    BING("Bing", "https://www.bing.com/search?q=", "https://www.bing.com")
}

/**
 * Small persisted settings (SharedPreferences). The search engine is also
 * mirrored into a volatile field so BrowserTab.normalizeInput can read it
 * without a Context; GeckoApp/MainActivity call [load] at startup.
 */
object AppSettings {
    private const val PREFS = "harrier_settings"
    private const val KEY_SCREENSHOT = "screenshot_protection"
    private const val KEY_SEARCH = "search_engine"

    @Volatile
    var searchEngine: SearchEngine = SearchEngine.DUCKDUCKGO
        private set

    fun load(context: Context) {
        val name = prefs(context).getString(KEY_SEARCH, SearchEngine.DUCKDUCKGO.name)
        searchEngine = runCatching { SearchEngine.valueOf(name!!) }
            .getOrDefault(SearchEngine.DUCKDUCKGO)
    }

    fun screenshotProtection(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SCREENSHOT, true)

    fun setScreenshotProtection(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_SCREENSHOT, enabled).apply()
    }

    fun setSearchEngine(context: Context, engine: SearchEngine) {
        searchEngine = engine
        prefs(context).edit().putString(KEY_SEARCH, engine.name).apply()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
