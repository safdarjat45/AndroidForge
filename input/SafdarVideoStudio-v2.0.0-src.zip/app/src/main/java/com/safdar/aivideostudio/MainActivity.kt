package com.safdar.aivideostudio

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.tabs.TabLayout
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var tabLayout: TabLayout
    private lateinit var webStudio: WebView
    private lateinit var webColab: WebView
    private lateinit var webApiKey: WebView
    private lateinit var webFlow: WebView
    private lateinit var studioWaitingOverlay: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var tvBridgeStatus: TextView
    private lateinit var etManualColabUrl: EditText

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var activeTabIndex = 0

    private var capturedColabUrl: String = ""
    private var capturedApiKey: String = ""

    private lateinit var studioRootDir: File
    private lateinit var framesDir: File
    private lateinit var clipsDir: File
    private lateinit var outputDir: File

    private val DEFAULT_COLAB_URL = "https://colab.research.google.com/"
    private val AI_STUDIO_KEY_URL = "https://aistudio.google.com/app/apikey"
    private val GOOGLE_FLOW_URL = "https://labs.google/fx/tools/flow"

    private val handler = Handler(Looper.getMainLooper())

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val serviceIntent = Intent(this, KeepAliveService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        setupDedicatedFolders()

        tabLayout = findViewById(R.id.tabLayout)
        webStudio = findViewById(R.id.webStudio)
        webColab = findViewById(R.id.webColab)
        webApiKey = findViewById(R.id.webApiKey)
        webFlow = findViewById(R.id.webFlow)
        studioWaitingOverlay = findViewById(R.id.studioWaitingOverlay)
        progressBar = findViewById(R.id.progressBar)
        tvBridgeStatus = findViewById(R.id.tvBridgeStatus)
        etManualColabUrl = findViewById(R.id.etManualColabUrl)

        val btnRefresh: ImageButton = findViewById(R.id.btnRefresh)
        val btnGoColab: Button = findViewById(R.id.btnGoColab)
        val btnManualConnect: Button = findViewById(R.id.btnManualConnect)

        val prefs = getSharedPreferences("StudioV2Prefs", Context.MODE_PRIVATE)
        capturedColabUrl = prefs.getString("colab_url", "") ?: ""
        capturedApiKey = prefs.getString("gemini_api_key", "") ?: ""

        assignIsolatedProfile(webStudio, "Profile_Studio")
        assignIsolatedProfile(webColab, "Profile_Colab")
        assignIsolatedProfile(webApiKey, "Profile_ApiKey")
        assignIsolatedProfile(webFlow, "Profile_Flow_Pro")

        configureWebView(webStudio, "STUDIO")
        configureWebView(webColab, "COLAB")
        configureWebView(webApiKey, "APIKEY")
        configureWebView(webFlow, "FLOW")

        webColab.loadUrl(DEFAULT_COLAB_URL)
        webApiKey.loadUrl(AI_STUDIO_KEY_URL)
        webFlow.loadUrl(GOOGLE_FLOW_URL)

        if (capturedColabUrl.isNotEmpty()) {
            openStudioDashboard(capturedColabUrl)
        }
        updateBridgeStatusBadge()

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                switchTab(tab.position)
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        btnRefresh.setOnClickListener {
            when (activeTabIndex) {
                0 -> webStudio.reload()
                1 -> webColab.reload()
                2 -> webApiKey.reload()
                3 -> webFlow.reload()
            }
            Toast.makeText(this, "Refreshing active tab...", Toast.LENGTH_SHORT).show()
        }

        btnGoColab.setOnClickListener {
            tabLayout.getTabAt(1)?.select()
        }

        btnManualConnect.setOnClickListener {
            val url = etManualColabUrl.text.toString().trim()
            if (url.startsWith("http")) {
                onColabTunnelCaptured(url)
            } else {
                Toast.makeText(this, "Valid https:// URL darj karein", Toast.LENGTH_SHORT).show()
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val activeWeb = when (activeTabIndex) {
                    0 -> webStudio
                    1 -> webColab
                    2 -> webApiKey
                    else -> webFlow
                }
                if (activeWeb.canGoBack()) {
                    activeWeb.goBack()
                } else if (activeTabIndex != 0) {
                    tabLayout.getTabAt(0)?.select()
                } else {
                    moveTaskToBack(true)
                }
            }
        })
    }

    private fun setupDedicatedFolders() {
        val baseDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        studioRootDir = File(baseDownloads, "AIVideoStudio")
        framesDir = File(studioRootDir, "1_Generated_Frames")
        clipsDir = File(studioRootDir, "2_Veo_Clips")
        outputDir = File(studioRootDir, "3_Final_Videos")
        framesDir.mkdirs()
        clipsDir.mkdirs()
        outputDir.mkdirs()
    }

    private fun assignIsolatedProfile(webView: WebView, profileName: String) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            WebViewCompat.setProfile(webView, profileName)
        }
    }

    private fun switchTab(index: Int) {
        activeTabIndex = index
        webStudio.visibility = if (index == 0) View.VISIBLE else View.GONE
        webColab.visibility = if (index == 1) View.VISIBLE else View.GONE
        webApiKey.visibility = if (index == 2) View.VISIBLE else View.GONE
        webFlow.visibility = if (index == 3) View.VISIBLE else View.GONE

        if (index == 0) {
            studioWaitingOverlay.visibility = if (capturedColabUrl.isEmpty()) View.VISIBLE else View.GONE
            if (capturedApiKey.isNotEmpty()) {
                injectApiKeyIntoStudio(capturedApiKey)
            }
        } else {
            studioWaitingOverlay.visibility = View.GONE
        }
    }

    private fun updateBridgeStatusBadge() {
        val cStatus = if (capturedColabUrl.isNotEmpty()) "Colab: OK" else "Colab: Wait"
        val kStatus = if (capturedApiKey.isNotEmpty()) "Key: OK" else "Key: Wait"
        tvBridgeStatus.text = "$cStatus | $kStatus"
    }

    private fun onColabTunnelCaptured(url: String) {
        if (url == capturedColabUrl && studioWaitingOverlay.visibility == View.GONE) return
        capturedColabUrl = url
        getSharedPreferences("StudioV2Prefs", Context.MODE_PRIVATE)
            .edit().putString("colab_url", url).apply()
        updateBridgeStatusBadge()
        Toast.makeText(this, "Colab Tunnel Auto-Connected!", Toast.LENGTH_SHORT).show()
        openStudioDashboard(url)
        tabLayout.getTabAt(0)?.select()
    }

    private fun onGeminiKeyCaptured(key: String) {
        if (!key.startsWith("AIza") || key == capturedApiKey) return
        capturedApiKey = key
        getSharedPreferences("StudioV2Prefs", Context.MODE_PRIVATE)
            .edit().putString("gemini_api_key", key).apply()
        updateBridgeStatusBadge()
        Toast.makeText(this, "Gemini API Key Auto-Captured!", Toast.LENGTH_SHORT).show()
        injectApiKeyIntoStudio(key)
    }

    private fun openStudioDashboard(url: String) {
        studioWaitingOverlay.visibility = View.GONE
        val finalUrl = if (capturedApiKey.isNotEmpty()) {
            "$url/?auto_key=$capturedApiKey"
        } else {
            url
        }
        webStudio.loadUrl(finalUrl)
    }

    private fun injectApiKeyIntoStudio(key: String) {
        val js = "(function(){const inputs=document.querySelectorAll('input[type=\"password\"],input[type=\"text\"]');for(let inp of inputs){if((inp.placeholder&&inp.placeholder.toLowerCase().includes('gemini'))||(inp.getAttribute('aria-label')&&inp.getAttribute('aria-label').toLowerCase().includes('gemini'))){const ns=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;ns.call(inp,'$key');inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));}}})();"
        webStudio.evaluateJavascript(js, null)
    }

    inner class AndroidAutomationBridge {
        @JavascriptInterface
        fun reportColabUrl(url: String) {
            handler.post { onColabTunnelCaptured(url.trim()) }
        }

        @JavascriptInterface
        fun reportApiKey(key: String) {
            handler.post { onGeminiKeyCaptured(key.trim()) }
        }

        @JavascriptInterface
        fun saveFrameBase64(sceneId: Int, base64Data: String) {
            try {
                val cleanBase64 = base64Data.substringAfter(",")
                val bytes = Base64.decode(cleanBase64, Base64.DEFAULT)
                val outFile = File(framesDir, "scene_${sceneId}.png")
                FileOutputStream(outFile).use { it.write(bytes) }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        @JavascriptInterface
        fun triggerAutoFlowForScene(sceneId: Int, motionPrompt: String) {
            handler.post {
                val frameFile = File(framesDir, "scene_${sceneId}.png")
                if (!frameFile.exists()) {
                    Toast.makeText(this@MainActivity, "Scene $sceneId frame missing in ${framesDir.name}", Toast.LENGTH_SHORT).show()
                    return@post
                }
                Toast.makeText(this@MainActivity, "Auto-Flow starting for Scene $sceneId...", Toast.LENGTH_SHORT).show()
                tabLayout.getTabAt(3)?.select()
                injectFlowAutomation(sceneId, frameFile, motionPrompt)
            }
        }
    }

    private fun injectFlowAutomation(sceneId: Int, frameFile: File, motionPrompt: String) {
        val bytes = frameFile.readBytes()
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val escapedPrompt = motionPrompt.replace("'", "\\'").replace("\n", " ")

        val jsFlow = "(async function(){function b2f(b,fn){const bc=atob(b);const bn=new Array(bc.length);for(let i=0;i<bc.length;i++)bn[i]=bc.charCodeAt(i);return new File([new Blob([new Uint8Array(bn)],{type:'image/png'})],fn,{type:'image/png'});}const btns=Array.from(document.querySelectorAll('button,a'));const np=btns.find(b=>b.innerText&&b.innerText.toLowerCase().includes('new project'));if(np){np.click();await new Promise(r=>setTimeout(r,2500));}const fi=document.querySelector('input[type=\"file\"]');if(fi){const dt=new DataTransfer();dt.items.add(b2f('$b64','scene_${sceneId}.png'));fi.files=dt.files;fi.dispatchEvent(new Event('change',{bubbles:true}));await new Promise(r=>setTimeout(r,3000));}const pb=document.querySelector('textarea,div[contenteditable=\"true\"]');if(pb){pb.focus();if(pb.tagName==='TEXTAREA'){const s=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;s.call(pb,'$escapedPrompt');pb.dispatchEvent(new Event('input',{bubbles:true}));}else{pb.innerText='$escapedPrompt';pb.dispatchEvent(new Event('input',{bubbles:true}));}await new Promise(r=>setTimeout(r,1000));}const gb=Array.from(document.querySelectorAll('button')).reverse().find(b=>(b.innerText&&b.innerText.toLowerCase().includes('generate'))||(b.getAttribute('aria-label')&&b.getAttribute('aria-label').toLowerCase().includes('generate')));if(gb)gb.click();})();"

        handler.postDelayed({
            webFlow.evaluateJavascript(jsFlow, null)
        }, 1500)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView, tag: String) {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.allowFileAccess = true
        s.allowContentAccess = true
        s.mediaPlaybackRequiresUserGesture = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.userAgentString = s.userAgentString.replace("; wv", "")

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.addJavascriptInterface(AndroidAutomationBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = View.GONE
                if (url == null) return
                when (tag) {
                    "COLAB" -> injectColabWatcher(webView)
                    "APIKEY" -> injectApiKeyWatcher(webView)
                    "STUDIO" -> if (capturedApiKey.isNotEmpty()) injectApiKeyIntoStudio(capturedApiKey)
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress < 100) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = newProgress
                } else {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                fileChooserLauncher.launch(intent)
                return true
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val targetSubFolder = when {
                    tag == "FLOW" -> "AIVideoStudio/2_Veo_Clips"
                    fileName.endsWith(".png") || fileName.endsWith(".jpg") -> "AIVideoStudio/1_Generated_Frames"
                    else -> "AIVideoStudio/3_Final_Videos"
                }
                val request = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mimeType)
                    addRequestHeader("User-Agent", userAgent)
                    setTitle(fileName)
                    setDescription("Saving to $targetSubFolder")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "$targetSubFolder/$fileName")
                }
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                Toast.makeText(this, "Saved to Downloads/$targetSubFolder/$fileName", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun injectColabWatcher(webView: WebView) {
        val js = "(function(){if(window.__cw)return;window.__cw=true;let rc=false;setInterval(()=>{if(!rc&&!location.href.includes('accounts.google.com')){const els=Array.from(document.querySelectorAll('button,[role=\"menuitem\"],[role=\"button\"]'));const t=els.find(e=>e.innerText&&e.innerText.trim()==='Run all');if(t){t.click();rc=true;}}const txt=document.body?document.body.innerText:'';const m=txt.match(/https:\\/\\/[a-zA-Z0-9-]+\\.trycloudflare\\.com/);if(m&&m[0])AndroidBridge.reportColabUrl(m[0]);},3000);})();"
        webView.evaluateJavascript(js, null)
    }

    private fun injectApiKeyWatcher(webView: WebView) {
        val js = "(function(){if(window.__aw)return;window.__aw=true;let cc=false;setInterval(()=>{if(location.href.includes('accounts.google.com'))return;const txt=document.body?document.body.innerText:'';const km=txt.match(/AIza[0-9A-Za-z\\-_]{35}/);if(km&&km[0]){AndroidBridge.reportApiKey(km[0]);return;}if(!cc){const btns=Array.from(document.querySelectorAll('button'));const cb=btns.find(b=>b.innerText&&b.innerText.toLowerCase().includes('create api key'));if(cb){cb.click();cc=true;}}},3000);})();"
        webView.evaluateJavascript(js, null)
    }
}
