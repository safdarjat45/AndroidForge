package com.safdowser.gecko.browser

/**
 * Built-in start page, loaded as inline data through GeckoSession.Loader
 * (no network needed, no data:-URI encoding pitfalls).
 *
 * Links go to AMO (Firefox add-ons) and to the two verified working
 * substitutes. Urban VPN / Green VPN are named here honestly: they do not
 * exist for Firefox on Android, so the page points at Browsec instead.
 */
object StartPage {

    val HTML: String = """
        <!doctype html>
        <html><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Foxfire</title>
        <style>
        body { background:#0B1120; color:#F1F5F9; font-family:sans-serif; margin:0; padding:28px 20px; }
        h1 { font-size:24px; margin:0 0 6px 0; }
        p { color:#94A3B8; line-height:1.5; }
        a { color:#38BDF8; }
        .card { background:#111827; border:1px solid #1E293B; border-radius:12px; padding:16px; margin:14px 0; }
        .card h2 { font-size:16px; margin:0 0 8px 0; }
        .card p { margin:6px 0; }
        .warn { color:#FBBF24; }
        </style></head>
        <body>
        <h1>Foxfire</h1>
        <p>Firefox engine + real Firefox add-ons. Type an address above, or pick an add-on below.</p>
        <div class="card">
        <h2>Recommended add-ons (Firefox for Android)</h2>
        <p><a href="https://addons.mozilla.org/en-US/firefox/addon/ublock-origin/">uBlock Origin</a> - ad and tracker blocker, Recommended for Android.</p>
        <p><a href="https://addons.mozilla.org/en-US/firefox/addon/browsec/">Browsec VPN</a> - free VPN add-on for Firefox Android (proxy-based).</p>
        <p><a href="https://addons.mozilla.org/en-US/android/">Browse all Android add-ons on AMO</a></p>
        </div>
        <div class="card">
        <h2>Please note</h2>
        <p class="warn">Urban VPN and Green VPN cannot be installed on Firefox for Android by anyone. Urban VPN is not listed on AMO for Android, and Green VPN has no Firefox add-on at all (Chrome only). Browsec above is the working free-VPN substitute.</p>
        <p>v0.1 does not spoof timezone or GPS the way Safdowser does - GeckoView has no supported API for either. Sites that ask for your location are denied.</p>
        </div>
        </body></html>
    """.trimIndent()
}
