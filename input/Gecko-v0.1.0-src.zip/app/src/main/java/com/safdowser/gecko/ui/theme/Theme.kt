package com.safdowser.gecko.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GeckoColors = darkColorScheme(
    primary = Color(0xFF38BDF8),
    onPrimary = Color(0xFF06202E),
    secondary = Color(0xFF34D399),
    tertiary = Color(0xFFA78BFA),
    background = Color(0xFF0B1120),
    surface = Color(0xFF111827),
    surfaceVariant = Color(0xFF1E293B),
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9)
)

@Composable
fun GeckoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GeckoColors,
        content = content
    )
}
