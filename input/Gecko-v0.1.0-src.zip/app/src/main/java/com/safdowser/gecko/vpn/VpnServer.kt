package com.safdowser.gecko.vpn

data class VpnServer(
    val id: String,
    val countryName: String,
    val countryCode: String,
    val city: String,
    val ipAddress: String,
    val port: Int,
    val protocol: String, // "SOCKS5", "HTTP", "OPENVPN"
    val pingMs: Int = 45,
    val isFreeCommunity: Boolean = true,
    /** Raw .ovpn configuration text (decoded from the VPN Gate directory), used to open a real tunnel. */
    val ovpnConfig: String = "",
    /** VPN Gate's public standard login for its volunteer servers (username "vpn"). */
    val username: String = "",
    val password: String = "",
    /** VPN Gate quality score (higher = more reliable/faster). */
    val score: Int = 0,
    /** Cumulative uptime reported by the directory, in milliseconds. */
    val uptimeMs: Long = 0
)
