package com.safdowser.gecko.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.safdowser.gecko.browser.BrowserTab
import com.safdowser.gecko.vpn.OpenVpnController
import java.util.Locale
import java.util.TimeZone

/**
 * Identity page: shows what websites see right now — exit IP, user agent,
 * locale, timezone, WebRTC and DNS posture. Honest about v0.1 limits:
 * timezone and GPS are NOT spoofed (no supported GeckoView API), so the
 * page shows the real device timezone and says so.
 */
@Composable
fun IdentityScreen(
    tab: BrowserTab?,
    onBack: () -> Unit
) {
    var exitIp by remember { mutableStateOf<String?>(null) }
    var userAgent by remember { mutableStateOf<String?>(null) }
    val vpnState by OpenVpnController.state.collectAsState()

    LaunchedEffect(Unit) {
        exitIp = OpenVpnController.fetchExitIp()
    }

    LaunchedEffect(tab?.id) {
        userAgent = null
        tab?.session?.getUserAgent().accept(
            { ua -> userAgent = ua },
            { userAgent = "User agent nahi mila" }
        )
    }

    val rows = listOf(
        "Exit IP (websites ye dekhte hain)" to (exitIp ?: "check ho raha hai…"),
        "VPN tunnel" to vpnState.name,
        "User agent" to (userAgent ?: "check ho raha hai…"),
        "Locale (Accept-Language)" to Locale.getDefault().toLanguageTag(),
        "Timezone (JavaScript)" to (TimeZone.getDefault().id + " — REAL device timezone, v0.1 mein spoof nahi hota"),
        "GPS / location" to "No fake GPS in v0.1 — location requests deny hoti hain, real location kisi site ko nahi milti",
        "WebRTC" to "Engine default ON — iska koi typed off switch GeckoView mein nahi. VPN on ho to WebRTC traffic bhi per-app TUN ke andar rehta hai.",
        "DNS (DoH)" to "OFF by choice — OS resolver use hota hai, jo VPN tunnel ke andar hai",
        "Fingerprinting protection (FPP)" to "ON — known fingerprinting scripts block hoti hain (ye resistFingerprinting nahi hai)",
        "Tracking protection" to "STRICT — trackers, cryptominers, fingerprinting categories block"
    )

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Identity", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            items(rows) { (label, value) ->
                Column(modifier = Modifier.padding(vertical = 8.dp)) {
                    Text(label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text(value, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
