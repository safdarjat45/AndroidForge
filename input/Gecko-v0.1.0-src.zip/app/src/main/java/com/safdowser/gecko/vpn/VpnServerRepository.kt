package com.safdowser.gecko.vpn

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class VpnServerRepository {

    /**
     * Fetches live free public volunteer relay nodes from the academic VPN Gate directory.
     *
     * The directory CSV has 15 columns; the last column holds the server's OpenVPN
     * configuration as Base64. The "Message" column may itself contain commas, so the
     * configuration is always read from the LAST column of each row.
     */
    suspend fun fetchLiveFreeVpnGateServers(): List<VpnServer> = withContext(Dispatchers.IO) {
        val results = mutableListOf<VpnServer>()
        runCatching {
            val conn = (URL("https://www.vpngate.net/api/iphone/").openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 15000
                requestMethod = "GET"
            }
            conn.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    if (line.isBlank() || line.startsWith("*") || line.startsWith("#")) return@forEach
                    val cols = line.split(",")
                    if (cols.size >= 8) {
                        val ip = cols[1].trim()
                        val score = cols.getOrNull(2)?.trim()?.toIntOrNull() ?: 0
                        val ping = cols[3].trim().toIntOrNull() ?: 999
                        val country = cols[5].trim()
                        val code = cols[6].trim().uppercase()
                        val uptime = cols.getOrNull(8)?.trim()?.toLongOrNull() ?: 0L
                        val configB64 = cols.last().trim()
                        val config = runCatching {
                            String(Base64.decode(configB64, Base64.DEFAULT), Charsets.UTF_8)
                        }.getOrDefault("")
                        if (ip.isNotEmpty() && code.length == 2 && config.contains("remote")) {
                            results.add(
                                VpnServer(
                                    id = "vpngate-$code-$ip",
                                    countryName = country,
                                    countryCode = code,
                                    city = "VPN Gate Relay",
                                    ipAddress = ip,
                                    port = 443,
                                    protocol = "OPENVPN",
                                    pingMs = ping,
                                    isFreeCommunity = true,
                                    ovpnConfig = config,
                                    // VPN Gate's volunteer servers only accept their
                                    // public standard login — without it every
                                    // connection is rejected at auth.
                                    username = "vpn",
                                    password = "vpn",
                                    score = score,
                                    uptimeMs = uptime
                                )
                            )
                        }
                    }
                }
            }
        }
        // Best first: VPN Gate's own quality score, then lowest ping.
        results.sortedWith(compareByDescending<VpnServer> { it.score }.thenBy { it.pingMs })
    }
}

/**
 * Makes a VPN Gate .ovpn configuration acceptable to the OpenVPN 3 core:
 * drops legacy options the core rejects (LZO compression, persist helpers).
 * NOTE: `auth-user-pass` must STAY — the core needs it to know the server
 * expects the username/password we provide via provide_creds().
 */
fun sanitizeOvpnConfig(raw: String): String {
    val dropPrefixes = listOf("comp-lzo", "persist-key", "persist-tun")
    return raw.lines()
        .filter { line ->
            val t = line.trim()
            dropPrefixes.none { t.startsWith(it) }
        }
        .joinToString("\n")
}
