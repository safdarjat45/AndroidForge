package com.safdowser.gecko.vpn

import com.tim.openvpn.OpenVPNThreadv3
import com.tim.openvpn.service.IOpenVPNService
import net.openvpn.ovpn3.ClientAPI_Event
import net.openvpn.ovpn3.ClientAPI_LogInfo

/**
 * OpenVPNThreadv3 that also reports every core event and log line to a listener,
 * so the app can SHOW why a connection failed instead of failing silently.
 * (The stock thread only writes to logcat, which the user can never see.)
 */
class LoggingOpenVPNThreadv3(
    service: IOpenVPNService,
    config: String,
    private val onEvent: (name: String, info: String, isError: Boolean) -> Unit,
    private val onLog: (text: String) -> Unit
) : OpenVPNThreadv3(service, config) {

    override fun event(event: ClientAPI_Event) {
        runCatching {
            onEvent(event.name ?: "", event.info ?: "", event.error)
        }
        super.event(event)
    }

    override fun log(logInfo: ClientAPI_LogInfo) {
        runCatching {
            onLog(logInfo.text ?: "")
        }
        super.log(logInfo)
    }
}
