package com.safdowser.gecko.browser

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import java.net.HttpURLConnection
import java.net.URL

/**
 * Firefox add-ons (WebExtensions) from addons.mozilla.org (AMO).
 *
 * Install flow: AMO API v5 → Android XPI download URL → WebExtensionController
 * .install(xpiUrl, INSTALLATION_METHOD_MANAGER). Only Mozilla-signed AMO
 * add-ons can install — unsigned XPIs from the open web are rejected by the
 * engine, and there is no supported sideload path. Chrome Web Store
 * extensions can never run here (different engine, different format).
 *
 * The two pre-seeded shortcuts are the only add-ons verified Android-
 * compatible on AMO (checked 2026-11-20): Browsec VPN and uBlock Origin.
 * Urban VPN is not listed on AMO for Android and Green VPN has no Firefox
 * add-on at all — the UI says so plainly instead of offering them.
 */
data class PreseededAddon(
    val slug: String,
    val name: String,
    val blurb: String
)

val PRESEEDED_ADDONS = listOf(
    PreseededAddon(
        slug = "browsec",
        name = "Browsec VPN",
        blurb = "Free VPN add-on for Firefox Android (proxy-based). The working substitute for Urban/Green VPN."
    ),
    PreseededAddon(
        slug = "ublock-origin",
        name = "uBlock Origin",
        blurb = "Efficient ad + tracker blocker. Recommended for Android."
    )
)

data class InstallPromptData(
    val extension: WebExtension,
    val permissions: List<String>,
    val origins: List<String>,
    val result: GeckoResult<WebExtension.PermissionPromptResponse>
)

data class PopupRequest(
    val extension: WebExtension,
    val session: GeckoSession
)

class AddonsManager(
    private val runtime: GeckoRuntime,
    /** Opens a URL in a new browser tab and returns its session. */
    private val openTab: (String?) -> GeckoSession
) {
    private val controller: WebExtensionController = runtime.webExtensionController

    val installed = mutableStateListOf<WebExtension>()

    /** extension id -> latest browser/page action (title, badge) */
    val browserActions = mutableStateMapOf<String, WebExtension.Action>()

    var status by mutableStateOf<String?>(null)
        private set

    var installing by mutableStateOf(false)
        private set

    /** Non-null while an install-permission dialog must be shown. */
    var pendingPrompt by mutableStateOf<InstallPromptData?>(null)
        private set

    /** Non-null while an extension popup must be shown in a dialog. */
    var popupRequest by mutableStateOf<PopupRequest?>(null)
        private set

    private val ioScope = CoroutineScope(Dispatchers.IO)

    init {
        controller.setPromptDelegate(object : WebExtensionController.PromptDelegate {
            override fun onInstallPromptRequest(
                extension: WebExtension,
                permissions: Array<String>,
                origins: Array<String>,
                dataCollectionPermissions: Array<String>
            ): GeckoResult<WebExtension.PermissionPromptResponse>? {
                val result = GeckoResult<WebExtension.PermissionPromptResponse>()
                pendingPrompt = InstallPromptData(
                    extension = extension,
                    permissions = permissions.toList(),
                    origins = origins.toList(),
                    result = result
                )
                return result
            }

            override fun onOptionalPrompt(
                extension: WebExtension,
                permissions: Array<String>,
                origins: Array<String>,
                dataCollectionPermissions: Array<String>
            ): GeckoResult<AllowOrDeny>? {
                // Conservative v0.1: never auto-grant extra runtime permissions.
                return GeckoResult.fromValue(AllowOrDeny.DENY)
            }

            override fun onUpdatePrompt(
                extension: WebExtension,
                newPermissions: Array<String>,
                newOrigins: Array<String>,
                newDataCollectionPermissions: Array<String>
            ): GeckoResult<AllowOrDeny>? {
                // Conservative v0.1: updates needing new permissions stay
                // on the old version until the user approves in the UI.
                return GeckoResult.fromValue(AllowOrDeny.DENY)
            }
        })

        controller.setAddonManagerDelegate(object : WebExtensionController.AddonManagerDelegate {
            override fun onInstalled(extension: WebExtension) {
                attachDelegates(extension)
                refreshInstalled()
            }

            override fun onUninstalled(extension: WebExtension) {
                browserActions.remove(extension.id)
                refreshInstalled()
            }

            override fun onEnabled(extension: WebExtension) = refreshInstalled()
            override fun onDisabled(extension: WebExtension) = refreshInstalled()
            override fun onInstallationFailed(
                extension: WebExtension?,
                error: WebExtension.InstallException
            ) {
                status = "Install fail: ${error.message ?: "code ${error.code}"}"
            }
        })

        refreshInstalled()
    }

    /** User answered the install-permission dialog. */
    fun respondToPrompt(allow: Boolean) {
        val prompt = pendingPrompt ?: return
        pendingPrompt = null
        // (permissions granted, private-browsing allowed, technical-data allowed)
        // Allow = grant the listed permissions only; private browsing and
        // technical/interaction data stay off unless the user enables them.
        prompt.result.complete(WebExtension.PermissionPromptResponse(allow, false, false))
    }

    fun dismissPopup() {
        popupRequest?.session?.let { runCatching { it.close() } }
        popupRequest = null
    }

    fun refreshInstalled() {
        controller.list().accept(
            { list ->
                val items = list ?: emptyList()
                installed.clear()
                installed.addAll(items)
                items.forEach { attachDelegates(it) }
            },
            { error ->
                status = "Add-ons list nahi mili: ${error?.message}"
            }
        )
    }

    fun installFromAmo(slug: String) {
        if (installing) return
        installing = true
        status = "AMO se $slug dhoond rahe hain…"
        ioScope.launch {
            try {
                val xpiUrl = fetchAndroidXpiUrl(slug)
                    ?: throw IllegalStateException("Is add-on ka Android version AMO par nahi mila")
                withContext(Dispatchers.Main) {
                    controller.install(xpiUrl, WebExtensionController.INSTALLATION_METHOD_MANAGER)
                        .accept(
                            { ext ->
                                installing = false
                                if (ext != null) {
                                    status = "${ext.metaData.name ?: slug} install ho gaya"
                                    attachDelegates(ext)
                                    refreshInstalled()
                                } else {
                                    status = "Install ka jawab khaali aaya — dobara try karo"
                                }
                            },
                            { error ->
                                installing = false
                                status = "Install fail: ${error?.message}"
                            }
                        )
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    installing = false
                    status = "AMO error: ${e.message}"
                }
            }
        }
    }

    /**
     * AMO API v5: GET /api/v5/addons/addon/{slug}/ — returns the add-on's
     * current version with its files[]. Picks the Android file when the
     * listing declares one, otherwise the first .xpi file. Returns null when
     * the add-on has no downloadable XPI (e.g. desktop-only listing).
     */
    private fun fetchAndroidXpiUrl(slug: String): String? {
        val conn = (URL("https://addons.mozilla.org/api/v5/addons/addon/$slug/")
            .openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        val body = conn.inputStream.bufferedReader().use { it.readText() }
        val root = JSONObject(body)
        val current = root.optJSONObject("current_version") ?: return null
        val files = current.optJSONArray("files") ?: return null
        var fallback: String? = null
        for (i in 0 until files.length()) {
            val file = files.optJSONObject(i) ?: continue
            val url = file.optString("url", "")
            if (!url.endsWith(".xpi")) continue
            if (fallback == null) fallback = url
            if (file.optString("platform", "") == "android") return url
        }
        return fallback
    }

    fun uninstall(ext: WebExtension) {
        controller.uninstall(ext).accept(
            { refreshInstalled() },
            { error -> status = "Uninstall fail: ${error?.message}" }
        )
    }

    fun setEnabled(ext: WebExtension, enabled: Boolean) {
        val result = if (enabled) {
            controller.enable(ext, WebExtensionController.EnableSource.USER)
        } else {
            controller.disable(ext, WebExtensionController.EnableSource.USER)
        }
        result.accept(
            { refreshInstalled() },
            { error -> status = "Enable/disable fail: ${error?.message}" }
        )
    }

    fun openOptionsPage(ext: WebExtension) {
        val url = ext.metaData.optionsPageUrl ?: return
        openTab(url)
    }

    private fun attachDelegates(ext: WebExtension) {
        ext.setActionDelegate(object : WebExtension.ActionDelegate {
            override fun onBrowserAction(
                extension: WebExtension,
                session: GeckoSession?,
                action: WebExtension.Action
            ) {
                browserActions[extension.id] = action
            }

            override fun onPageAction(
                extension: WebExtension,
                session: GeckoSession?,
                action: WebExtension.Action
            ) {
                browserActions[extension.id] = action
            }

            override fun onOpenPopup(
                extension: WebExtension,
                action: WebExtension.Action
            ): GeckoResult<GeckoSession>? = openPopupSession(extension)

            override fun onTogglePopup(
                extension: WebExtension,
                action: WebExtension.Action
            ): GeckoResult<GeckoSession>? = openPopupSession(extension)
        })

        ext.setTabDelegate(object : WebExtension.TabDelegate {
            override fun onNewTab(
                extension: WebExtension,
                details: WebExtension.CreateTabDetails
            ): GeckoResult<GeckoSession>? {
                return GeckoResult.fromValue(openTab(details.url))
            }

            override fun onOpenOptionsPage(extension: WebExtension) {
                extension.metaData.optionsPageUrl?.let { openTab(it) }
            }
        })
    }

    /**
     * Creates a fresh GeckoSession for an extension popup (e.g. Browsec's
     * connect panel). Gecko loads the extension's popup page into the
     * returned session automatically; the UI shows it in a dialog.
     */
    private fun openPopupSession(extension: WebExtension): GeckoResult<GeckoSession> {
        val session = GeckoSession()
        session.open(runtime)
        popupRequest = PopupRequest(extension, session)
        return GeckoResult.fromValue(session)
    }
}
