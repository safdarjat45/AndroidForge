package com.safdowser.gecko.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentResolver
import android.content.Intent
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import com.safdowser.gecko.MainActivity
import com.tim.basevpn.state.ConnectionState
import com.tim.openvpn.OpenVPNThreadv3
import com.tim.openvpn.model.CIDRIP
import com.tim.openvpn.service.IOpenVPNService
import com.tim.openvpn.utils.NetworkSpace
import com.tim.openvpn.utils.NetworkUtils
import java.net.Inet6Address
import java.net.InetAddress
import java.net.UnknownHostException

/**
 * Gecko's own OpenVPN service.
 *
 * Drives the OpenVPN 3 core (from the tim06 openvpn library) but builds the TUN
 * itself with addAllowedApplication(own package): the tunnel applies ONLY to the
 * Gecko browser — the rest of the device keeps using its normal connection.
 * Only the browser's traffic (the thing that can reveal the real IP) goes through
 * the VPN; when the tunnel is up, the browser cannot leak outside it.
 */
class GeckoOpenVpnService : VpnService(), IOpenVPNService {

    private var vpnThread: OpenVPNThreadv3? = null
    private var runner: Thread? = null
    private var credsUser: String = ""
    private var credsPass: String = ""

    // ---- TUN parameters collected from the OpenVPN core via callbacks ----
    private var mtu: Int? = null
    private var domain: String? = null
    private var localIp: CIDRIP? = null
    private var localIPv6: String? = null
    private val dnsList = mutableListOf<String>()
    private var routes = NetworkSpace()
    private var routes6 = NetworkSpace()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopTunnel()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val config = intent.getStringExtra(EXTRA_CONFIG)
                val label = intent.getStringExtra(EXTRA_LABEL) ?: "VPN"
                val username = intent.getStringExtra(EXTRA_USERNAME) ?: ""
                val password = intent.getStringExtra(EXTRA_PASSWORD) ?: ""
                if (config.isNullOrBlank()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForeground(NOTIFICATION_ID, buildNotification(label))
                startTunnel(config, username, password)
            }
        }
        return START_STICKY
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        runCatching { vpnThread?.stopVPN() }
        super.onDestroy()
    }

    private fun startTunnel(config: String, username: String, password: String) {
        runCatching { vpnThread?.stopVPN() }
        resetTunState()
        credsUser = username
        credsPass = password
        OpenVpnController.onTunnelState(ConnectionState.CONNECTING)
        lateinit var thread: LoggingOpenVPNThreadv3
        thread = LoggingOpenVPNThreadv3(
            this,
            config,
            onEvent = { name, info, isError ->
                OpenVpnController.noteVpnEvent(name, info, isError)
                // If the core asks for credentials mid-handshake, hand them over again.
                if (name.contains("CRED", ignoreCase = true) && credsUser.isNotEmpty()) {
                    provideCreds(thread)
                }
            },
            onLog = { text -> OpenVpnController.appendVpnLog(text) }
        )
        vpnThread = thread
        if (username.isNotEmpty()) {
            // Hand the credentials to the OpenVPN 3 core BEFORE connect() runs.
            // VPN Gate servers reject every connection that arrives without
            // their public standard login.
            provideCreds(thread)
        }
        runner = Thread(thread, "GeckoOpenVPN").apply { start() }
    }

    private fun provideCreds(thread: OpenVPNThreadv3) {
        runCatching {
            val creds = net.openvpn.ovpn3.ClientAPI_ProvideCreds()
            creds.username = credsUser
            creds.password = credsPass
            creds.cachePassword = true
            thread.provide_creds(creds)
        }
    }

    private fun stopTunnel() {
        runCatching { vpnThread?.stopVPN() }
        vpnThread = null
        OpenVpnController.onTunnelState(ConnectionState.DISCONNECTED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun resetTunState() {
        mtu = null
        domain = null
        localIp = null
        localIPv6 = null
        dnsList.clear()
        // Fresh route spaces for the new session (NetworkSpace has no clear()).
        routes = NetworkSpace()
        routes6 = NetworkSpace()
    }

    // ------------------------------------------------------------------
    // IOpenVPNService callbacks (invoked by the OpenVPN 3 core)
    // ------------------------------------------------------------------

    override fun setMtu(mtu: Int) {
        this.mtu = mtu
    }

    override fun addDNS(dns: String?) {
        dns?.let { dnsList.add(it) }
    }

    override fun addRoute(route: CIDRIP?, include: Boolean) {
        routes.addIP(route, include)
    }

    override fun addRoute(dest: String?, mask: String?, gateway: String?, device: String?) {
        if (dest == null || mask == null) return
        val route = CIDRIP(dest, maskToPrefixLen(mask))
        var include = isAndroidTunDevice(device)

        if (gateway == null) {
            routes.addIP(route, include)
            return
        }
        val gatewayIP = NetworkSpace.IpAddress(CIDRIP(gateway, 32), false)
        val local = localIp
        if (local == null) {
            return
        }
        val localNet = NetworkSpace.IpAddress(local, true)
        if (localNet.containsNet(gatewayIP)) include = true
        if (gateway == "255.255.255.255") include = true
        route.normalise()
        routes.addIP(route, include)
    }

    override fun addRoutev6(network: String?, device: String?) {
        val included = isAndroidTunDevice(device)
        network?.let { addRoutev6(it, included) }
    }

    fun addRoutev6(network: String, included: Boolean) {
        val parts = network.split("/".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        try {
            val ip = InetAddress.getAllByName(parts[0])[0] as Inet6Address
            val mask = parts[1].toInt()
            routes6.addIPv6(ip, mask, included)
        } catch (e: UnknownHostException) {
            // ignore unresolvable v6 route
        }
    }

    override fun setDomain(domain: String?) {
        domain?.let { this.domain = it }
    }

    override fun addHttpProxy(proxy: String?, port: Int): Boolean = false

    override fun protectFd(fd: Int): Boolean = protect(fd)

    override fun openTun(): ParcelFileDescriptor? = startTun()

    override fun setLocalIP(cidrip: CIDRIP?) {
        this.localIp = cidrip
    }

    override fun setLocalIPv6(ipv6addr: String?) {
        this.localIPv6 = ipv6addr
    }

    override fun trigger_sso(info: String?) {
        // No SSO flows for VPN Gate configs.
    }

    override val ctResolver: ContentResolver
        get() = contentResolver

    override val connectivityManager: ConnectivityManager
        get() = getSystemService(ConnectivityManager::class.java)

    override fun openvpnStopped() {
        vpnThread = null
        OpenVpnController.onTunnelState(ConnectionState.DISCONNECTED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun updateStateThread(state: ConnectionState) {
        OpenVpnController.onTunnelState(state)
    }

    // ------------------------------------------------------------------
    // TUN establishment — per-app: ONLY Safdowser is allowed in the tunnel
    // ------------------------------------------------------------------

    private fun startTun(): ParcelFileDescriptor? {
        val builder = Builder()

        // *** Per-app VPN: only this browser's traffic enters the tunnel. ***
        // Fail CLOSED: if the per-app restriction cannot be applied, do not
        // establish any tunnel at all rather than silently leaking.
        val allowedOk = runCatching {
            builder.addAllowedApplication(packageName)
            true
        }.getOrDefault(false)
        if (!allowedOk) return null

        builder.apply {
            if (localIp != null) {
                addLocalNetworksToRoutes()
                try {
                    localIp?.let { addAddress(it.ip, it.len) }
                } catch (iae: IllegalArgumentException) {
                    return null
                }
            }

            if (localIPv6 != null) {
                val ipv6parts = localIPv6!!.split("/".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                try {
                    addAddress(ipv6parts[0], ipv6parts[1].toInt())
                } catch (iae: IllegalArgumentException) {
                    return null
                }
            }

            if (dnsList.isEmpty()) {
                // No DNS pushed by the server: use public resolvers THROUGH the
                // tunnel so name lookups cannot leak to the device network either.
                addDnsServer("1.1.1.1")
                addDnsServer("8.8.8.8")
            } else {
                dnsList.forEach { addDnsServer(it) }
            }
            mtu?.let { setMtu(it) }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                installRoutesExcluded(this, routes)
                installRoutesExcluded(this, routes6)
            } else {
                installRoutesPositiveOnly(this, routes.getPositiveIPList(), routes6.getPositiveIPList())
            }

            // Belt and braces: ALWAYS route all of the app's traffic into the
            // tunnel explicitly, whatever route collection produced above.
            runCatching { addRoute("0.0.0.0", 0) }
            if (localIPv6 != null) {
                runCatching { addRoute("::", 0) }
            }

            if (domain != null) {
                addSearchDomain(domain!!)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                setUnderlyingNetworks(null)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                setMetered(false)
            }
            setSession("Gecko VPN")
        }

        return runCatching { builder.establish() }.getOrNull()
    }

    private fun addLocalNetworksToRoutes() {
        for (net in NetworkUtils.getLocalNetworks(connectivityManager, true)) {
            addRoutev6(net, false)
        }
    }

    private fun installRoutesExcluded(builder: Builder, space: NetworkSpace) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            for (ipIncl in space.getNetworks(true)) {
                try {
                    builder.addRoute(ipIncl.prefix)
                } catch (e: Exception) {
                    // skip bad route
                }
            }
            for (ipExcl in space.getNetworks(false)) {
                try {
                    builder.excludeRoute(ipExcl.prefix)
                } catch (e: Exception) {
                    // skip bad route
                }
            }
        }
    }

    private fun installRoutesPositiveOnly(
        builder: Builder,
        positiveIPv4Routes: Collection<NetworkSpace.IpAddress>,
        positiveIPv6Routes: Collection<NetworkSpace.IpAddress>
    ) {
        val multicastRange = NetworkSpace.IpAddress(CIDRIP("224.0.0.0", 3), true)
        for (route in positiveIPv4Routes) {
            try {
                if (!multicastRange.containsNet(route)) {
                    builder.addRoute(route.getIPv4Address(), route.networkMask)
                }
            } catch (iae: IllegalArgumentException) {
                // skip bad route
            }
        }
        for (route6 in positiveIPv6Routes) {
            try {
                builder.addRoute(route6.getIPv6Address(), route6.networkMask)
            } catch (iae: IllegalArgumentException) {
                // skip bad route
            }
        }
    }

    private fun isAndroidTunDevice(device: String?): Boolean {
        return device != null &&
            (device.startsWith("tun") || device == "(null)" || device == OpenVPNThreadv3.VPNSERVICE_TUN)
    }

    private fun maskToPrefixLen(mask: String): Int {
        return mask.split(".").sumOf { part -> Integer.bitCount(part.toIntOrNull() ?: 0) }
    }

    private fun buildNotification(label: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CHANNEL_ID, "Gecko VPN", NotificationManager.IMPORTANCE_LOW)
        nm.createNotificationChannel(channel)
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Gecko VPN active (this browser only)")
            .setContentText(label)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_START = "com.safdowser.gecko.openvpn.START"
        const val ACTION_STOP = "com.safdowser.gecko.openvpn.STOP"
        const val EXTRA_CONFIG = "extra_ovpn_config"
        const val EXTRA_LABEL = "extra_server_label"
        const val EXTRA_USERNAME = "extra_ovpn_username"
        const val EXTRA_PASSWORD = "extra_ovpn_password"
        private const val CHANNEL_ID = "gecko_openvpn_channel"
        private const val NOTIFICATION_ID = 7002
    }
}
