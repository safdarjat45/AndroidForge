package com.safdowser.gecko

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.safdowser.gecko.ui.GeckoApp
import com.safdowser.gecko.ui.theme.GeckoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GeckoTheme {
                GeckoApp()
            }
        }
    }
}
