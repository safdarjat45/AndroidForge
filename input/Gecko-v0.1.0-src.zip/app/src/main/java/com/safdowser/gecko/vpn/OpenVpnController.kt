package com.safdowser.gecko.vpn

import android.content.Context
import android.content.Intent
import android.os.Build
import com.tim.basevpn.state.ConnectionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Real OpenVPN tunnel control (VPN Gate servers).
 *
 * The tunnel is provided by [GeckoOpenVpnService], which restricts it to the
 * Safdowser app only (per-app VPN): the rest of the device is untouched, and the
 * browser — whose traffic could reveal the real IP — cannot leak outside it.
 */
object OpenVpnController {

    private val _state = MutableStateFlow(ConnectionState.DISCONNECTED)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private val _activeServer = MutableStateFlow<VpnServer?>(null)
    val activeServer: StateFlow<VpnServer?> = _activeServer.asStateFlow()

    /** Rolling OpenVPN core log (events + log lines) so failures are visible in the app. */
    private val _logLines = MutableStateFlow<List<String>>(emptyList())
    val logLines: StateFlow<List<String>> = _logLines.asStateFlow()

    /** The most recent error-looking event from the core, shown when a connection drops. */
    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    fun appendVpnLog(line: String) {
        val clean = line.trim().take(220)
        if (clean.isEmpty()) return
        _logLines.value = (_logLines.value + clean).takeLast(40)
    }

    fun noteVpnEvent(name: String, info: String, isError: Boolean) {
        appendVpnLog("EVENT: $name $info".trim())
        if (isError || name.contains("FAIL", ignoreCase = true) || name.contains("ERROR", ignoreCase = true)) {
            _lastError.value = "$name $info".trim()
        }
    }

    fun clearVpnLog() {
        _logLines.value = emptyList()
        _lastError.value = null
    }

    /** Called by GeckoOpenVpnService (same process) whenever the tunnel state changes. */
    fun onTunnelState(newState: ConnectionState) {
        _state.value = newState
        if (newState == ConnectionState.DISCONNECTED) {
            _activeServer.value = null
        }
    }

    fun connect(context: Context, server: VpnServer) {
        clearVpnLog()
        _activeServer.value = server
        _state.value = ConnectionState.CONNECTING
        val intent = Intent(context.applicationContext, GeckoOpenVpnService::class.java).apply {
            action = GeckoOpenVpnService.ACTION_START
            putExtra(GeckoOpenVpnService.EXTRA_CONFIG, sanitizeOvpnConfig(server.ovpnConfig))
            putExtra(GeckoOpenVpnService.EXTRA_LABEL, "${server.countryName} · ${server.ipAddress}")
            putExtra(GeckoOpenVpnService.EXTRA_USERNAME, server.username)
            putExtra(GeckoOpenVpnService.EXTRA_PASSWORD, server.password)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.applicationContext.startForegroundService(intent)
        } else {
            context.applicationContext.startService(intent)
        }
    }

    fun disconnect(context: Context) {
        val intent = Intent(context.applicationContext, GeckoOpenVpnService::class.java).apply {
            action = GeckoOpenVpnService.ACTION_STOP
        }
        runCatching { context.applicationContext.startService(intent) }
        _activeServer.value = null
        _state.value = ConnectionState.DISCONNECTED
    }

    val isConnected: Boolean
        get() = _state.value == ConnectionState.CONNECTED

    /** Fetches the public exit IP as seen by websites right now (goes through the tunnel when it is up). */
    suspend fun fetchExitIp(): String? = withContext(Dispatchers.IO) {
        val endpoints = listOf("https://api.ipify.org", "https://icanhazip.com")
        for (endpoint in endpoints) {
            val ip = runCatching {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                conn.inputStream.bufferedReader().use { it.readText() }.trim()
            }.getOrNull()
            if (!ip.isNullOrBlank() && ip.length <= 45) return@withContext ip
        }
        null
    }

    /** Exit IP measured THROUGH a specific proxy — the truth about what that proxy gives. */
    suspend fun fetchExitIpViaProxy(host: String, port: Int, proto: String): String? = withContext(Dispatchers.IO) {
        val proxy = runCatching {
            java.net.Proxy(
                if (proto.equals("SOCKS5", ignoreCase = true)) java.net.Proxy.Type.SOCKS else java.net.Proxy.Type.HTTP,
                java.net.InetSocketAddress(host, port)
            )
        }.getOrNull() ?: return@withContext null
        val endpoints = listOf("https://api.ipify.org", "https://icanhazip.com")
        for (endpoint in endpoints) {
            val ip = runCatching {
                val conn = (URL(endpoint).openConnection(proxy) as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                conn.inputStream.bufferedReader().use { it.readText() }.trim()
            }.getOrNull()
            if (!ip.isNullOrBlank() && ip.length <= 45) return@withContext ip
        }
        null
    }
}
