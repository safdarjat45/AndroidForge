package com.safdowser.gecko.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.safdowser.gecko.browser.AddonsManager
import com.safdowser.gecko.browser.BrowserTabManager
import com.safdowser.gecko.browser.GeckoEngine
import org.mozilla.geckoview.GeckoView

private enum class Screen { Browser, Addons, Identity, Vpn }

@Composable
fun GeckoApp() {
    val context = LocalContext.current
    val runtime = remember { GeckoEngine.runtime(context) }
    val tabManager = remember { BrowserTabManager(runtime) }
    val addons = remember {
        AddonsManager(runtime) { url -> tabManager.newTab(url).session }
    }

    var screen by remember { mutableStateOf(Screen.Browser) }
    var addressText by remember { mutableStateOf("") }

    val activeTab = tabManager.activeTab

    LaunchedEffect(Unit) {
        if (tabManager.tabs.isEmpty()) tabManager.newTab()
    }

    // Keep the address bar in step with the active tab's current URL.
    LaunchedEffect(activeTab?.id, activeTab?.url) {
        val url = activeTab?.url.orEmpty()
        addressText =
            if (url.isNotEmpty() && !url.startsWith("data:") && !url.startsWith("about:")) url
            else ""
    }

    BackHandler {
        when {
            screen != Screen.Browser -> screen = Screen.Browser
            activeTab?.canGoBack == true -> activeTab?.goBack()
            else -> (context as? Activity)?.finish()
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // ---- Tab strip ----
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 40.dp, start = 8.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LazyRow(modifier = Modifier.weight(1f)) {
                items(tabManager.tabs, key = { it.id }) { tab ->
                    Row(
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (tab.id == activeTab?.id) MaterialTheme.colorScheme.surfaceVariant
                                else MaterialTheme.colorScheme.surface
                            )
                            .clickable { tabManager.selectTab(tab.id) }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tab.title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.width(90.dp),
                            style = MaterialTheme.typography.bodySmall
                        )
                        IconButton(onClick = { tabManager.closeTab(tab) }) {
                            Icon(Icons.Filled.Close, contentDescription = "Close tab")
                        }
                    }
                }
            }
            IconButton(onClick = { tabManager.newTab() }) {
                Icon(Icons.Filled.Add, contentDescription = "New tab")
            }
        }

        // ---- Address bar ----
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { activeTab?.goBack() },
                enabled = activeTab?.canGoBack == true
            ) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
            IconButton(
                onClick = { activeTab?.goForward() },
                enabled = activeTab?.canGoForward == true
            ) { Icon(Icons.Filled.ArrowForward, contentDescription = "Forward") }
            IconButton(onClick = { activeTab?.reload() }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Reload")
            }
            OutlinedTextField(
                value = addressText,
                onValueChange = { addressText = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Search ya address likho") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = { activeTab?.load(addressText) }
                )
            )
            IconButton(onClick = { screen = Screen.Addons }) {
                Icon(Icons.Filled.Extension, contentDescription = "Add-ons")
            }
            IconButton(onClick = { screen = Screen.Identity }) {
                Icon(Icons.Filled.Shield, contentDescription = "Identity")
            }
            IconButton(onClick = { screen = Screen.Vpn }) {
                Icon(Icons.Filled.VpnKey, contentDescription = "VPN")
            }
        }

        // ---- Extension action buttons (browser_action / page_action) ----
        if (addons.browserActions.isNotEmpty()) {
            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(addons.browserActions.entries.toList(), key = { it.key }) { (extId, action) ->
                    val label = buildString {
                        append(action.title ?: extId)
                        action.badgeText?.let { append(" ($it)") }
                    }
                    TextButton(onClick = { action.click() }) {
                        Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        if (activeTab?.loading == true) {
            LinearProgressIndicator(
                progress = { (activeTab?.progress ?: 0) / 100f },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // ---- Content ----
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (screen) {
                Screen.Browser -> {
                    val tab = activeTab
                    if (tab != null) {
                        key(tab.id) {
                            AndroidView(
                                factory = { ctx ->
                                    GeckoView(ctx).apply { setSession(tab.session) }
                                },
                                onRelease = { view -> view.releaseSession() },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) { Text("Tab khul raha hai…") }
                    }
                }
                Screen.Addons -> AddonsScreen(
                    addons = addons,
                    onBack = { screen = Screen.Browser }
                )
                Screen.Identity -> IdentityScreen(
                    tab = activeTab,
                    onBack = { screen = Screen.Browser }
                )
                Screen.Vpn -> VpnScreen(onBack = { screen = Screen.Browser })
            }
        }
    }

    // ---- Extension install permission dialog ----
    val prompt = addons.pendingPrompt
    if (prompt != null) {
        AlertDialog(
            onDismissRequest = { addons.respondToPrompt(false) },
            title = {
                Text("Add-on install karein?")
            },
            text = {
                Column {
                    Text(
                        text = prompt.extension.metaData.name ?: prompt.extension.id,
                        fontWeight = FontWeight.Bold
                    )
                    Text(prompt.extension.metaData.description ?: "")
                    if (prompt.permissions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Permissions:", fontWeight = FontWeight.Bold)
                        prompt.permissions.forEach { Text("• $it") }
                    }
                    if (prompt.origins.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Sites:", fontWeight = FontWeight.Bold)
                        prompt.origins.forEach { Text("• $it") }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Ye add-on Mozilla-signed hai (AMO se). Add-on apna code khud chalata hai — " +
                            "uske leaks (WebRTC waghera) hamare control mein nahi.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(onClick = { addons.respondToPrompt(true) }) { Text("Install") }
            },
            dismissButton = {
                TextButton(onClick = { addons.respondToPrompt(false) }) { Text("Cancel") }
            }
        )
    }

    // ---- Extension popup (e.g. Browsec connect panel) ----
    val popup = addons.popupRequest
    if (popup != null) {
        Dialog(onDismissRequest = { addons.dismissPopup() }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(480.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = popup.extension.metaData.name ?: popup.extension.id,
                        modifier = Modifier.weight(1f),
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { addons.dismissPopup() }) {
                        Icon(Icons.Filled.Close, contentDescription = "Close popup")
                    }
                }
                // Key on the session object itself: a second popup from the
                // same extension gets a fresh session and must re-run factory.
                key(popup.session) {
                    AndroidView(
                        factory = { ctx ->
                            GeckoView(ctx).apply { setSession(popup.session) }
                        },
                        onRelease = { view -> view.releaseSession() },
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    )
                }
            }
        }
    }
}
