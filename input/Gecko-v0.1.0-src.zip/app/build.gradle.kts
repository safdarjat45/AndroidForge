plugins {
    id("com.android.application")
    // Explicit KGP 2.4.21 (see top-level build file + gradle.properties):
    // AGP 9.1's built-in Kotlin is 2.2.10 and cannot read GeckoView 160's
    // kotlin-stdlib 2.4.21 (run #13). Built-in Kotlin is opted out.
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.safdowser.gecko"
    // GeckoView 160 + current AndroidX require compileSdk 37
    // (run #10 failed checkReleaseAarMetadata on 35). targetSdk stays 35.
    compileSdk = 37

    defaultConfig {
        applicationId = "com.safdowser.gecko"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"

        vectorDrawables {
            useSupportLibrary = true
        }

        ndk {
            // arm64 only: the GeckoView omni AAR we depend on is arm64-only.
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            // v0.1: keep minification OFF — the GeckoView engine + OpenVPN
            // native core are big, and R8 adds a whole class of first-build
            // risk for almost no size saving on a ~90 MB APK.
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // KGP 2.4.21 is applied explicitly (see plugins block above); the
    // kotlin.compilerOptions{} DSL is provided by that plugin.
    kotlin {
        compilerOptions {
            jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
        }
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    // NOTE (run #13 fix): the constraints block that pinned the Kotlin
    // stdlib family to 2.2.10 was REMOVED. It did not take effect — the
    // 2.4.21 stdlib was still on the compile classpath in run #13 — and
    // with the compiler now upgraded to 2.4.21, stdlib 2.4.21 (declared
    // by GeckoView 160's POM) is exactly what the compiler expects.
    // Pinning it down again would reintroduce the mismatch in reverse.

    // Compose BOM 2025.05.00 (Compose 1.8.1 runtime, verified on Google
    // Maven). The old BOM 2024.09.03 pinned runtime 1.7.x; the Compose
    // compiler 2.4.x targets newer runtimes, so the BOM is bumped to the
    // 1.8.x line to stay above the compiler's minimum runtime. BOM
    // 2025.05.00 needs Kotlin 2.2+ and compileSdk 35 — both satisfied
    // (Kotlin 2.4.21, compileSdk 37). Deliberately NOT the newest BOM
    // (2026.11.01 / Compose 1.13 needs compileSdk 37.1).
    val composeBom = platform("androidx.compose:compose-bom:2025.05.00")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.activity:activity-compose:1.9.2")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Firefox engine (GeckoView 160 stable). The stable per-ABI arm64
    // artifact is named "geckoview-omni-arm64-v8a" — there is no plain
    // "geckoview-arm64-v8a" for stable releases (that name is beta/nightly
    // only). Verified on mvnrepository 2026-11-21: 160.0.20261116130455
    // exists for geckoview-omni-arm64-v8a (AAR ~87 MB).
    implementation("org.mozilla.geckoview:geckoview-omni-arm64-v8a:160.0.20261116130455")

    // Real OpenVPN tunnel engine (OpenVPN 3 core) — same as Safdowser.
    implementation("io.github.tim06:openvpn:1.1.3")
}
