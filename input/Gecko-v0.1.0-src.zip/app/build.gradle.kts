plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.safdowser.gecko"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.safdowser.gecko"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"

        vectorDrawables {
            useSupportLibrary = true
        }

        ndk {
            // arm64 only: the GeckoView omni AAR we depend on is arm64-only.
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            // v0.1: keep minification OFF — the GeckoView engine + OpenVPN
            // native core are big, and R8 adds a whole class of first-build
            // risk for almost no size saving on a ~90 MB APK.
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.03")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.activity:activity-compose:1.9.2")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Firefox engine (GeckoView 160 stable). The stable per-ABI arm64
    // artifact is named "geckoview-omni-arm64-v8a" — there is no plain
    // "geckoview-arm64-v8a" for stable releases (that name is beta/nightly
    // only). Verified on mvnrepository 2026-11-21: 160.0.20261116130455
    // exists for geckoview-omni-arm64-v8a (AAR ~87 MB).
    implementation("org.mozilla.geckoview:geckoview-omni-arm64-v8a:160.0.20261116130455")

    // Real OpenVPN tunnel engine (OpenVPN 3 core) — same as Safdowser.
    implementation("io.github.tim06:openvpn:1.1.3")
}
