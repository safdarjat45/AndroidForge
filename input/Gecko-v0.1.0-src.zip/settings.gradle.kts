pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Mozilla's own Maven repo — the only place GeckoView artifacts live.
        maven { url = uri("https://maven.mozilla.org/maven2/") }
    }
}

rootProject.name = "GeckoBrowser"
include(":app")
