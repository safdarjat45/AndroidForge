plugins {
    // AGP 9.1.1 — minimum for compileSdk 37 (API 37 table: AGP 9.1.1+).
    // Verified against developer.android.com AGP 9.1.1 release notes
    // (Gradle 9.3.1, JDK 17, KGP 2.2.10, Build Tools 36.0.0).
    id("com.android.application") version "9.1.1" apply false
    // Kotlin 2.4.21 — NOT AGP's built-in KGP 2.2.10. Run #13 proved the
    // built-in 2.2 compiler cannot read GeckoView 160's kotlin-stdlib
    // 2.4.21 (metadata 2.4.0 vs compiler max 2.3.0), and the constraints
    // pin to 2.2.10 did not take effect. So built-in Kotlin is opted out
    // (android.builtInKotlin=false in gradle.properties, documented at
    // developer.android.com/build/migrate-to-built-in-kotlin) and the
    // explicit KGP 2.4.21 is applied instead. Compatibility verified on
    // kotlinlang.org (KGP 2.4.20-2.4.21: Gradle 7.6.3-9.7.0,
    // AGP 8.5.2-9.3.1 — our Gradle 9.3.1 and AGP 9.1.1 are both inside)
    // and developer.android.com/build/kotlin-support (Kotlin 2.4 needs
    // AGP 8.5.2+). Plugin markers verified HTTP 200 on the Gradle Plugin
    // Portal, implementation artifacts on Maven Central.
    id("org.jetbrains.kotlin.android") version "2.4.21" apply false
    // Compose compiler plugin, same version as KGP (they ship together
    // since Kotlin 2.0; the plugin overrides AGP's bundled compiler).
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.21" apply false
}
