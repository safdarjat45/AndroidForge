plugins {
    // AGP 9.1.1 — minimum for compileSdk 37 (API 37 table: AGP 9.1.1+).
    // Verified against developer.android.com AGP 9.1.1 release notes
    // (Gradle 9.3.1, JDK 17, KGP 2.2.10, Build Tools 36.0.0).
    id("com.android.application") version "9.1.1" apply false
    // Compose compiler plugin (Kotlin 2.2.10, matches AGP's runtime KGP).
    // NOTE: org.jetbrains.kotlin.android is deliberately NOT applied:
    // AGP 9.0+ has built-in Kotlin (android.builtInKotlin=true by default)
    // and applying kotlin-android errors out. See
    // developer.android.com/build/migrate-to-built-in-kotlin.
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.10" apply false
}
