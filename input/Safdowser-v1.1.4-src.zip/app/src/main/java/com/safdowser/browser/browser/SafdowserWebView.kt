package com.safdowser.browser.browser

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.safdowser.browser.antidetect.AntiDetectScriptBuilder
import com.safdowser.browser.data.SettingsStore
import com.safdowser.browser.model.BrowserProfile

@SuppressLint("SetJavaScriptEnabled")
class SafdowserWebViewController(private val context: Context) {

    var webView: WebView? = null
        private set

    fun createAndConfigure(
        profile: BrowserProfile,
        onUrlChanged: (String) -> Unit,
        onProgressChanged: (Int) -> Unit,
        onTitleChanged: (String) -> Unit,
        onError: (String?) -> Unit = {},
        onIdentityProbe: (String) -> Unit = {}
    ): WebView {
        val wv = WebView(context).apply {
            settings.apply {
                javaScriptEnabled = SettingsStore.jsEnabled
                loadsImagesAutomatically = SettingsStore.imagesEnabled
                blockNetworkImage = !SettingsStore.imagesEnabled
                domStorageEnabled = !profile.isIncognito
                databaseEnabled = !profile.isIncognito
                userAgentString = profile.userAgent
                setGeolocationEnabled(true)
                useWideViewPort = true
                loadWithOverviewMode = true
                builtInZoomControls = true
                displayZoomControls = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                cacheMode = if (profile.isIncognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
                allowFileAccess = false
                allowContentAccess = false
            }

            if (profile.isIncognito) {
                CookieManager.getInstance().setAcceptCookie(false)
                clearHistory()
                clearCache(true)
            } else {
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            }

            val antiDetectScript = AntiDetectScriptBuilder.build(profile)
            val docStartSupported = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
            if (docStartSupported) {
                WebViewCompat.addDocumentStartJavaScript(
                    this,
                    antiDetectScript,
                    setOf("*")
                )
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): android.webkit.WebResourceResponse? {
                    if (SettingsStore.adBlockEnabled && AdBlocker.isAd(request?.url?.host)) {
                        return android.webkit.WebResourceResponse(
                            "text/plain",
                            "utf-8",
                            "".byteInputStream()
                        )
                    }
                    if (request?.url?.host == StartPage.HOST) {
                        val html = StartPage.html(profile)
                        return android.webkit.WebResourceResponse(
                            "text/html",
                            "utf-8",
                            html.byteInputStream(Charsets.UTF_8)
                        )
                    }
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    onError(null)
                    if (!docStartSupported) {
                        // Fallback for WebViews without document-start scripts:
                        // inject as early as we can instead of not at all.
                        view?.evaluateJavascript(antiDetectScript, null)
                    }
                    if (url != null) onUrlChanged(url)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    // Verify the spoofing is actually alive on this page and report
                    // back, so a silent failure becomes a visible warning instead.
                    view?.evaluateJavascript(
                        "(window.__safdowserInjected === true ? (Intl.DateTimeFormat().resolvedOptions().timeZone || 'OK') : 'NOT_INJECTED')"
                    ) { result -> onIdentityProbe(result?.trim('"') ?: "") }
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: android.webkit.WebResourceRequest?,
                    error: android.webkit.WebResourceError?
                ) {
                    super.onReceivedError(view, request, error)
                    if (request?.isForMainFrame == true) {
                        val desc = error?.description?.toString() ?: "Page failed to load"
                        onError(desc)
                    }
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val scheme = request?.url?.scheme?.lowercase() ?: return false
                    return scheme != "http" && scheme != "https"
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    onProgressChanged(newProgress)
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                    if (!title.isNullOrBlank()) onTitleChanged(title)
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?
                ) {
                    callback?.invoke(origin, true, false)
                }
            }
        }
        webView = wv
        return wv
    }

    fun wipeSessionData() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        webView?.apply {
            clearHistory()
            clearFormData()
            clearCache(true)
        }
    }

    /** Full browsing-data wipe across every tab (cookies/cache are shared by the engine). */
    fun wipeAllData(allViews: Collection<WebView>) {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        allViews.forEach { v ->
            runCatching {
                v.clearHistory()
                v.clearFormData()
                v.clearCache(true)
            }
        }
    }
}
