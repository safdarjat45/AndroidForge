package com.safdowser.browser.browser

/**
 * Built-in ad/tracker blocking — the job most people install an extension for.
 * Android WebView cannot run Chrome extensions at all, so the common ad and
 * tracker networks are blocked right in the request pipeline instead.
 */
object AdBlocker {
    private val blockedHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "google-analytics.com", "googletagmanager.com", "adservice.google.com",
        "adnxs.com", "adsrvr.org", "criteo.com", "criteo.net", "outbrain.com",
        "taboola.com", "scorecardresearch.com", "quantserve.com", "moatads.com",
        "amazon-adsystem.com", "connect.facebook.net", "bat.bing.com",
        "adform.net", "smartadserver.com", "pubmatic.com", "rubiconproject.com",
        "openx.net", "casalemedia.com", "contextweb.com", "lijit.com", "sovrn.com",
        "sharethrough.com", "teads.tv", "yieldmo.com", "nativo.com", "mgid.com",
        "revcontent.com", "zergnet.com", "popads.net", "popcash.net",
        "propellerads.com", "adcash.com", "exoclick.com", "hilltopads.com",
        "clickadu.com", "adsterra.com", "monetag.com", "unityads.unity3d.com",
        "applovin.com", "chartboost.com", "inmobi.com", "adcolony.com",
        "analytics.yahoo.com", "ads.yahoo.com", "advertising.com", "33across.com",
        "bidswitch.net", "rlcdn.com", "mathtag.com", "everesttech.net"
    )

    fun isAd(host: String?): Boolean {
        if (host.isNullOrBlank()) return false
        val h = host.lowercase()
        return blockedHosts.any { h == it || h.endsWith(".$it") }
    }
}
