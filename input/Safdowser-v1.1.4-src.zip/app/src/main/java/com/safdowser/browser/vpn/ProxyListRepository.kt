package com.safdowser.browser.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL

/** A raw proxy endpoint from a public list (untested — most free ones are dead). */
data class ProxyCandidate(val host: String, val port: Int, val type: String) // type: "HTTP" | "SOCKS5"

/** A proxy that answered a real HTTPS request from THIS phone, with the exit IP it produced. */
data class VerifiedProxy(
    val host: String,
    val port: Int,
    val type: String,
    val exitIp: String,
    val country: String,
    val countryCode: String,
    val latencyMs: Long
)

/**
 * "Ready IPs": fetches fresh free-proxy lists and TESTS each candidate on this
 * phone's own network (a proxy that is dead here is useless here, wherever else
 * it may work). Only proxies that actually return an exit IP are surfaced.
 */
object ProxyListRepository {

    private val ipLine = Regex("""^(\d{1,3}(?:\.\d{1,3}){3}):(\d{1,5})\s*$""")

    private fun fetchText(url: String, timeoutMs: Int = 12000): String? = runCatching {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
        }
        conn.inputStream.bufferedReader().use { it.readText() }
    }.getOrNull()

    private fun parseList(text: String?, type: String, cap: Int): List<ProxyCandidate> {
        if (text.isNullOrBlank()) return emptyList()
        val out = ArrayList<ProxyCandidate>()
        for (line in text.lineSequence()) {
            val m = ipLine.matchEntire(line.trim()) ?: continue
            val port = m.groupValues[2].toIntOrNull() ?: continue
            if (port !in 1..65535) continue
            out.add(ProxyCandidate(m.groupValues[1], port, type))
            if (out.size >= cap) break
        }
        return out
    }

    /** Fresh candidate endpoints from several public lists. Untested — verify before use. */
    suspend fun fetchCandidates(): List<ProxyCandidate> = withContext(Dispatchers.IO) {
        val sources = listOf(
            // USA first — that is what the user asks for most; dedupe keeps this order,
            // so US candidates are the first ones tested.
            "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=8000&country=US&ssl=all&anonymity=all" to ("HTTP" to 70),
            "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=8000&country=US" to ("SOCKS5" to 50),
            "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=8000&country=all&ssl=all&anonymity=all" to ("HTTP" to 130),
            "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=8000&country=all" to ("SOCKS5" to 90),
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt" to ("HTTP" to 90),
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt" to ("SOCKS5" to 60)
        )
        val all = ArrayList<ProxyCandidate>()
        for ((url, tc) in sources) {
            all += parseList(fetchText(url), tc.first, tc.second)
        }
        val seen = HashSet<String>()
        all.filter { seen.add("${it.host}:${it.port}:${it.type}") }
    }

    /** Country of an exit IP (HTTPS lookup; "Unknown" when it fails). */
    fun geoOf(ip: String): Pair<String, String> {
        val body = fetchText("https://ipapi.co/$ip/json/", 5000) ?: return "Unknown" to ""
        val name = Regex(""""country_name"\s*:\s*"([^"]+)"""").find(body)?.groupValues?.get(1) ?: "Unknown"
        val code = Regex(""""country_code"\s*:\s*"([^"]+)"""").find(body)?.groupValues?.get(1) ?: ""
        return name to code
    }

    /** One real test: fetch our exit IP through this proxy over HTTPS. Null = dead for us. */
    fun testOne(c: ProxyCandidate): VerifiedProxy? {
        val started = System.currentTimeMillis()
        val exitIp = runCatching {
            val proxy = Proxy(
                if (c.type == "SOCKS5") Proxy.Type.SOCKS else Proxy.Type.HTTP,
                InetSocketAddress(c.host, c.port)
            )
            val conn = (URL("https://api.ipify.org?format=json").openConnection(proxy) as HttpURLConnection).apply {
                connectTimeout = 5000
                readTimeout = 5000
                requestMethod = "GET"
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            Regex(""""ip"\s*:\s*"([^"]+)"""").find(body)?.groupValues?.get(1)
        }.getOrNull() ?: return null
        val latency = System.currentTimeMillis() - started
        val (country, code) = geoOf(exitIp)
        return VerifiedProxy(c.host, c.port, c.type, exitIp, country, code, latency)
    }

    /**
     * Fetch fresh candidates and test them on THIS phone's network until [want]
     * working ones are found (or [maxTest] have been tried).
     */
    suspend fun fetchVerified(
        want: Int = 12,
        maxTest: Int = 80,
        onProgress: (found: Int, tested: Int) -> Unit = { _, _ -> }
    ): List<VerifiedProxy> = withContext(Dispatchers.IO) {
        val candidates = fetchCandidates().take(maxTest)
        val found = ArrayList<VerifiedProxy>()
        var tested = 0
        for (batch in candidates.chunked(10)) {
            if (found.size >= want) break
            val results = coroutineScope {
                batch.map { c -> async(Dispatchers.IO) { testOne(c) } }.awaitAll()
            }
            tested += batch.size
            results.filterNotNull().forEach { if (found.size < want) found.add(it) }
            onProgress(found.size, tested)
        }
        found.sortedBy { it.latencyMs }
    }
}
