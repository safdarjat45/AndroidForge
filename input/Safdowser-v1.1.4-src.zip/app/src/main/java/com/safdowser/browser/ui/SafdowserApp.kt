package com.safdowser.browser.ui

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.safdowser.browser.browser.SafdowserWebViewController
import com.safdowser.browser.browser.StartPage
import com.safdowser.browser.data.ProfileRepository
import com.safdowser.browser.data.SettingsStore
import com.safdowser.browser.model.GeoPreset
import com.safdowser.browser.model.GeoPresets
import com.safdowser.browser.vpn.OpenVpnController
import com.safdowser.browser.vpn.ProxyListRepository
import com.safdowser.browser.vpn.SafdowserVpnService
import com.safdowser.browser.vpn.VerifiedProxy
import com.safdowser.browser.vpn.VpnServer
import com.safdowser.browser.vpn.VpnServerRepository
import com.safdowser.browser.vpn.WebViewProxyManager
import com.tim.basevpn.state.ConnectionState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

/** One browser tab: its own WebView (kept in a map) plus observable page state. */
private class TabState(val id: String, startUrl: String) {
    var url by mutableStateOf(startUrl)
    var title by mutableStateOf("New Tab")
    var progress by mutableIntStateOf(100)
    var error by mutableStateOf<String?>(null)
    /** True when the identity probe found the anti-detect script NOT active on the current page. */
    var spoofWarning by mutableStateOf(false)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafdowserApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val profileRepo = remember { ProfileRepository(context) }
    val vpnRepo = remember { VpnServerRepository() }
    SettingsStore.init(context)

    var profiles by remember { mutableStateOf(profileRepo.loadProfiles()) }
    var activeProfile by remember { mutableStateOf(profiles.first()) }
    var isIncognito by remember { mutableStateOf(false) }

    // ---- Tabs -------------------------------------------------------------
    var tabs by remember { mutableStateOf(listOf(TabState(UUID.randomUUID().toString(), StartPage.URL))) }
    var activeTabId by remember { mutableStateOf(tabs.first().id) }
    val activeTab: TabState = tabs.firstOrNull { it.id == activeTabId } ?: tabs.first()
    val tabWebViews = remember { mutableMapOf<String, WebView>() }
    var addressInput by remember { mutableStateOf(tabs.first().url) }

    val controller = remember { SafdowserWebViewController(context) }
    val activeWebView: WebView? = tabWebViews[activeTabId]

    fun resetTabs(startUrl: String) {
        tabWebViews.values.forEach { runCatching { it.destroy() } }
        tabWebViews.clear()
        val fresh = TabState(UUID.randomUUID().toString(), startUrl)
        tabs = listOf(fresh)
        activeTabId = fresh.id
        addressInput = startUrl
    }

    fun newTab() {
        val t = TabState(UUID.randomUUID().toString(), StartPage.URL)
        tabs = tabs + t
        activeTabId = t.id
        addressInput = t.url
    }

    fun closeTab(tab: TabState) {
        tabWebViews.remove(tab.id)?.let { runCatching { it.destroy() } }
        if (SettingsStore.clearOnTabClose) {
            // The closed tab's own data goes with it; cookies/cache are shared by
            // the whole engine, so the wipe covers them for every tab (see Settings).
            controller.wipeAllData(tabWebViews.values)
        }
        val remaining = tabs.filter { it.id != tab.id }
        if (remaining.isEmpty()) {
            val t = TabState(UUID.randomUUID().toString(), StartPage.URL)
            tabs = listOf(t)
            activeTabId = t.id
            addressInput = t.url
        } else {
            tabs = remaining
            if (activeTabId == tab.id) {
                activeTabId = remaining.last().id
                addressInput = remaining.last().url
            }
        }
    }

    /** Re-apply the live settings (JS / images) to every open WebView. */
    fun applySettingsToViews() {
        tabWebViews.values.forEach { wv ->
            runCatching {
                wv.settings.javaScriptEnabled = SettingsStore.jsEnabled
                wv.settings.loadsImagesAutomatically = SettingsStore.imagesEnabled
                wv.settings.blockNetworkImage = !SettingsStore.imagesEnabled
            }
        }
        activeWebView?.reload()
    }

    fun navigateTo(raw: String) {
        val trimmed = raw.trim()
        val target = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=${trimmed.replace(" ", "+")}"
        }
        activeTab.url = target
        activeTab.error = null
        addressInput = target
        activeWebView?.loadUrl(target)
    }

    // ---- Proxy (custom SOCKS5/HTTP) state ----------------------------------
    val proxyState by SafdowserVpnService.state.collectAsState()
    var customHost by remember { mutableStateOf("") }
    var customPort by remember { mutableStateOf("1080") }
    var customProto by remember { mutableStateOf("SOCKS5") }

    fun connectProxy(host: String, port: Int, proto: String, country: String, code: String) {
        WebViewProxyManager.applyProxy(host, port, proto) {
            val intent = Intent(context, SafdowserVpnService::class.java).apply {
                action = SafdowserVpnService.ACTION_CONNECT
                putExtra(SafdowserVpnService.EXTRA_COUNTRY, country)
                putExtra(SafdowserVpnService.EXTRA_CODE, code)
                putExtra(SafdowserVpnService.EXTRA_CITY, "")
                putExtra(SafdowserVpnService.EXTRA_IP, host)
                putExtra(SafdowserVpnService.EXTRA_PORT, port)
                putExtra(SafdowserVpnService.EXTRA_PROTO, proto)
            }
            context.startForegroundService(intent)
        }
    }

    fun disconnectProxy() {
        WebViewProxyManager.clearProxy()
        context.startService(Intent(context, SafdowserVpnService::class.java).apply {
            action = SafdowserVpnService.ACTION_DISCONNECT
        })
    }

    // ---- Real OpenVPN (VPN Gate) -------------------------------------------
    val ovpnState by OpenVpnController.state.collectAsState()
    val ovpnServer by OpenVpnController.activeServer.collectAsState()
    val vpnLog by OpenVpnController.logLines.collectAsState()
    val vpnError by OpenVpnController.lastError.collectAsState()
    var vpnServers by remember { mutableStateOf<List<VpnServer>>(emptyList()) }
    var fetchingServers by remember { mutableStateOf(false) }
    var showAllCountries by remember { mutableStateOf(false) }
    var exitIp by remember { mutableStateOf<String?>(null) }
    /** Exit IP captured while the VPN was off — used to prove the tunnel actually changed it. */
    var ipBeforeVpn by remember { mutableStateOf<String?>(null) }
    /** Auto-retry: when a tapped server fails, walk down the same-country list on its own. */
    var attemptQueue by remember { mutableStateOf<List<VpnServer>>(emptyList()) }
    var attemptIndex by remember { mutableIntStateOf(0) }
    var autoTrying by remember { mutableStateOf(false) }
    var showVpnLog by remember { mutableStateOf(false) }

    // ---- Ready IPs: free proxies the app itself tests on this phone ----------
    var readyProxies by remember { mutableStateOf<List<VerifiedProxy>>(emptyList()) }
    var testingProxies by remember { mutableStateOf(false) }
    var proxyTestNote by remember { mutableStateOf<String?>(null) }
    /** Exit IP measured THROUGH the active proxy — what websites will actually see. */
    var browserIp by remember { mutableStateOf<String?>(null) }
    var checkingBrowserIp by remember { mutableStateOf(false) }

    fun fetchReadyProxies() {
        if (testingProxies) return
        testingProxies = true
        proxyTestNote = "Fresh IPs la kar is phone par test ki ja rahi hain…"
        scope.launch {
            val found = ProxyListRepository.fetchVerified { n, t ->
                proxyTestNote = "Testing… $t IPs check hui, $n kaam ki mili"
            }
            readyProxies = found
            testingProxies = false
            proxyTestNote = if (found.isEmpty())
                "Koi IP jawab nahi de rahi abhi — thodi der baad phir try karo (free IPs jaldi mar jati hain)."
            else
                "${found.size} tested IPs mil gayi — koi si tap karke lagao."
        }
    }

    LaunchedEffect(ovpnState) {
        if (ovpnState == ConnectionState.CONNECTED) {
            exitIp = OpenVpnController.fetchExitIp()
        }
    }

    // Whenever a custom proxy becomes active, measure the exit IP THROUGH it and
    // show the verdict — "Active" alone proved nothing (dead proxies stayed silent).
    LaunchedEffect(proxyState.isConnected, proxyState.activeServer?.ipAddress, proxyState.activeServer?.port) {
        val srv = proxyState.activeServer
        if (proxyState.isConnected && srv != null) {
            checkingBrowserIp = true
            browserIp = OpenVpnController.fetchExitIpViaProxy(srv.ipAddress, srv.port, srv.protocol)
            checkingBrowserIp = false
        } else {
            browserIp = null
        }
    }

    var pendingServer by remember { mutableStateOf<VpnServer?>(null) }
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            pendingServer?.let { OpenVpnController.connect(context, it) }
        }
        pendingServer = null
    }

    fun beginAttempt(server: VpnServer) {
        val prepareIntent = VpnService.prepare(context)
        if (prepareIntent == null) {
            OpenVpnController.connect(context, server)
        } else {
            pendingServer = server
            vpnPermissionLauncher.launch(prepareIntent)
        }
    }

    fun onServerTapped(server: VpnServer) {
        // Queue: the tapped server, then the next best servers of the same country.
        // If one fails, the app moves to the next by itself (see the effects below).
        attemptQueue = (listOf(server) +
            vpnServers.filter { it.countryCode == server.countryCode && it.id != server.id }).take(4)
        attemptIndex = 0
        autoTrying = true
        beginAttempt(server)
    }

    // Auto-retry driver: success stops the queue; a drop moves to the next server.
    LaunchedEffect(ovpnState, autoTrying) {
        if (ovpnState == ConnectionState.CONNECTED) {
            autoTrying = false
        } else if (ovpnState == ConnectionState.DISCONNECTED && autoTrying) {
            if (attemptIndex < attemptQueue.size - 1) {
                attemptIndex++
                delay(800)
                if (autoTrying && attemptIndex < attemptQueue.size) {
                    beginAttempt(attemptQueue[attemptIndex])
                }
            } else {
                autoTrying = false
            }
        }
    }

    // Watchdog: a server stuck on "Connecting" for 45s counts as failed — dropping
    // it to DISCONNECTED hands control to the auto-retry effect above.
    LaunchedEffect(ovpnState, attemptIndex) {
        if (ovpnState == ConnectionState.CONNECTING) {
            delay(45_000)
            if (ovpnState == ConnectionState.CONNECTING) {
                OpenVpnController.disconnect(context)
            }
        }
    }

    fun fetchServers() {
        if (fetchingServers) return
        fetchingServers = true
        scope.launch {
            vpnServers = vpnRepo.fetchLiveFreeVpnGateServers()
            fetchingServers = false
        }
    }

    // ---- Sheets --------------------------------------------------------------
    var showProfileSheet by remember { mutableStateOf(false) }
    var showLocationSheet by remember { mutableStateOf(false) }
    var showVpnSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var dataWipedNote by remember { mutableStateOf<String?>(null) }

    val activePreset: GeoPreset =
        GeoPresets.all.firstOrNull { it.timezoneId == activeProfile.timezoneId } ?: GeoPresets.all.first()

    /** One selection drives timezone + GPS + language + VPN country together. */
    fun applyPreset(preset: GeoPreset) {
        val keepUrl = activeTab.url
        val updated = activeProfile.copy(
            timezoneId = preset.timezoneId,
            timezoneOffsetMinutes = preset.timezoneOffsetMinutes,
            latitude = preset.latitude,
            longitude = preset.longitude,
            language = preset.language,
            languages = listOf(preset.language, "en")
        )
        activeProfile = updated
        if (!updated.isIncognito) {
            profiles = profiles.map { if (it.id == updated.id) updated else it }
            profileRepo.saveProfiles(profiles)
        }
        controller.wipeSessionData()
        resetTabs(keepUrl)
    }

    LaunchedEffect(showVpnSheet) {
        if (showVpnSheet && vpnServers.isEmpty()) fetchServers()
        if (showVpnSheet) scope.launch {
            val now = OpenVpnController.fetchExitIp()
            exitIp = now
            if (ovpnState == ConnectionState.DISCONNECTED && now != null) ipBeforeVpn = now
        }
    }

    val vpnChipLabel = when {
        ovpnState == ConnectionState.CONNECTED -> ovpnServer?.countryCode ?: "VPN"
        ovpnState == ConnectionState.CONNECTING -> "VPN..."
        proxyState.isConnected -> proxyState.activeServer?.countryCode ?: "PROXY"
        else -> "Direct IP"
    }
    val vpnChipActive = ovpnState == ConnectionState.CONNECTED || proxyState.isConnected

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isIncognito) Color(0xFF1F122B) else MaterialTheme.colorScheme.surface)
                    .statusBarsPadding()
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = addressInput,
                        onValueChange = { addressInput = it },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Search or enter URL") },
                        leadingIcon = {
                            Icon(
                                if (isIncognito) Icons.Default.VisibilityOff else Icons.Default.Shield,
                                contentDescription = null,
                                tint = if (isIncognito) Color(0xFFC084FC) else MaterialTheme.colorScheme.primary
                            )
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { navigateTo(addressInput) }),
                        shape = RoundedCornerShape(24.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = {
                        isIncognito = !isIncognito
                        val keepUrl = activeTab.url
                        if (isIncognito) {
                            activeProfile = profileRepo.createIncognitoProfile(activeProfile)
                        } else {
                            controller.wipeSessionData()
                            activeProfile = profiles.first()
                        }
                        resetTabs(keepUrl)
                    }) {
                        Icon(
                            Icons.Default.VisibilityOff,
                            contentDescription = "Incognito",
                            tint = if (isIncognito) Color(0xFFC084FC) else Color.Gray
                        )
                    }
                }

                if (activeTab.progress in 1..99) {
                    LinearProgressIndicator(
                        progress = { activeTab.progress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .height(2.dp)
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatusChip(
                        label = activeProfile.name,
                        icon = Icons.Default.Person,
                        active = true,
                        onClick = { showProfileSheet = true },
                        modifier = Modifier.weight(1f)
                    )
                    StatusChip(
                        label = activePreset.label,
                        icon = Icons.Default.LocationOn,
                        active = true,
                        onClick = { showLocationSheet = true },
                        modifier = Modifier.weight(1.2f)
                    )
                    StatusChip(
                        label = vpnChipLabel,
                        icon = Icons.Default.VpnLock,
                        active = vpnChipActive,
                        onClick = { showVpnSheet = true },
                        modifier = Modifier.weight(0.9f)
                    )
                }

                // ---- Tab strip ----
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                ) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(tabs, key = { it.id }) { tab ->
                            TabChip(
                                tab = tab,
                                selected = tab.id == activeTabId,
                                onSelect = {
                                    activeTabId = tab.id
                                    addressInput = tab.url
                                },
                                onClose = { closeTab(tab) }
                            )
                        }
                    }
                    IconButton(onClick = { newTab() }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Add, contentDescription = "New tab", modifier = Modifier.size(18.dp))
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = false,
                    onClick = { activeWebView?.goBack() },
                    icon = { Icon(Icons.Default.ArrowBack, contentDescription = "Back") },
                    label = { Text("Back") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { activeWebView?.reload() },
                    icon = { Icon(Icons.Default.Refresh, contentDescription = "Reload") },
                    label = { Text("Reload") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navigateTo(StartPage.URL) },
                    icon = { Icon(Icons.Default.Fingerprint, contentDescription = "Identity") },
                    label = { Text("Identity") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { controller.wipeSessionData(); activeWebView?.reload() },
                    icon = { Icon(Icons.Default.DeleteSweep, contentDescription = "Wipe") },
                    label = { Text("Wipe") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { showSettingsSheet = true },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") }
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            val tab = activeTab
            key(tab.id, activeProfile.id) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = {
                        tabWebViews.getOrPut(tab.id) {
                            controller.createAndConfigure(
                                profile = activeProfile,
                                onUrlChanged = { url ->
                                    tab.url = url
                                    if (tab.id == activeTabId) addressInput = url
                                },
                                onProgressChanged = { p -> tab.progress = p },
                                onTitleChanged = { t -> tab.title = t },
                                onError = { e -> tab.error = e },
                                onIdentityProbe = { seen ->
                                    tab.spoofWarning = seen == "NOT_INJECTED" &&
                                        (tab.url.startsWith("http://") || tab.url.startsWith("https://"))
                                }
                            ).also { wv -> wv.loadUrl(tab.url) }
                        }
                    },
                    onRelease = { /* WebView stays alive in tabWebViews for tab switching */ }
                )
            }

            if (tab.spoofWarning) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF7F1D1D))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        "Warning: anti-detect is NOT active on this page — your real info may be visible. Try Reload.",
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
            }

            if (tab.error != null) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(20.dp)
                ) {
                    Text("Page could not be loaded", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(tab.error ?: "", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Spacer(Modifier.height(4.dp))
                    Text(tab.url, style = MaterialTheme.typography.bodySmall, color = Color.Gray, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        tab.error = null
                        activeWebView?.reload()
                    }) { Text("Retry") }
                }
            }
        }
    }

    if (showProfileSheet) {
        ModalBottomSheet(onDismissRequest = { showProfileSheet = false }) {
            Column(Modifier.padding(16.dp)) {
                Text("Anti-Detect Profiles", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                profiles.forEach { p ->
                    ListItem(
                        headlineContent = { Text(p.name) },
                        supportingContent = { Text("${p.timezoneId} · GPS ${p.latitude}, ${p.longitude}") },
                        leadingContent = {
                            RadioButton(selected = activeProfile.id == p.id, onClick = {
                                val keepUrl = activeTab.url
                                controller.wipeSessionData()
                                activeProfile = p
                                isIncognito = false
                                showProfileSheet = false
                                resetTabs(keepUrl)
                            })
                        },
                        modifier = Modifier.clickable {
                            val keepUrl = activeTab.url
                            controller.wipeSessionData()
                            activeProfile = p
                            isIncognito = false
                            showProfileSheet = false
                            resetTabs(keepUrl)
                        }
                    )
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showLocationSheet) {
        ModalBottomSheet(onDismissRequest = { showLocationSheet = false }) {
            Column(Modifier.padding(16.dp)) {
                Text("Location & Timezone", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    "One tap sets everything together: timezone, fake GPS, language — and the VPN server list for the same country. Websites only ever see these, never your device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                    items(GeoPresets.all) { preset ->
                        val selected = preset.timezoneId == activeProfile.timezoneId
                        ListItem(
                            headlineContent = { Text(preset.label) },
                            supportingContent = { Text("${preset.timezoneId} · ${preset.latitude}, ${preset.longitude}") },
                            leadingContent = {
                                RadioButton(selected = selected, onClick = {
                                    applyPreset(preset)
                                    showLocationSheet = false
                                })
                            },
                            modifier = Modifier.clickable {
                                applyPreset(preset)
                                showLocationSheet = false
                            }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (showVpnSheet) {
        ModalBottomSheet(onDismissRequest = { showVpnSheet = false }) {
            Column(Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("VPN & Proxy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Row {
                        TextButton(onClick = { fetchServers() }) {
                            Text(if (fetchingServers) "Fetching..." else "Fetch VPN Gate")
                        }
                        if (ovpnState == ConnectionState.CONNECTED || ovpnState == ConnectionState.CONNECTING) {
                            TextButton(onClick = {
                                autoTrying = false
                                OpenVpnController.disconnect(context)
                            }) {
                                Text("Disconnect", color = Color(0xFFF87171))
                            }
                        }
                    }
                }

                val statusText = when (ovpnState) {
                    ConnectionState.CONNECTED ->
                        "VPN Connected · ${ovpnServer?.countryName ?: ""} · ${ovpnServer?.ipAddress ?: ""}"
                    ConnectionState.CONNECTING -> "VPN Connecting... (free servers can take 10-30s)"
                    else -> proxyState.statusText
                }
                Text(statusText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                if (proxyState.isConnected && ovpnState != ConnectionState.CONNECTED) {
                    Text(
                        "Phone ki asal IP: ${exitIp ?: "…"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        modifier = Modifier.clickable { scope.launch { exitIp = OpenVpnController.fetchExitIp() } }
                    )
                    when {
                        checkingBrowserIp -> Text(
                            "Browser ki IP check ho rahi hai (proxy ke zariye)…",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        browserIp != null -> Text(
                            "Browser ki IP (websites ko ye dikhe gi): $browserIp",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF22C55E),
                            fontWeight = FontWeight.Bold
                        )
                        else -> Text(
                            "YE PROXY JAWAB NAHI DE RAHI — browser ki IP check fail. Doosri IP lagao (neeche Ready IPs se tested wali chuno).",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFF87171),
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Text(
                        "Exit IP right now: ${exitIp ?: "tap refresh"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        modifier = Modifier.clickable { scope.launch { exitIp = OpenVpnController.fetchExitIp() } }
                    )
                }
                if (ovpnState == ConnectionState.CONNECTED && exitIp != null &&
                    ipBeforeVpn != null && exitIp == ipBeforeVpn
                ) {
                    Text(
                        "WARNING: IP did not change — this server is not carrying your traffic. Disconnect and pick another server.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFF87171),
                        fontWeight = FontWeight.Bold
                    )
                }
                if (autoTrying && attemptQueue.size > 1) {
                    Text(
                        "Trying server ${attemptIndex + 1} of ${attemptQueue.size} — agar ek fail ho to app khud agla try kare gi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                if (ovpnState == ConnectionState.DISCONNECTED && vpnError != null) {
                    Text(
                        "Last error: $vpnError",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFF87171),
                        fontWeight = FontWeight.Bold
                    )
                }
                if (vpnLog.isNotEmpty()) {
                    TextButton(onClick = { showVpnLog = !showVpnLog }) {
                        Text(if (showVpnLog) "Hide connection details" else "Show connection details (masla kya hai)")
                    }
                    if (showVpnLog) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 170.dp)
                                .verticalScroll(rememberScrollState())
                                .background(Color(0xFF111827))
                                .padding(8.dp)
                        ) {
                            vpnLog.forEach { line ->
                                Text(line, style = MaterialTheme.typography.bodySmall, color = Color(0xFFD1D5DB), fontSize = 10.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (showAllCountries) "Servers: all countries" else "Servers for ${activePreset.label}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    FilterChip(
                        selected = showAllCountries,
                        onClick = { showAllCountries = !showAllCountries },
                        label = { Text("All countries") }
                    )
                }
                val visibleServers = if (showAllCountries) vpnServers
                    else vpnServers.filter { it.countryCode == activePreset.countryCode }
                if (visibleServers.isEmpty()) {
                    Text(
                        if (fetchingServers) "Fetching live servers..."
                        else "No live servers for this country right now. Try Fetch again or switch on All countries.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 240.dp)) {
                        items(visibleServers, key = { it.id }) { srv ->
                            val isActive = ovpnServer?.id == srv.id &&
                                (ovpnState == ConnectionState.CONNECTED || ovpnState == ConnectionState.CONNECTING)
                            ListItem(
                                headlineContent = { Text("${srv.countryName} — ${srv.ipAddress}") },
                                supportingContent = {
                                    Text(
                                        if (isActive && ovpnState == ConnectionState.CONNECTING) "Connecting… (tap Disconnect above to stop)"
                                        else if (isActive) "Connected · tap Disconnect above to stop"
                                        else "OpenVPN · ${srv.pingMs}ms · score ${srv.score}" +
                                            (if (srv.uptimeMs > 0) " · ${srv.uptimeMs / 86_400_000}d up" else "") +
                                            " · tap to connect"
                                    )
                                },
                                trailingContent = {
                                    if (isActive && ovpnState == ConnectionState.CONNECTED) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = "Connected", tint = Color(0xFF22C55E))
                                    }
                                },
                                modifier = Modifier.clickable(enabled = !isActive) { onServerTapped(srv) }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                Text("Ready IPs — tested, kaam karne wali", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Free IPs aksar mari hui hoti hain. Ye wali app khud is phone par test karke deti hai — jo IP asal mein jawab de, sirf wohi yahan ati hai, us ke bahar wale (exit) IP ke sath. Tap karo to proxy lag jayegi.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                Button(
                    onClick = { fetchReadyProxies() },
                    enabled = !testingProxies,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (testingProxies) "IPs test ho rahi hain…" else "Fetch & Test IPs") }
                proxyTestNote?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                }
                readyProxies.forEach { vp ->
                    ListItem(
                        headlineContent = { Text("${vp.country} — bahar ki IP: ${vp.exitIp}") },
                        supportingContent = { Text("${vp.type} ${vp.host}:${vp.port} · ${vp.latencyMs}ms · tap karke lagao") },
                        modifier = Modifier.clickable {
                            connectProxy(vp.host, vp.port, vp.type, vp.country, vp.countryCode.ifBlank { "PX" })
                        }
                    )
                }

                Spacer(Modifier.height(12.dp))
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                Text("Custom IP (Proxy) — apni marzi ki IP lagao", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Kisi bhi country ki apni IP lagani ho to neeche wali sites se us country ki free IP lo (IP:Port copy karo), yahan paste karke Apply kar do. Apply ke baad upar app khud check karke batayegi ke ye IP chal rahi hai ya nahi. Misal: USA ki IP ke liye 'Free USA IPs' kholo, wahan United States wali koi IP chuno.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        showVpnSheet = false
                        navigateTo("https://hidemy.name/en/proxy-list/?country=US")
                    }) { Text("Free USA IPs") }
                    TextButton(onClick = {
                        showVpnSheet = false
                        navigateTo("https://free-proxy-list.net/")
                    }) { Text("Free IPs — all countries") }
                }
                if (proxyState.isConnected) {
                    TextButton(onClick = { disconnectProxy() }) { Text("Disconnect proxy", color = Color(0xFFF87171)) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = customHost,
                        onValueChange = { customHost = it },
                        label = { Text("IP ya IP:Port paste karo") },
                        singleLine = true,
                        modifier = Modifier.weight(1.4f)
                    )
                    OutlinedTextField(
                        value = customPort,
                        onValueChange = { customPort = it },
                        label = { Text("Port") },
                        singleLine = true,
                        modifier = Modifier.weight(0.7f)
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = customProto == "SOCKS5", onClick = { customProto = "SOCKS5" }, label = { Text("SOCKS5") })
                        FilterChip(selected = customProto == "HTTP", onClick = { customProto = "HTTP" }, label = { Text("HTTP") })
                    }
                    Button(
                        enabled = customHost.isNotBlank(),
                        onClick = {
                            // Accept a pasted "1.2.3.4:8080" in the IP box too.
                            val raw = customHost.trim()
                            val hostPart: String
                            val portPart: Int
                            if (raw.contains(":")) {
                                val pieces = raw.split(":")
                                hostPart = pieces[0].trim()
                                portPart = pieces.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
                            } else {
                                hostPart = raw
                                portPart = customPort.toIntOrNull() ?: 0
                            }
                            if (hostPart.isNotBlank() && portPart in 1..65535) {
                                customHost = hostPart
                                customPort = portPart.toString()
                                connectProxy(hostPart, portPart, customProto, "Custom", "PX")
                                // Sheet stays open so the through-proxy check result is visible.
                            }
                        }
                    ) { Text("Apply Proxy") }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
    if (showSettingsSheet) {
        ModalBottomSheet(onDismissRequest = { showSettingsSheet = false }) {
            Column(Modifier.padding(16.dp)) {
                Text("Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                SettingToggleRow(
                    title = "JavaScript",
                    note = "Band karne se pehchan chhupana (spoofing) bhi band ho jayega — aam tor par ON rakho.",
                    checked = SettingsStore.jsEnabled,
                    onChange = { SettingsStore.setJs(it); applySettingsToViews() }
                )
                SettingToggleRow(
                    title = "Tasaveer (Images)",
                    note = "Band karne se pages tez khulenge aur data bachega.",
                    checked = SettingsStore.imagesEnabled,
                    onChange = { SettingsStore.setImages(it); applySettingsToViews() }
                )
                SettingToggleRow(
                    title = "Ads & Trackers block",
                    note = "Chrome extensions is engine mein nahi chalti, is liye mashhoor ad networks yahin built-in block kar diye hain.",
                    checked = SettingsStore.adBlockEnabled,
                    onChange = { SettingsStore.setAdBlock(it) }
                )
                SettingToggleRow(
                    title = "Tab band = data auto delete",
                    note = "Koi tab band karte hi cookies, cache aur site data saaf. Note: browser engine ye data sab tabs mein share karta hai, to safai sab ke liye hoti hai.",
                    checked = SettingsStore.clearOnTabClose,
                    onChange = { SettingsStore.setClearOnTabClose(it) }
                )
                Spacer(Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(Modifier.height(10.dp))
                Text("Extensions ke baray mein", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Chrome wali extensions (Urban VPN, Green VPN waghera) Android par khud Chrome mein bhi nahi chalti — is engine (WebView) mein extension chalane ka system hi mojood nahi. Un VPNs ka faida (doosri country ki IP) tumhein is app ke Ready IPs aur VPN servers se milta hai — app khud test karke working IP deti hai.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                Spacer(Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        controller.wipeAllData(tabWebViews.values)
                        dataWipedNote = "Ho gaya — cookies, cache, history, sab saaf kar diya."
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C)),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Abhi saara browsing data delete karo") }
                dataWipedNote?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = Color(0xFF22C55E))
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    note: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
            Text(note, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun TabChip(
    tab: TabState,
    selected: Boolean,
    onSelect: () -> Unit,
    onClose: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onSelect)
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(
            tab.title.ifBlank { "Tab" },
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 90.dp),
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.width(4.dp))
        Icon(
            Icons.Default.Close,
            contentDescription = "Close tab",
            modifier = Modifier
                .size(13.dp)
                .clickable(onClick = onClose),
            tint = Color.Gray
        )
    }
}

@Composable
private fun StatusChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) MaterialTheme.colorScheme.surfaceVariant else Color(0xFF1F2937))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = if (active) MaterialTheme.colorScheme.primary else Color.Gray
        )
        Spacer(Modifier.width(4.dp))
        Text(
            label,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
