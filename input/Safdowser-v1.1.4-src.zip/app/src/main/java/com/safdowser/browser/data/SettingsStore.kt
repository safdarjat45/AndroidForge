package com.safdowser.browser.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** User settings: persisted in SharedPreferences, readable from the WebView layer. */
object SettingsStore {
    var jsEnabled by mutableStateOf(true)
        private set
    var imagesEnabled by mutableStateOf(true)
        private set
    var adBlockEnabled by mutableStateOf(false)
        private set
    /** Closing any tab wipes cookies/cache/site storage (WebView shares them across tabs). */
    var clearOnTabClose by mutableStateOf(true)
        private set

    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.getSharedPreferences("safdowser_settings", Context.MODE_PRIVATE)
        prefs = p
        jsEnabled = p.getBoolean("js", true)
        imagesEnabled = p.getBoolean("images", true)
        adBlockEnabled = p.getBoolean("adblock", false)
        clearOnTabClose = p.getBoolean("clear_on_close", true)
    }

    fun setJs(v: Boolean) { jsEnabled = v; prefs?.edit()?.putBoolean("js", v)?.apply() }
    fun setImages(v: Boolean) { imagesEnabled = v; prefs?.edit()?.putBoolean("images", v)?.apply() }
    fun setAdBlock(v: Boolean) { adBlockEnabled = v; prefs?.edit()?.putBoolean("adblock", v)?.apply() }
    fun updateClearOnTabClose(v: Boolean) { clearOnTabClose = v; prefs?.edit()?.putBoolean("clear_on_close", v)?.apply() }
}
