package com.safdowser.browser.browser

import com.safdowser.browser.model.BrowserProfile
import org.json.JSONObject

/**
 * Safdowser's own built-in start / identity page.
 *
 * Served locally by the WebView client (no external website involved). It shows —
 * in simple words — exactly what websites see of this browser: the exit IP (fetched
 * by the page itself, through the same network path as any website), the timezone,
 * location and user agent the page observes, and whether WebRTC is blocked.
 * This replaces the old external "Leak Test" site.
 */
object StartPage {
    const val URL = "https://start.safdowser.local/"
    const val HOST = "start.safdowser.local"

    fun html(profile: BrowserProfile): String {
        val name = JSONObject.quote(profile.name)
        val tz = JSONObject.quote(profile.timezoneId)
        val lat = profile.latitude
        val lon = profile.longitude
        return """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Safdowser</title>
<style>
  body { font-family: sans-serif; margin: 0; padding: 20px; background: #0f172a; color: #e2e8f0; }
  h1 { font-size: 22px; margin: 4px 0 2px; }
  .sub { color: #94a3b8; font-size: 13px; margin-bottom: 16px; }
  .card { background: #1e293b; border-radius: 14px; padding: 14px 16px; margin-bottom: 12px; }
  .label { color: #94a3b8; font-size: 12px; text-transform: uppercase; letter-spacing: .05em; }
  .value { font-size: 17px; font-weight: 600; margin-top: 3px; word-break: break-all; }
  .note { color: #94a3b8; font-size: 12px; margin-top: 3px; }
  .ok { color: #4ade80; }
  .bad { color: #f87171; }
  button { background: #334155; color: #e2e8f0; border: 0; border-radius: 10px; padding: 9px 14px; font-size: 14px; }
  a { color: #7dd3fc; }
</style>
</head>
<body>
  <h1>🛡️ Safdowser</h1>
  <div class="sub">Ye is browser ki apni pehchan hai — jo websites ko dikhti hai. Ye tumhare phone ki pehchan nahi hai.</div>

  <div class="card">
    <div class="label">Profile</div>
    <div class="value" id="profileName"></div>
    <div class="note">Location jo tum ne chuni hai — timezone, GPS aur zuban isi ke hisaab se set hain.</div>
  </div>

  <div class="card">
    <div class="label">IP address jo websites ko dikhta hai</div>
    <div class="value" id="exitIp">check kar raha hai…</div>
    <div class="note">VPN on ho to yahan VPN server ki IP ani chahiye, tumhari asal IP nahi.</div>
  </div>

  <div class="card">
    <div class="label">Timezone jo website ko dikhta hai</div>
    <div class="value" id="tzSeen">…</div>
    <div class="note" id="clockNow"></div>
  </div>

  <div class="card">
    <div class="label">Location (GPS) jo website ko milta hai</div>
    <div class="value" id="geoSeen">check kar raha hai…</div>
    <div class="note">Ye nakli (fake) location hai — phone ki asal location app ke paas hai hi nahi.</div>
  </div>

  <div class="card">
    <div class="label">WebRTC (IP leak ka ek purana rasta)</div>
    <div class="value" id="rtcSeen">…</div>
  </div>

  <div class="card">
    <div class="label">Browser ki pehchan (User Agent)</div>
    <div class="value" id="uaSeen" style="font-size:13px; font-weight:400"></div>
  </div>

  <button onclick="location.reload()">Dobara check karo</button>
  <p class="note" style="margin-top:14px">Koi website kholna ho to upar address bar mein us ka naam ya address likho.</p>

<script>
  document.getElementById('profileName').textContent = $name + ' · ' + $tz;
  document.getElementById('tzSeen').textContent =
    Intl.DateTimeFormat().resolvedOptions().timeZone + ' (offset ' + new Date().getTimezoneOffset() + ')';
  setInterval(function() {
    document.getElementById('clockNow').textContent = 'Is timezone ka waqt abhi: ' + new Date().toString();
  }, 1000);
  document.getElementById('uaSeen').textContent = navigator.userAgent;

  fetch('https://api.ipify.org?format=json').then(r => r.json()).then(j => {
    document.getElementById('exitIp').textContent = j.ip;
  }).catch(e => {
    fetch('https://icanhazip.com').then(r => r.text()).then(t => {
      document.getElementById('exitIp').textContent = t.trim();
    }).catch(e2 => {
      document.getElementById('exitIp').innerHTML = '<span class="bad">check nahi ho saka (internet?)</span>';
    });
  });

  try {
    var pc = new RTCPeerConnection();
    document.getElementById('rtcSeen').innerHTML = '<span class="bad">WebRTC khula hai — leak ho sakta hai</span>';
  } catch (e) {
    document.getElementById('rtcSeen').innerHTML = '<span class="ok">Band hai ✓ — is raste se IP leak nahi ho sakta</span>';
  }

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(pos) {
      document.getElementById('geoSeen').textContent =
        pos.coords.latitude.toFixed(4) + ', ' + pos.coords.longitude.toFixed(4) + ' (nakli)';
    }, function(err) {
      document.getElementById('geoSeen').textContent = 'website ko location nahi mili';
    }, { timeout: 4000 });
  }
  // Profile coordinates for reference: $lat, $lon
</script>
</body>
</html>
        """.trimIndent()
    }
}
