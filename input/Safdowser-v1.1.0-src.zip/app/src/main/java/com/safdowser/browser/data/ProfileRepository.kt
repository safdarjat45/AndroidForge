package com.safdowser.browser.data

import android.content.Context
import com.safdowser.browser.model.BrowserProfile
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

class ProfileRepository(context: Context) {
    private val prefs = context.getSharedPreferences("safdowser_profiles", Context.MODE_PRIVATE)

    fun loadProfiles(): List<BrowserProfile> {
        val raw = prefs.getString("profiles_json", null)
        if (raw.isNullOrBlank()) {
            val defaults = defaultProfiles()
            saveProfiles(defaults)
            return defaults
        }
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { idx -> fromJson(arr.getJSONObject(idx)) }
        }.getOrElse {
            val defaults = defaultProfiles()
            saveProfiles(defaults)
            defaults
        }
    }

    fun saveProfiles(profiles: List<BrowserProfile>) {
        val arr = JSONArray()
        profiles.filterNot { it.isIncognito }.forEach { arr.put(toJson(it)) }
        prefs.edit().putString("profiles_json", arr.toString()).apply()
    }

    fun createIncognitoProfile(base: BrowserProfile): BrowserProfile {
        return base.copy(
            id = "incognito-${System.currentTimeMillis()}",
            name = "Incognito (${base.name})",
            noiseSeed = Random.nextInt(1000, 99999),
            isIncognito = true
        )
    }

    private fun defaultProfiles(): List<BrowserProfile> = listOf(
        BrowserProfile(
            id = "profile-us-ny",
            name = "US East (New York)",
            timezoneId = "America/New_York",
            timezoneOffsetMinutes = 300,
            latitude = 40.7128,
            longitude = -74.0060,
            language = "en-US",
            languages = listOf("en-US", "en"),
            userAgent = "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
            webglVendor = "Google Inc. (ARM)",
            webglRenderer = "ANGLE (ARM, Mali-G715, OpenGL ES 3.2)",
            noiseSeed = 14823,
            vpnServerId = "us-ny-1"
        ),
        BrowserProfile(
            id = "profile-uk-lon",
            name = "UK (London)",
            timezoneId = "Europe/London",
            timezoneOffsetMinutes = 0,
            latitude = 51.5074,
            longitude = -0.1278,
            language = "en-GB",
            languages = listOf("en-GB", "en"),
            userAgent = "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36",
            webglVendor = "Qualcomm",
            webglRenderer = "Adreno (TM) 740",
            noiseSeed = 58391,
            vpnServerId = "uk-lon-1"
        ),
        BrowserProfile(
            id = "profile-jp-tok",
            name = "Japan (Tokyo)",
            timezoneId = "Asia/Tokyo",
            timezoneOffsetMinutes = -540,
            latitude = 35.6762,
            longitude = 139.6503,
            language = "ja-JP",
            languages = listOf("ja-JP", "ja", "en-US"),
            userAgent = "Mozilla/5.0 (Linux; Android 14; SO-51D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
            webglVendor = "Qualcomm",
            webglRenderer = "Adreno (TM) 730",
            noiseSeed = 90412,
            vpnServerId = "jp-tok-1"
        )
    )

    private fun toJson(p: BrowserProfile): JSONObject = JSONObject().apply {
        put("id", p.id)
        put("name", p.name)
        put("timezoneId", p.timezoneId)
        put("timezoneOffsetMinutes", p.timezoneOffsetMinutes)
        put("latitude", p.latitude)
        put("longitude", p.longitude)
        put("accuracyMeters", p.accuracyMeters.toDouble())
        put("language", p.language)
        put("languages", JSONArray(p.languages))
        put("userAgent", p.userAgent)
        put("platform", p.platform)
        put("hardwareConcurrency", p.hardwareConcurrency)
        put("deviceMemory", p.deviceMemory)
        put("screenWidth", p.screenWidth)
        put("screenHeight", p.screenHeight)
        put("webglVendor", p.webglVendor)
        put("webglRenderer", p.webglRenderer)
        put("noiseSeed", p.noiseSeed)
        put("vpnServerId", p.vpnServerId)
        put("customProxyHost", p.customProxyHost)
        put("customProxyPort", p.customProxyPort)
        put("blockWebRtc", p.blockWebRtc)
    }

    private fun fromJson(o: JSONObject): BrowserProfile {
        val langsArr = o.optJSONArray("languages")
        val langs = if (langsArr != null) {
            (0 until langsArr.length()).map { langsArr.getString(it) }
        } else {
            listOf(o.optString("language", "en-US"))
        }
        return BrowserProfile(
            id = o.getString("id"),
            name = o.getString("name"),
            timezoneId = o.getString("timezoneId"),
            timezoneOffsetMinutes = o.getInt("timezoneOffsetMinutes"),
            latitude = o.getDouble("latitude"),
            longitude = o.getDouble("longitude"),
            accuracyMeters = o.optDouble("accuracyMeters", 15.0).toFloat(),
            language = o.optString("language", "en-US"),
            languages = langs,
            userAgent = o.getString("userAgent"),
            platform = o.optString("platform", "Linux armv81"),
            hardwareConcurrency = o.optInt("hardwareConcurrency", 8),
            deviceMemory = o.optInt("deviceMemory", 8),
            screenWidth = o.optInt("screenWidth", 412),
            screenHeight = o.optInt("screenHeight", 915),
            webglVendor = o.optString("webglVendor", "Qualcomm"),
            webglRenderer = o.optString("webglRenderer", "Adreno (TM) 740"),
            noiseSeed = o.optInt("noiseSeed", 4219),
            vpnServerId = o.optString("vpnServerId", "us-ny-1"),
            customProxyHost = o.optString("customProxyHost", ""),
            customProxyPort = o.optInt("customProxyPort", 0),
            blockWebRtc = o.optBoolean("blockWebRtc", true),
            isIncognito = false
        )
    }
}
