package com.safdowser.browser.vpn

import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import java.util.concurrent.Executor

object WebViewProxyManager {

    fun applyProxy(host: String, port: Int, protocol: String = "SOCKS5", onDone: (Boolean) -> Unit = {}) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            onDone(false)
            return
        }
        val executor = Executor { it.run() }
        if (host.isBlank() || port <= 0) {
            ProxyController.getInstance().clearProxyOverride(executor) { onDone(true) }
            return
        }
        val scheme = if (protocol.equals("HTTP", ignoreCase = true)) "http" else "socks5"
        val config = ProxyConfig.Builder()
            .addProxyRule("$scheme://$host:$port")
            .build()
        ProxyController.getInstance().setProxyOverride(config, executor) { onDone(true) }
    }

    fun clearProxy(onDone: () -> Unit = {}) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            onDone()
            return
        }
        val executor = Executor { it.run() }
        ProxyController.getInstance().clearProxyOverride(executor, onDone)
    }
}
