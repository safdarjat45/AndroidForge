package com.safdowser.browser.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import com.safdowser.browser.MainActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VpnConnectionState(
    val isConnected: Boolean = false,
    val activeServer: VpnServer? = null,
    val statusText: String = "Direct (No Proxy)"
)

/**
 * Foreground service tracking Safdowser proxy/VPN state.
 * Note: WebView traffic is routed via WebViewProxyManager (ProxyController) so
 * browsing never blackholes without a native tun2socks binary.
 */
class SafdowserVpnService : VpnService() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> {
                _state.value = VpnConnectionState(
                    isConnected = false,
                    activeServer = null,
                    statusText = "Direct (No Proxy)"
                )
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_CONNECT -> {
                val country = intent.getStringExtra(EXTRA_COUNTRY) ?: "Custom Proxy"
                val ip = intent.getStringExtra(EXTRA_IP) ?: ""
                val port = intent.getIntExtra(EXTRA_PORT, 1080)
                val code = intent.getStringExtra(EXTRA_CODE) ?: "PX"
                val city = intent.getStringExtra(EXTRA_CITY) ?: ""
                val proto = intent.getStringExtra(EXTRA_PROTO) ?: "SOCKS5"
                val server = VpnServer("active", country, code, city, ip, port, proto)
                startForeground(NOTIFICATION_ID, buildNotification(server))
                _state.value = VpnConnectionState(
                    isConnected = true,
                    activeServer = server,
                    statusText = "Active · $proto ${server.ipAddress}:${server.port}"
                )
            }
        }
        return START_STICKY
    }

    private fun buildNotification(server: VpnServer): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Safdowser Proxy & VPN",
            NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)

        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Safdowser Routing Active")
            .setContentText("${server.protocol}: ${server.ipAddress}:${server.port}")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_CONNECT = "com.safdowser.browser.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.safdowser.browser.vpn.DISCONNECT"
        const val EXTRA_COUNTRY = "extra_country"
        const val EXTRA_CODE = "extra_code"
        const val EXTRA_CITY = "extra_city"
        const val EXTRA_IP = "extra_ip"
        const val EXTRA_PORT = "extra_port"
        const val EXTRA_PROTO = "extra_proto"
        private const val CHANNEL_ID = "safdowser_vpn_channel"
        private const val NOTIFICATION_ID = 7001

        private val _state = MutableStateFlow(VpnConnectionState())
        val state: StateFlow<VpnConnectionState> = _state.asStateFlow()
    }
}
