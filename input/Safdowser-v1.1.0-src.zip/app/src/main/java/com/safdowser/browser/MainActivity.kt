package com.safdowser.browser

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.safdowser.browser.ui.SafdowserApp
import com.safdowser.browser.ui.theme.SafdowserTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SafdowserTheme {
                SafdowserApp()
            }
        }
    }
}
