package com.safdowser.browser.vpn

import android.content.Context
import com.tim.basevpn.state.ConnectionState
import com.tim.openvpn.configuration.OpenVPNConfig
import com.tim.openvpn.connection.OpenVPNVpnConnection
import com.tim.openvpn.service.OpenVPNService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Real OpenVPN tunnel control (VPN Gate servers), powered by the OpenVPN 3 core.
 * The tunnel is device-wide: while it is up, no traffic can leak outside it.
 */
object OpenVpnController {

    private val _state = MutableStateFlow(ConnectionState.DISCONNECTED)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private val _activeServer = MutableStateFlow<VpnServer?>(null)
    val activeServer: StateFlow<VpnServer?> = _activeServer.asStateFlow()

    @Volatile
    private var connection: OpenVPNVpnConnection? = null

    /** Start observing tunnel state. Safe to call repeatedly. */
    fun attach(context: Context) {
        if (connection == null) {
            synchronized(this) {
                if (connection == null) {
                    connection = OpenVPNVpnConnection(context.applicationContext) { newState ->
                        _state.value = newState
                        if (newState == ConnectionState.DISCONNECTED) {
                            _activeServer.value = null
                        }
                    }
                }
            }
        }
        runCatching { connection?.attachListener() }
    }

    fun connect(context: Context, server: VpnServer) {
        _activeServer.value = server
        _state.value = ConnectionState.CONNECTING
        val config = OpenVPNConfig(
            name = "Safdowser ${server.countryName} ${server.ipAddress}",
            configuration = sanitizeOvpnConfig(server.ovpnConfig)
        )
        OpenVPNService.startService(context.applicationContext, config)
        attach(context)
    }

    fun disconnect(context: Context) {
        runCatching { OpenVPNService.stopService(context.applicationContext) }
        _activeServer.value = null
        _state.value = ConnectionState.DISCONNECTED
    }

    val isConnected: Boolean
        get() = _state.value == ConnectionState.CONNECTED

    /** Fetches the public exit IP as seen by websites right now (goes through the tunnel when it is up). */
    suspend fun fetchExitIp(): String? = withContext(Dispatchers.IO) {
        val endpoints = listOf("https://api.ipify.org", "https://icanhazip.com")
        for (endpoint in endpoints) {
            val ip = runCatching {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                conn.inputStream.bufferedReader().use { it.readText() }.trim()
            }.getOrNull()
            if (!ip.isNullOrBlank() && ip.length <= 45) return@withContext ip
        }
        null
    }
}
