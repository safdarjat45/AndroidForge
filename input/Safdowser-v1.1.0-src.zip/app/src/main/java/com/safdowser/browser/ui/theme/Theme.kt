package com.safdowser.browser.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SafdowserColors = darkColorScheme(
    primary = Color(0xFF38BDF8),
    onPrimary = Color(0xFF06202E),
    secondary = Color(0xFF34D399),
    tertiary = Color(0xFFA78BFA),
    background = Color(0xFF0B1120),
    surface = Color(0xFF111827),
    surfaceVariant = Color(0xFF1E293B),
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9)
)

@Composable
fun SafdowserTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SafdowserColors,
        content = content
    )
}
