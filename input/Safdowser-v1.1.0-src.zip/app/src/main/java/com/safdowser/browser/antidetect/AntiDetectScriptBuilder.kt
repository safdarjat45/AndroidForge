package com.safdowser.browser.antidetect

import com.safdowser.browser.model.BrowserProfile
import org.json.JSONArray
import org.json.JSONObject

/**
 * Generates an anti-detect JavaScript payload injected at document-start
 * via WebViewCompat.addDocumentStartJavaScript before any page script runs.
 */
object AntiDetectScriptBuilder {

    fun build(profile: BrowserProfile): String {
        val tzId = JSONObject.quote(profile.timezoneId)
        val lang = JSONObject.quote(profile.language)
        val langsJson = JSONArray(profile.languages).toString()
        val ua = JSONObject.quote(profile.userAgent)
        val platform = JSONObject.quote(profile.platform)
        val webglVendor = JSONObject.quote(profile.webglVendor)
        val webglRenderer = JSONObject.quote(profile.webglRenderer)

        return """
        (function() {
            'use strict';
            if (window.__safdowserInjected) return;
            Object.defineProperty(window, '__safdowserInjected', { value: true, enumerable: false });

            const SPOOF_TZ = $tzId;
            const SPOOF_OFFSET_MIN = ${profile.timezoneOffsetMinutes};
            const SPOOF_LAT = ${profile.latitude};
            const SPOOF_LON = ${profile.longitude};
            const SPOOF_ACC = ${profile.accuracyMeters};
            const SPOOF_LANG = $lang;
            const SPOOF_LANGS = $langsJson;
            const SPOOF_UA = $ua;
            const SPOOF_PLATFORM = $platform;
            const SPOOF_CORES = ${profile.hardwareConcurrency};
            const SPOOF_MEM = ${profile.deviceMemory};
            const SPOOF_W = ${profile.screenWidth};
            const SPOOF_H = ${profile.screenHeight};
            const SPOOF_WEBGL_VENDOR = $webglVendor;
            const SPOOF_WEBGL_RENDERER = $webglRenderer;
            const NOISE_SEED = ${profile.noiseSeed};
            const BLOCK_WEBRTC = ${profile.blockWebRtc};

            // 1. Timezone Spoofing (Intl.DateTimeFormat & Date methods)
            const OrigDateTimeFormat = Intl.DateTimeFormat;
            Intl.DateTimeFormat = function(locales, options) {
                const opts = Object.assign({}, options || {});
                if (!opts.timeZone) {
                    opts.timeZone = SPOOF_TZ;
                }
                return new OrigDateTimeFormat(locales || SPOOF_LANG, opts);
            };
            Intl.DateTimeFormat.prototype = OrigDateTimeFormat.prototype;
            Intl.DateTimeFormat.supportedLocalesOf = OrigDateTimeFormat.supportedLocalesOf;

            const origResolvedOptions = OrigDateTimeFormat.prototype.resolvedOptions;
            OrigDateTimeFormat.prototype.resolvedOptions = function() {
                const res = origResolvedOptions.apply(this, arguments);
                res.timeZone = SPOOF_TZ;
                return res;
            };

            Date.prototype.getTimezoneOffset = function() {
                return SPOOF_OFFSET_MIN;
            };

            const formatSpoofed = (date, opts) => {
                return new OrigDateTimeFormat('en-US', Object.assign({ timeZone: SPOOF_TZ }, opts)).format(date);
            };

            Date.prototype.toString = function() {
                const parts = formatSpoofed(this, {
                    weekday: 'short', month: 'short', day: '2-digit', year: 'numeric',
                    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
                    timeZoneName: 'long'
                });
                const sign = SPOOF_OFFSET_MIN <= 0 ? '+' : '-';
                const absMin = Math.abs(SPOOF_OFFSET_MIN);
                const hh = String(Math.floor(absMin / 60)).padStart(2, '0');
                const mm = String(absMin % 60).padStart(2, '0');
                return parts + ' GMT' + sign + hh + mm;
            };

            Date.prototype.toTimeString = function() {
                return formatSpoofed(this, {
                    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
                    timeZoneName: 'long'
                });
            };

            Date.prototype.toDateString = function() {
                return formatSpoofed(this, {
                    weekday: 'short', month: 'short', day: '2-digit', year: 'numeric'
                });
            };

            const origToLocaleString = Date.prototype.toLocaleString;
            Date.prototype.toLocaleString = function(locales, options) {
                const opts = Object.assign({ timeZone: SPOOF_TZ }, options || {});
                return origToLocaleString.call(this, locales || SPOOF_LANG, opts);
            };

            const origToLocaleDateString = Date.prototype.toLocaleDateString;
            Date.prototype.toLocaleDateString = function(locales, options) {
                const opts = Object.assign({ timeZone: SPOOF_TZ }, options || {});
                return origToLocaleDateString.call(this, locales || SPOOF_LANG, opts);
            };

            const origToLocaleTimeString = Date.prototype.toLocaleTimeString;
            Date.prototype.toLocaleTimeString = function(locales, options) {
                const opts = Object.assign({ timeZone: SPOOF_TZ }, options || {});
                return origToLocaleTimeString.call(this, locales || SPOOF_LANG, opts);
            };

            // 2. Fake GPS / Geolocation Spoofing
            const buildFakePosition = () => ({
                coords: {
                    latitude: SPOOF_LAT,
                    longitude: SPOOF_LON,
                    accuracy: SPOOF_ACC,
                    altitude: null,
                    altitudeAccuracy: null,
                    heading: null,
                    speed: null
                },
                timestamp: Date.now()
            });

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition = function(success, error, options) {
                    if (typeof success === 'function') {
                        setTimeout(() => success(buildFakePosition()), 25);
                    }
                };
                navigator.geolocation.watchPosition = function(success, error, options) {
                    if (typeof success === 'function') {
                        setTimeout(() => success(buildFakePosition()), 25);
                    }
                    return Math.floor(Math.random() * 10000) + 1;
                };
                navigator.geolocation.clearWatch = function() {};
            }

            if (navigator.permissions && navigator.permissions.query) {
                const origPermQuery = navigator.permissions.query.bind(navigator.permissions);
                navigator.permissions.query = function(desc) {
                    if (desc && desc.name === 'geolocation') {
                        return Promise.resolve({ state: 'granted', onchange: null });
                    }
                    return origPermQuery(desc);
                };
            }

            // 3. Navigator & Hardware Fingerprint Spoofing
            const defineNav = (prop, val) => {
                try {
                    Object.defineProperty(Navigator.prototype, prop, {
                        get: () => val,
                        configurable: true
                    });
                } catch (_) {}
            };
            defineNav('webdriver', false);
            defineNav('userAgent', SPOOF_UA);
            defineNav('platform', SPOOF_PLATFORM);
            defineNav('language', SPOOF_LANG);
            defineNav('languages', Object.freeze(SPOOF_LANGS.slice()));
            defineNav('hardwareConcurrency', SPOOF_CORES);
            defineNav('deviceMemory', SPOOF_MEM);
            defineNav('userAgentData', undefined);

            try {
                Object.defineProperty(Screen.prototype, 'width', { get: () => SPOOF_W, configurable: true });
                Object.defineProperty(Screen.prototype, 'height', { get: () => SPOOF_H, configurable: true });
                Object.defineProperty(Screen.prototype, 'availWidth', { get: () => SPOOF_W, configurable: true });
                Object.defineProperty(Screen.prototype, 'availHeight', { get: () => SPOOF_H, configurable: true });
            } catch (_) {}

            // 4. WebRTC IP Leak Prevention
            if (BLOCK_WEBRTC) {
                const blockedRTC = function() {
                    throw new DOMException('WebRTC disabled by Safdowser Anti-Detect', 'NotAllowedError');
                };
                window.RTCPeerConnection = blockedRTC;
                window.webkitRTCPeerConnection = blockedRTC;
                window.mozRTCPeerConnection = blockedRTC;
            }

            // 5. Canvas Fingerprint Deterministic Noise (offscreen clone so visible canvas is untouched)
            const seededNoise = (i) => ((Math.sin(NOISE_SEED + i) * 10000) % 1 > 0.5 ? 1 : -1);
            const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
            HTMLCanvasElement.prototype.toDataURL = function() {
                try {
                    if (this.width > 0 && this.height > 0) {
                        const clone = document.createElement('canvas');
                        clone.width = this.width;
                        clone.height = this.height;
                        const ctx = clone.getContext('2d');
                        if (ctx) {
                            ctx.drawImage(this, 0, 0);
                            const img = ctx.getImageData(0, 0, Math.min(clone.width, 8), Math.min(clone.height, 8));
                            for (let i = 0; i < img.data.length; i += 4) {
                                img.data[i] = Math.max(0, Math.min(255, img.data[i] + seededNoise(i)));
                            }
                            ctx.putImageData(img, 0, 0);
                            return origToDataURL.apply(clone, arguments);
                        }
                    }
                } catch (_) {}
                return origToDataURL.apply(this, arguments);
            };

            // 6. WebGL Vendor & Renderer Spoofing
            const patchWebGL = (proto) => {
                if (!proto || !proto.getParameter) return;
                const origGetParam = proto.getParameter;
                proto.getParameter = function(param) {
                    if (param === 37445) return SPOOF_WEBGL_VENDOR;
                    if (param === 37446) return SPOOF_WEBGL_RENDERER;
                    return origGetParam.apply(this, arguments);
                };
            };
            if (window.WebGLRenderingContext) patchWebGL(WebGLRenderingContext.prototype);
            if (window.WebGL2RenderingContext) patchWebGL(WebGL2RenderingContext.prototype);
        })();
        """.trimIndent()
    }
}
