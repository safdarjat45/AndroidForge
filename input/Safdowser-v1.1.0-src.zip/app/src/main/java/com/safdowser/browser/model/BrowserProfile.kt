package com.safdowser.browser.model

import java.util.UUID

data class BrowserProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val timezoneId: String,
    val timezoneOffsetMinutes: Int, // JS getTimezoneOffset(): UTC - Local in minutes (EST = +300)
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float = 15.0f,
    val language: String = "en-US",
    val languages: List<String> = listOf("en-US", "en"),
    val userAgent: String,
    val platform: String = "Linux armv81",
    val hardwareConcurrency: Int = 8,
    val deviceMemory: Int = 8,
    val screenWidth: Int = 412,
    val screenHeight: Int = 915,
    val webglVendor: String = "Qualcomm",
    val webglRenderer: String = "Adreno (TM) 740",
    val noiseSeed: Int = 4219,
    val vpnServerId: String = "us-ny-1",
    val customProxyHost: String = "",
    val customProxyPort: Int = 0,
    val blockWebRtc: Boolean = true,
    val isIncognito: Boolean = false
)

data class GeoPreset(
    val label: String,
    val countryCode: String,
    val timezoneId: String,
    val timezoneOffsetMinutes: Int,
    val latitude: Double,
    val longitude: Double,
    val language: String
)

object GeoPresets {
    val all = listOf(
        GeoPreset("New York, USA", "US", "America/New_York", 300, 40.7128, -74.0060, "en-US"),
        GeoPreset("Los Angeles, USA", "US", "America/Los_Angeles", 480, 34.0522, -118.2437, "en-US"),
        GeoPreset("London, UK", "GB", "Europe/London", 0, 51.5074, -0.1278, "en-GB"),
        GeoPreset("Frankfurt, Germany", "DE", "Europe/Berlin", -60, 50.1109, 8.6821, "de-DE"),
        GeoPreset("Amsterdam, Netherlands", "NL", "Europe/Amsterdam", -60, 52.3676, 4.9041, "nl-NL"),
        GeoPreset("Paris, France", "FR", "Europe/Paris", -60, 48.8566, 2.3522, "fr-FR"),
        GeoPreset("Toronto, Canada", "CA", "America/Toronto", 300, 43.6532, -79.3832, "en-CA"),
        GeoPreset("Tokyo, Japan", "JP", "Asia/Tokyo", -540, 35.6762, 139.6503, "ja-JP"),
        GeoPreset("Singapore", "SG", "Asia/Singapore", -480, 1.3521, 103.8198, "en-SG"),
        GeoPreset("Dubai, UAE", "AE", "Asia/Dubai", -240, 25.2048, 55.2708, "en-AE"),
        GeoPreset("Sydney, Australia", "AU", "Australia/Sydney", -660, -33.8688, 151.2093, "en-AU"),
        GeoPreset("Sao Paulo, Brazil", "BR", "America/Sao_Paulo", 180, -23.5505, -46.6333, "pt-BR")
    )
}
