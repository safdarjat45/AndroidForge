# Safdowser — Anti-Detect Browser for Android 12+

**Safdowser** is an Android 12+ (API 31+) anti-detect browser built with Kotlin, Jetpack Compose, `androidx.webkit`, and `ProxyController`.

## Key Features
- **Zero-Leak Device Permissions**: Does not request `ACCESS_FINE_LOCATION` or `ACCESS_COARSE_LOCATION`, preventing hardware GPS leaks.
- **Multiple Isolated Profiles**: Create, switch, and manage independent browser profiles, each with its own User-Agent, IANA Timezone, Fake GPS coordinates, language, screen metrics, WebGL/Canvas fingerprint seed, and proxy/IP exit node.
- **Document-Start Anti-Detect Engine**: Uses `WebViewCompat.addDocumentStartJavaScript` to override `Intl.DateTimeFormat`, `Date` (including `toString()`, `toTimeString()`, `toDateString()`, `getTimezoneOffset()`), `navigator.geolocation`, `navigator.permissions`, `RTCPeerConnection` (WebRTC IP leak block), `Canvas`, `WebGL`, `navigator.userAgentData`, `navigator.webdriver`, and hardware properties **before** any website script executes.
- **Incognito Mode**: Ephemeral session that blocks disk caching, clears `CookieManager`, `WebStorage`, history, and form data upon exit.
- **Global IP / Proxy Routing**: Supports `androidx.webkit.ProxyController` (`SOCKS5` / `HTTP`) per-WebView proxy routing with custom `host:port` input and live VPN Gate directory lookup.

## How to Build & Install on Android 12+
1. Open the `Safdowser/` folder in **Android Studio** (Koala / Ladybug or newer).
2. Let Gradle sync download dependencies (`androidx.webkit:webkit:1.12.1`, Jetpack Compose Material 3, Kotlin Coroutines).
3. Connect your Android 12+ phone with **USB Debugging** enabled (or build an APK via **Build > Build Bundle(s) / APK(s) > Build APK(s)**).
4. Install `app/build/outputs/apk/debug/app-debug.apk` on your device.
