package com.safdowser.gecko.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.safdowser.gecko.browser.AddonsManager
import com.safdowser.gecko.browser.PRESEEDED_ADDONS

/**
 * Add-ons screen: install from AMO, list installed, enable/disable,
 * options page, uninstall.
 *
 * AMO only — Chrome Web Store extensions cannot run on this engine, and
 * the screen never suggests otherwise. Urban VPN / Green VPN are called
 * out as unavailable here, not hidden.
 */
@Composable
fun AddonsScreen(
    addons: AddonsManager,
    onBack: () -> Unit,
    /** Called after the store/search tab is opened, so the UI can switch to it. */
    onStoreOpened: () -> Unit = {}
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Add-ons", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            if (addons.status != null) {
                item {
                    Text(
                        text = addons.status!!,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Urban VPN aur Green VPN?", fontWeight = FontWeight.Bold)
                        Text(
                            "Ye dono Firefox for Android par install nahi ho sakte — kisi bhi browser se nahi. " +
                                "Urban VPN AMO par Android ke liye listed hi nahi, aur Green VPN ka Firefox " +
                                "add-on hai hi nahi (sirf Chrome). Neeche Browsec uski jagah kaam karega.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Mozilla Add-ons Store", fontWeight = FontWeight.Bold)
                        Text(
                            "Koi bhi add-on khud dhoond kar lagana ho to official store kholo. " +
                                "Naam likh kar Search dabao — store ka page naye tab mein khulega, " +
                                "wahan \"Add to Firefox\" dabane par permission wala dialog yahin " +
                                "is app mein aayega. Sirf wahi add-ons install honge jo Firefox " +
                                "for Android ke liye bane hain.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        var storeQuery by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = storeQuery,
                            onValueChange = { storeQuery = it },
                            label = { Text("Add-on ka naam, masalan: vpn, blocker, dark reader") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row {
                            Button(onClick = {
                                addons.searchAddonStore(storeQuery)
                                onStoreOpened()
                            }) {
                                Text("Search")
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = {
                                addons.openAddonStore()
                                onStoreOpened()
                            }) {
                                Text("Poora Store kholo")
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    "Recommended",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
            }

            items(PRESEEDED_ADDONS, key = { it.slug }) { addon ->
                val alreadyInstalled = addons.installed.any {
                    it.metaData.name?.contains(addon.name, ignoreCase = true) == true
                }
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(addon.name, fontWeight = FontWeight.Bold)
                        Text(addon.blurb, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { addons.installFromAmo(addon.slug) },
                            enabled = !addons.installing && !alreadyInstalled
                        ) {
                            Text(
                                when {
                                    alreadyInstalled -> "Installed"
                                    addons.installing -> "Installing…"
                                    else -> "Install"
                                }
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    "Installed (${addons.installed.size})",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                )
            }

            if (addons.installed.isEmpty()) {
                item {
                    Text(
                        "Abhi koi add-on installed nahi. Upar se Browsec ya uBlock Origin install karo.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
            }

            items(addons.installed, key = { it.id }) { ext ->
                val meta = ext.metaData
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(meta.name ?: ext.id, fontWeight = FontWeight.Bold)
                                Text("v${meta.version}", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(
                                checked = meta.enabled,
                                onCheckedChange = { addons.setEnabled(ext, it) }
                            )
                        }
                        meta.description?.let {
                            Text(it, style = MaterialTheme.typography.bodyMedium)
                        }
                        Row(modifier = Modifier.padding(top = 8.dp)) {
                            if (meta.optionsPageUrl != null) {
                                OutlinedButton(onClick = { addons.openOptionsPage(ext) }) {
                                    Text("Options")
                                }
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { addons.uninstall(ext) }) {
                                Text("Uninstall")
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    "Note: add-on apna code khud chalata hai — uske leak points (WebRTC, " +
                        "direct connections) hamare control mein nahi. \"No detection\" ki " +
                        "guarantee sirf built-in behaviour ke liye di ja sakti hai.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        }
    }
}
