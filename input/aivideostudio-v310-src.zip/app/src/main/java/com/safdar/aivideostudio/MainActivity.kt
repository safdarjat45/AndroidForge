package com.safdar.aivideostudio

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.tabs.TabLayout
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var tabLayout: TabLayout
    private lateinit var webStudio: WebView
    private lateinit var webColab: WebView
    private lateinit var webApiKey: WebView
    private lateinit var webFlow: WebView
    private lateinit var studioWaitingOverlay: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var tvBridgeStatus: TextView
    private lateinit var etManualColabUrl: EditText

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var activeTabIndex = 0

    private var capturedColabUrl: String = ""
    private var capturedApiKey: String = ""
    private var deadTunnelUrl: String = ""

    // ---------------- Auto-Pilot (v3.0) ----------------
    private enum class APStage {
        IDLE, OPEN_COLAB, WAIT_SIGNIN, UPLOAD, RUNTIME_TYPE, RUN_ALL,
        WAIT_TUNNEL, STUDIO_READY, GEN_STEP1, GEN_STEP2, DONE
    }

    private var apStage = APStage.IDLE
    private var apStageSince = 0L
    private var apRunAllRetries = 0
    private var apRtAttempts = 0
    private var apConnectClicked = false

    // ---------------- Flow auto-chain (v3.1.0) ----------------
    // Step 1 ke baad har scene khud Flow (Veo) mein jata hai, clip khud wapas
    // dashboard mein lagta hai — user ko file download/upload nahi karni parti.
    private data class FlowJob(val sceneId: Int, val prompt: String)

    private val flowQueue = ArrayDeque<FlowJob>()
    private val flowDoneAt = mutableMapOf<Int, Long>()
    private var flowBusy = false
    private var flowStage = "IDLE"
    private var flowCurrent: FlowJob? = null
    private var flowStageSince = 0L
    private var flowBaselineClips = setOf<String>()
    private var flowDownloadClicked = false
    private var feedUri: Uri? = null
    private val flowHandler = Handler(Looper.getMainLooper())
    private var feedingNotebook = false
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val apHandler = Handler(Looper.getMainLooper())
    private lateinit var tvAutoStatus: TextView
    private lateinit var btnGenerateVideo: Button
    private lateinit var btnAutoPilot: Button
    private lateinit var tvLog: TextView
    private lateinit var svLog: android.widget.ScrollView
    private var lastStatusText = ""
    private val logLines = ArrayDeque<String>()
    private var heartbeatOn = false

    private val pickNotebookLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val dir = File(filesDir, "autopilot").apply { mkdirs() }
                val dest = File(dir, "custom_notebook.ipynb")
                contentResolver.openInputStream(uri)?.use { input ->
                    dest.outputStream().use { output -> input.copyTo(output) }
                }
                getSharedPreferences("StudioV2Prefs", Context.MODE_PRIVATE)
                    .edit().putBoolean("nb_custom", true).apply()
                setApStatus("📓 Tumhari Colab file save ho gayi. Ab '🚀 Auto-Pilot' dabao — upload, T4 aur Run all khud hoga.")
                Toast.makeText(this, "Colab file save ho gayi ✅", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "File save nahi ho saki: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private lateinit var studioRootDir: File
    private lateinit var framesDir: File
    private lateinit var clipsDir: File
    private lateinit var outputDir: File

    private val DEFAULT_COLAB_URL = "https://colab.research.google.com/"
    private val AI_STUDIO_KEY_URL = "https://aistudio.google.com/app/apikey"
    private val GOOGLE_FLOW_URL = "https://labs.google/fx/tools/flow"

    private val handler = Handler(Looper.getMainLooper())

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val serviceIntent = Intent(this, KeepAliveService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        setupDedicatedFolders()

        tabLayout = findViewById(R.id.tabLayout)
        webStudio = findViewById(R.id.webStudio)
        webColab = findViewById(R.id.webColab)
        webApiKey = findViewById(R.id.webApiKey)
        webFlow = findViewById(R.id.webFlow)
        studioWaitingOverlay = findViewById(R.id.studioWaitingOverlay)
        progressBar = findViewById(R.id.progressBar)
        tvBridgeStatus = findViewById(R.id.tvBridgeStatus)
        etManualColabUrl = findViewById(R.id.etManualColabUrl)

        val btnRefresh: ImageButton = findViewById(R.id.btnRefresh)
        val btnGoColab: Button = findViewById(R.id.btnGoColab)
        val btnManualConnect: Button = findViewById(R.id.btnManualConnect)

        val prefs = getSharedPreferences("StudioV2Prefs", Context.MODE_PRIVATE)
        capturedColabUrl = prefs.getString("colab_url", "") ?: ""
        capturedApiKey = prefs.getString("gemini_api_key", "") ?: ""

        assignIsolatedProfile(webStudio, "Profile_Studio")
        assignIsolatedProfile(webColab, "Profile_Colab")
        assignIsolatedProfile(webApiKey, "Profile_ApiKey")
        assignIsolatedProfile(webFlow, "Profile_Flow_Pro")

        configureWebView(webStudio, "STUDIO")
        configureWebView(webColab, "COLAB")
        configureWebView(webApiKey, "APIKEY")
        configureWebView(webFlow, "FLOW")

        webColab.loadUrl(DEFAULT_COLAB_URL)
        webApiKey.loadUrl(AI_STUDIO_KEY_URL)
        webFlow.loadUrl(GOOGLE_FLOW_URL)

        if (capturedColabUrl.isNotEmpty()) {
            openStudioDashboard(capturedColabUrl)
        }
        updateBridgeStatusBadge()

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                switchTab(tab.position)
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        btnRefresh.setOnClickListener {
            when (activeTabIndex) {
                0 -> webStudio.reload()
                1 -> webColab.reload()
                2 -> webApiKey.reload()
                3 -> webFlow.reload()
            }
            Toast.makeText(this, "Refreshing active tab...", Toast.LENGTH_SHORT).show()
        }

        btnGoColab.setOnClickListener {
            tabLayout.getTabAt(1)?.select()
        }

        btnManualConnect.setOnClickListener {
            val raw = etManualColabUrl.text.toString()
            // Paste mein poori line bhi aa sakti hai — sirf tunnel URL nikaal lo
            val found = Regex("https://[a-zA-Z0-9.-]+\\.trycloudflare\\.com").find(raw)?.value
            val url = (found ?: raw.trim()).trimEnd('/')
            if (url.startsWith("http")) {
                onColabTunnelCaptured(url)
            } else {
                Toast.makeText(this, "Valid https:// URL darj karein", Toast.LENGTH_SHORT).show()
            }
        }

        // ---------------- Auto-Pilot wiring ----------------
        tvAutoStatus = findViewById(R.id.tvAutoStatus)
        btnGenerateVideo = findViewById(R.id.btnGenerateVideo)
        btnAutoPilot = findViewById(R.id.btnAutoPilot)
        tvLog = findViewById(R.id.tvLog)
        svLog = findViewById(R.id.svLog)
        prepareBundledNotebook()

        findViewById<Button>(R.id.btnPickNotebook).setOnClickListener {
            pickNotebookLauncher.launch(arrayOf("*/*"))
        }

        btnAutoPilot.setOnClickListener {
            if (apStage == APStage.IDLE || apStage == APStage.DONE) {
                startAutopilot()
            } else {
                stopAutopilot("Auto-Pilot roka gaya. Sab tabs manual bhi chal sakte hain.")
            }
        }

        btnGenerateVideo.setOnClickListener {
            if (apStage == APStage.STUDIO_READY) {
                tabLayout.getTabAt(0)?.select()
                setApStage(APStage.GEN_STEP1)
                setApStatus("🎬 Start daba diya hai — poori pipeline chal rahi hai (Step 1 → Flow → Step 2 auto)...")
                apStudioJs("window.__apGenFlow=true;")
                clickStudioButton("Start")
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val activeWeb = when (activeTabIndex) {
                    0 -> webStudio
                    1 -> webColab
                    2 -> webApiKey
                    else -> webFlow
                }
                if (activeWeb.canGoBack()) {
                    activeWeb.goBack()
                } else if (activeTabIndex != 0) {
                    tabLayout.getTabAt(0)?.select()
                } else {
                    moveTaskToBack(true)
                }
            }
        })
    }

    private fun setupDedicatedFolders() {
        val baseDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        studioRootDir = File(baseDownloads, "AIVideoStudio")
        framesDir = File(studioRootDir, "1_Generated_Frames")
        clipsDir = File(studioRootDir, "2_Veo_Clips")
        outputDir = File(studioRootDir, "3_Final_Videos")
        framesDir.mkdirs()
        clipsDir.mkdirs()
        outputDir.mkdirs()
    }

    private fun assignIsolatedProfile(webView: WebView, profileName: String) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            WebViewCompat.setProfile(webView, profileName)
        }
    }

    private fun switchTab(index: Int) {
        activeTabIndex = index
        webStudio.visibility = if (index == 0) View.VISIBLE else View.GONE
        webColab.visibility = if (index == 1) View.VISIBLE else View.GONE
        webApiKey.visibility = if (index == 2) View.VISIBLE else View.GONE
        webFlow.visibility = if (index == 3) View.VISIBLE else View.GONE

        if (index == 0) {
            studioWaitingOverlay.visibility = if (capturedColabUrl.isEmpty()) View.VISIBLE else View.GONE
            if (capturedApiKey.isNotEmpty()) {
                injectApiKeyIntoStudio(capturedApiKey)
            }
        } else {
            studioWaitingOverlay.visibility = View.GONE
        }
    }

    // ================= Auto-Pilot engine (v3.0) =================
    // Colab upload -> T4 -> Run all -> tunnel -> dashboard khud; Studio mein
    // Step 1 -> Step 2 -> final video aik tap par. Sign-in/captcha user ke paas.

    private fun setApStatus(msg: String) {
        if (!::tvAutoStatus.isInitialized) return
        tvAutoStatus.text = msg
        if (msg != lastStatusText) {
            lastStatusText = msg
            logEvent(msg)
        }
    }

    /** Live maloomat: har nayi karwai time ke saath neeche list mein judti rehti hai. */
    private fun logEvent(msg: String) {
        if (!::tvLog.isInitialized) return
        val time = java.text.SimpleDateFormat("hh:mm:ss a", java.util.Locale.US).format(java.util.Date())
        logLines.addLast("$time  $msg")
        while (logLines.size > 30) logLines.removeFirst()
        tvLog.text = logLines.joinToString("\n")
        svLog.post { svLog.fullScroll(View.FOCUS_DOWN) }
    }

    /** Jab koi step dair tak chale to status par guzra waqt bhi lagatar dikhao —
     * taake screen ruki hui na lage, hamesha pata chale ke kaam chal raha hai. */
    private val heartbeat = object : Runnable {
        override fun run() {
            val active = apStage != APStage.IDLE && apStage != APStage.DONE || flowBusy
            if (active && ::tvAutoStatus.isInitialized && lastStatusText.isNotEmpty()) {
                val since = if (flowBusy) flowStageSince else apStageSince
                val sec = ((System.currentTimeMillis() - since) / 1000).coerceAtLeast(0)
                val fmt = "%d:%02d".format(sec / 60, sec % 60)
                tvAutoStatus.text = "$lastStatusText\n⏳ Is step ko $fmt ho gaye — kaam chal raha hai..."
            }
            if (active) flowHandler.postDelayed(this, 5000) else heartbeatOn = false
        }
    }

    private fun startHeartbeat() {
        if (heartbeatOn) return
        heartbeatOn = true
        flowHandler.postDelayed(heartbeat, 5000)
    }

    private fun setApStage(stage: APStage) {
        apStage = stage
        apStageSince = System.currentTimeMillis()
        if (stage == APStage.RUNTIME_TYPE) {
            apRtAttempts = 0
            apConnectClicked = false
        }
    }

    private fun prepareBundledNotebook() {
        try {
            val dir = File(filesDir, "autopilot").apply { mkdirs() }
            val dest = File(dir, "bundled_notebook.ipynb")
            assets.open("colab_studio.ipynb").use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            }
        } catch (e: Exception) { /* bundled copy optional */ }
    }

    private fun effectiveNotebookFile(): File? {
        val dir = File(filesDir, "autopilot")
        val prefs = getSharedPreferences("StudioV2Prefs", Context.MODE_PRIVATE)
        val custom = File(dir, "custom_notebook.ipynb")
        if (prefs.getBoolean("nb_custom", false) && custom.exists() && custom.length() > 0) return custom
        val bundled = File(dir, "bundled_notebook.ipynb")
        return if (bundled.exists() && bundled.length() > 0) bundled else null
    }

    private fun startAutopilot() {
        if (effectiveNotebookFile() == null) prepareBundledNotebook()
        // Purana (expire-shuda) link bhool jao taake naya hi capture ho
        capturedColabUrl = ""
        deadTunnelUrl = ""
        getSharedPreferences("StudioV2Prefs", Context.MODE_PRIVATE)
            .edit().remove("colab_url").apply()
        apRunAllRetries = 0
        apRtAttempts = 0
        tabLayout.getTabAt(1)?.select()
        btnAutoPilot.text = "⏹ Auto-Pilot"
        btnGenerateVideo.isEnabled = false
        setApStage(APStage.OPEN_COLAB)
        setApStatus("🚀 Auto-Pilot shuru — Colab khul raha hai...")
        webColab.loadUrl("https://colab.research.google.com/")
        startHeartbeat()
        apHandler.removeCallbacks(apTick)
        apHandler.postDelayed(apTick, 3000)
    }

    private fun stopAutopilot(msg: String) {
        setApStage(APStage.IDLE)
        apHandler.removeCallbacks(apTick)
        feedingNotebook = false
        if (::btnAutoPilot.isInitialized) btnAutoPilot.text = "🚀 Auto-Pilot"
        setApStatus(msg)
    }

    private val apTick = object : Runnable {
        override fun run() {
            if (apStage == APStage.IDLE) return
            try { apStep() } catch (e: Exception) { /* agle tick par phir koshish */ }
            if (apStage != APStage.IDLE && apStage != APStage.DONE) {
                apHandler.postDelayed(this, 3000)
            }
        }
    }

    private fun cleanJsResult(res: String?): String {
        if (res.isNullOrEmpty()) return ""
        return try {
            val v = org.json.JSONTokener(res).nextValue()
            if (v is String) v else res
        } catch (e: Exception) { res.trim().trim('"') }
    }

    private fun apColabJs(js: String, cb: ((String) -> Unit)? = null) {
        webColab.evaluateJavascript(js) { res -> cb?.invoke(cleanJsResult(res)) }
    }

    private fun apStudioJs(js: String, cb: ((String) -> Unit)? = null) {
        webStudio.evaluateJavascript(js) { res -> cb?.invoke(cleanJsResult(res)) }
    }

    private val AP_JS_UTILS = """
        window.__apClick=function(txt,partial){
          var els=Array.from(document.querySelectorAll('button,a,[role="button"],[role="menuitem"],[role="tab"],[role="option"]'));
          var c=els.filter(function(e){var s=(e.innerText||e.textContent||'').trim();return s&&(partial?s.indexOf(txt)>-1:s===txt);});
          c=c.filter(function(e){return e.getClientRects().length>0;});
          if(!c.length)return false;
          c.sort(function(a,b){return (a.innerText||'').length-(b.innerText||'').length;});
          c[0].click();return true;
        };
        window.__apText=function(){return document.body?document.body.innerText:'';};
        window.__apClickLoose=function(txt,partial){
          var els=Array.from(document.querySelectorAll('button,a,[role="button"],[role="menuitem"],[role="tab"],[role="option"],div,span'));
          var c=els.filter(function(e){var s=(e.innerText||e.textContent||'').trim();return s&&(partial?s.indexOf(txt)>-1:s===txt)&&e.childElementCount<=2;});
          if(!c.length)return false;
          c.sort(function(a,b){return (a.innerText||'').length-(b.innerText||'').length;});
          c[0].click();return true;
        };
        window.__apRunAll=function(){
          try{
            var opts={key:'F9',code:'F9',keyCode:120,which:120,ctrlKey:true,bubbles:true,cancelable:true};
            document.dispatchEvent(new KeyboardEvent('keydown',opts));
            if(document.body)document.body.dispatchEvent(new KeyboardEvent('keydown',opts));
          }catch(e){}
          setTimeout(function(){window.__apClickLoose('Runtime');setTimeout(function(){window.__apClickLoose('Run all',true);},900);},700);
        };
    """.trimIndent()

    private fun installColabDialogWatcher() {
        apColabJs(
            """
            if(!window.__apDlgTimer){window.__apDlgTimer=setInterval(function(){
              var texts=['Run anyway','Reconnect','Run all','Yes','OK','Continue'];
              var btns=Array.from(document.querySelectorAll('button,[role="button"]'));
              for(var i=0;i<btns.length;i++){var s=(btns[i].innerText||'').trim();
                if(texts.indexOf(s)>-1&&btns[i].getClientRects().length>0){btns[i].click();break;}}
            },2000);}
            """.trimIndent()
        )
    }

    private fun issueRunAll() {
        // Do tareeqe: Ctrl+F9 shortcut + menu (chhoti screen par menu chhupa hota hai)
        apColabJs(AP_JS_UTILS + "if(window.__apRunAll)window.__apRunAll();")
    }

    private fun clickStudioButton(partialText: String) {
        apStudioJs(
            """
            (function(){
              var els=Array.from(document.querySelectorAll('button'));
              var c=els.filter(function(e){return (e.innerText||'').indexOf('$partialText')>-1&&e.getClientRects().length>0;});
              if(c.length){c[0].click();return 'clicked';}
              return 'not-found';
            })()
            """.trimIndent()
        )
    }

    private fun apStep() {
        val inStage = System.currentTimeMillis() - apStageSince
        when (apStage) {
            APStage.OPEN_COLAB -> {
                val url = webColab.url ?: ""
                if (url.contains("accounts.google.com")) {
                    setApStage(APStage.WAIT_SIGNIN)
                    setApStatus("🔐 Colab tab mein Google sign-in kar lein — sign-in hote hi Auto-Pilot khud aage barhega. (Sign-in/captcha hamesha aap ke hath mein rehta hai.)")
                } else if (url.contains("colab.research.google.com")) {
                    apColabJs(AP_JS_UTILS + """
                        (function(){
                          var t=window.__apText();
                          if(t.indexOf('Open notebook')>-1||t.indexOf('Upload')>-1&&t.indexOf('Examples')>-1) return 'dialog';
                          if(document.querySelector('#top-toolbar')) return 'notebook';
                          return 'page';
                        })()
                    """.trimIndent()) { r ->
                        if (apStage != APStage.OPEN_COLAB) return@apColabJs
                        when (r) {
                            "dialog" -> {
                                feedingNotebook = true
                                setApStage(APStage.UPLOAD)
                                setApStatus("📤 Notebook upload ho raha hai — file khud select hogi...")
                                apColabJs(AP_JS_UTILS + "window.__apClick('Upload');")
                                apHandler.postDelayed({
                                    apColabJs(AP_JS_UTILS + "window.__apClick('Browse',true);")
                                }, 1500)
                            }
                            "notebook" -> {
                                installColabDialogWatcher()
                                setApStage(APStage.RUNTIME_TYPE)
                                setApStatus("📓 Notebook pehle se khula hai — runtime connect + Run all ho raha hai...")
                            }
                            else -> if (inStage > 45000) {
                                // Welcome notebook ka File menu wala rasta
                                feedingNotebook = true
                                setApStage(APStage.UPLOAD)
                                setApStatus("📤 Upload menu se notebook bhej raha hai...")
                                apColabJs(AP_JS_UTILS + "window.__apClick('File');")
                                apHandler.postDelayed({
                                    apColabJs(AP_JS_UTILS + "window.__apClick('Upload notebook',true);")
                                    apHandler.postDelayed({
                                        apColabJs(AP_JS_UTILS + "window.__apClick('Upload');")
                                        apHandler.postDelayed({
                                            apColabJs(AP_JS_UTILS + "window.__apClick('Browse',true);")
                                        }, 1200)
                                    }, 1200)
                                }, 1200)
                            }
                        }
                    }
                }
            }

            APStage.WAIT_SIGNIN -> {
                val url = webColab.url ?: ""
                if (url.contains("colab.research.google.com")) {
                    setApStage(APStage.OPEN_COLAB)
                    setApStatus("✅ Sign-in ho gaya — notebook upload ho raha hai...")
                }
            }

            APStage.UPLOAD -> {
                apColabJs(
                    "(function(){var t=document.body?document.body.innerText:'';return (document.querySelector('#top-toolbar')||t.indexOf('Change runtime type')>-1)?'nb':'no';})()"
                ) { r ->
                    if (apStage != APStage.UPLOAD) return@apColabJs
                    if (r == "nb") {
                        feedingNotebook = false
                        installColabDialogWatcher()
                        setApStage(APStage.RUNTIME_TYPE)
                        setApStatus("📓 Notebook khul gaya — runtime connect + Run all ho raha hai...")
                    } else if (inStage > 150000) {
                        setApStatus("⏳ Upload dialog nahi mila. Colab tab mein Upload → Browse khud tap kar dein — file khud select ho jayegi aur Auto-Pilot aage sambhal lega.")
                    }
                }
            }

            APStage.RUNTIME_TYPE -> {
                // Chhoti (phone) screen par Colab ka Runtime menu chhup jata hai —
                // is liye menu-dialog wala purana tareeqa atak jata tha. Naya tareeqa:
                // pehle 'Connect' khud dabao, connect hote hi Ctrl+F9 se Run all.
                apRtAttempts++
                apColabJs(AP_JS_UTILS + """
                    (function(){
                      var t=window.__apText();
                      var connected=(t.indexOf('RAM')>-1&&t.indexOf('Disk')>-1);
                      var btns=Array.from(document.querySelectorAll('button,[role="button"]'));
                      var hasConnect=btns.some(function(b){var s=(b.innerText||'').trim();return s.indexOf('Connect')===0&&b.getClientRects().length>0;});
                      return (connected?'C':'')+(hasConnect?'B':'');
                    })()
                """.trimIndent()) { r ->
                    if (apStage != APStage.RUNTIME_TYPE) return@apColabJs
                    val connected = r.contains("C")
                    val hasConnect = r.contains("B")
                    when {
                        connected -> {
                            setApStatus("▶️ Runtime connect ho gaya — Run all ho raha hai, cells chal rahe hain...")
                            issueRunAll()
                            setApStage(APStage.WAIT_TUNNEL)
                        }
                        hasConnect && !apConnectClicked && apRtAttempts >= 2 -> {
                            apConnectClicked = true
                            apColabJs(AP_JS_UTILS + "window.__apClick('Connect',true);")
                            setApStatus("⚡ 'Connect' khud daba diya hai — T4 runtime connect ho raha hai, thora intezaar...")
                        }
                        apRtAttempts > 40 -> {
                            setApStatus("⏳ Runtime auto-connect nahi ho saka. Colab tab mein 'Connect' phir 'Run all' khud daba dein — link aate hi dashboard khud khul jayega, Auto-Pilot nazar rakhe hue hai.")
                            issueRunAll()
                            setApStage(APStage.WAIT_TUNNEL)
                        }
                    }
                }
            }

            APStage.WAIT_TUNNEL -> {
                if (capturedColabUrl.isNotEmpty()) {
                    setApStage(APStage.STUDIO_READY)
                    btnGenerateVideo.isEnabled = true
                    tabLayout.getTabAt(0)?.select()
                    setApStatus("✅ Dashboard khul gaya! Studio tab mein apne inputs dein (topic/script waghera), phir upar '🎬 Video Banao' dabayein — Step 1, Step 2 aur final video khud ban jayega.")
                } else {
                    apColabJs(
                        "(function(){var t=document.body?document.body.innerText:'';return t.indexOf('Traceback (most recent call last)')>-1?'err':'ok';})()"
                    ) { r ->
                        if (apStage != APStage.WAIT_TUNNEL) return@apColabJs
                        if (r == "err" && inStage > 60000) {
                            if (apRunAllRetries < 2) {
                                apRunAllRetries++
                                setApStatus("⚠️ Colab mein error mila — khud dobara Run all kar raha hai (koshish $apRunAllRetries/2)...")
                                issueRunAll()
                                apStageSince = System.currentTimeMillis()
                            } else {
                                setApStatus("⚠️ Colab cells mein error bar bar aa raha hai. Colab tab mein laal error parh lein — theek karke '🚀 Auto-Pilot' phir dabayein. (503 wala error notebook khud retry karti hai.)")
                                apStageSince = System.currentTimeMillis()
                            }
                        } else if (inStage > 480000) {
                            setApStatus("⏳ Link abhi nahi mila — Colab tab check karein, cells chal rahe hain ya ruk gaye? Auto-Pilot nazar rakhe hue hai.")
                            apStageSince = System.currentTimeMillis()
                        }
                    }
                }
            }

            APStage.STUDIO_READY -> {
                // User ke inputs + 'Video Banao' tap ka intezaar
            }

            APStage.GEN_STEP1 -> {
                apStudioJs(
                    "(function(){var t=document.body?document.body.innerText:'';" +
                        "if(t.indexOf('Scenes & Consistent Frames Ready')>-1)return 'ready';" +
                        "if(t.indexOf('overloaded hai')>-1)return 'busy';" +
                        "if(t.indexOf('API Key missing')>-1)return 'nokey';" +
                        "return 'wait';})()"
                ) { r ->
                    if (apStage != APStage.GEN_STEP1) return@apStudioJs
                    when (r) {
                        "ready" -> {
                            setApStage(APStage.GEN_STEP2)
                            setApStatus("✅ Scenes tayyar! Clips Flow se aate hi Step 2 (voices + lip-sync + render) khud chal jayega...")
                        }
                        "busy" -> {
                            apStudioJs("window.__apGenFlow=false;")
                            setApStage(APStage.STUDIO_READY)
                            setApStatus("⚠️ Google ka server overloaded tha aur notebook ki retries bhi khatam ho gayin. Chand minute ruk kar '🎬 Video Banao' phir dabayein.")
                        }
                        "nokey" -> {
                            apStudioJs("window.__apGenFlow=false;")
                            setApStage(APStage.STUDIO_READY)
                            setApStatus("⚠️ Gemini API Key nahi mili. '🔑 API Key' tab mein sign in karein (key khud capture ho jayegi), phir '🎬 Video Banao' dabayein.")
                        }
                        else -> if (inStage > 1200000) {
                            setApStage(APStage.STUDIO_READY)
                            setApStatus("⏳ Step 1 bohat der se chal raha hai — Studio tab check karke zaroorat ho to '🎬 Video Banao' phir dabayein.")
                        }
                    }
                }
            }

            APStage.GEN_STEP2 -> {
                apStudioJs(
                    "(function(){var t=document.body?document.body.innerText:'';return t.indexOf('Final Video Complete')>-1?'done':'wait';})()"
                ) { r ->
                    if (apStage != APStage.GEN_STEP2) return@apStudioJs
                    if (r == "done") {
                        apStudioJs("window.__apGenFlow=false;")
                        setApStage(APStage.DONE)
                        if (::btnAutoPilot.isInitialized) btnAutoPilot.text = "🚀 Auto-Pilot"
                        btnGenerateVideo.isEnabled = false
                        setApStatus("🎉 Final video tayyar hai! Download 'Downloads/AIVideoStudio/3_Final_Videos' mein check karein — agar auto-download na hua ho to Studio page par '⬇️ Download Final Video' button aik dafa tap kar dein.")
                        clickStudioButton("Download Final Video")
                    } else if (inStage > 2400000) {
                        setApStage(APStage.STUDIO_READY)
                        setApStatus("⏳ Step 2 bohat der se chal raha hai — Studio tab check karein. Video tayyar ho to wahi se download kar lein.")
                    }
                }
            }

            else -> { /* IDLE / DONE */ }
        }
    }

    private fun updateBridgeStatusBadge() {
        val cStatus = if (capturedColabUrl.isNotEmpty()) "Colab: OK" else "Colab: Wait"
        val kStatus = if (capturedApiKey.isNotEmpty()) "Key: OK" else "Key: Wait"
        tvBridgeStatus.text = "$cStatus | $kStatus"
    }

    private fun onColabTunnelCaptured(url: String) {
        if (url == capturedColabUrl && studioWaitingOverlay.visibility == View.GONE) return
        capturedColabUrl = url
        deadTunnelUrl = ""
        if (apStage != APStage.IDLE && apStage != APStage.DONE && apStage != APStage.STUDIO_READY &&
            apStage != APStage.GEN_STEP1 && apStage != APStage.GEN_STEP2
        ) {
            setApStage(APStage.STUDIO_READY)
            if (::btnGenerateVideo.isInitialized) btnGenerateVideo.isEnabled = true
            setApStatus("✅ Dashboard khul gaya! Studio tab mein apne inputs dein, phir '🎬 Video Banao' dabayein — Step 1, Step 2 aur final video khud ban jayega.")
        }
        getSharedPreferences("StudioV2Prefs", Context.MODE_PRIVATE)
            .edit().putString("colab_url", url).apply()
        updateBridgeStatusBadge()
        Toast.makeText(this, "Colab Tunnel Auto-Connected!", Toast.LENGTH_SHORT).show()
        openStudioDashboard(url)
        tabLayout.getTabAt(0)?.select()
    }

    private fun onGeminiKeyCaptured(key: String) {
        if (!key.startsWith("AIza") || key == capturedApiKey) return
        capturedApiKey = key
        getSharedPreferences("StudioV2Prefs", Context.MODE_PRIVATE)
            .edit().putString("gemini_api_key", key).apply()
        updateBridgeStatusBadge()
        Toast.makeText(this, "Gemini API Key Auto-Captured!", Toast.LENGTH_SHORT).show()
        injectApiKeyIntoStudio(key)
    }

    private fun openStudioDashboard(url: String) {
        studioWaitingOverlay.visibility = View.GONE
        val base = url.trimEnd('/')
        val finalUrl = if (capturedApiKey.isNotEmpty()) {
            "$base/?auto_key=$capturedApiKey"
        } else {
            base
        }
        webStudio.loadUrl(finalUrl)
    }

    /**
     * Trycloudflare links expire with the Colab session. When the saved link is
     * dead the Studio tab used to sit on the error page forever; now we detect
     * it, forget the dead link and show the connect screen with instructions.
     */
    private fun handleDeadTunnel() {
        if (capturedColabUrl.isEmpty() || deadTunnelUrl == capturedColabUrl) return
        deadTunnelUrl = capturedColabUrl
        capturedColabUrl = ""
        getSharedPreferences("StudioV2Prefs", Context.MODE_PRIVATE)
            .edit().remove("colab_url").apply()
        updateBridgeStatusBadge()
        if (activeTabIndex == 0) {
            studioWaitingOverlay.visibility = View.VISIBLE
        }
        Toast.makeText(
            this,
            "Purana Colab link expire ho gaya hai. 'Colab' tab mein notebook dobara Run karein — naya link khud connect ho jayega.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun injectApiKeyIntoStudio(key: String) {
        val js = "(function(){const inputs=document.querySelectorAll('input[type=\"password\"],input[type=\"text\"]');for(let inp of inputs){if((inp.placeholder&&inp.placeholder.toLowerCase().includes('gemini'))||(inp.getAttribute('aria-label')&&inp.getAttribute('aria-label').toLowerCase().includes('gemini'))){const ns=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;ns.call(inp,'$key');inp.dispatchEvent(new Event('input',{bubbles:true}));inp.dispatchEvent(new Event('change',{bubbles:true}));}}})();"
        webStudio.evaluateJavascript(js, null)
    }

    inner class AndroidAutomationBridge {
        @JavascriptInterface
        fun reportColabUrl(url: String) {
            handler.post { onColabTunnelCaptured(url.trim()) }
        }

        @JavascriptInterface
        fun reportApiKey(key: String) {
            handler.post { onGeminiKeyCaptured(key.trim()) }
        }

        @JavascriptInterface
        fun notifyAutoStep(msg: String) {
            handler.post { setApStatus(msg) }
        }

        @JavascriptInterface
        fun saveFrameBase64(sceneId: Int, base64Data: String) {
            try {
                val cleanBase64 = base64Data.substringAfter(",")
                val bytes = Base64.decode(cleanBase64, Base64.DEFAULT)
                val outFile = File(framesDir, "scene_${sceneId}.png")
                FileOutputStream(outFile).use { it.write(bytes) }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        @JavascriptInterface
        fun triggerAutoFlowForScene(sceneId: Int, motionPrompt: String) {
            handler.post {
                // v3.1.0: scene ko line mein lagao — Flow chain khud chalegi
                val now = System.currentTimeMillis()
                val doneAt = flowDoneAt[sceneId]
                if (flowQueue.any { it.sceneId == sceneId } || flowCurrent?.sceneId == sceneId ||
                    (doneAt != null && now - doneAt < 120000)
                ) {
                    return@post
                }
                flowQueue.add(FlowJob(sceneId, motionPrompt))
                setApStatus("🎞️ Scene $sceneId Flow (Veo) ki line mein lag gaya hai — khud jayega, clip khud wapas aayega.")
                startFlowProcessorIfNeeded()
            }
        }
    }

    private fun injectFlowAutomation(sceneId: Int, frameFile: File, motionPrompt: String) {
        val bytes = frameFile.readBytes()
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val escapedPrompt = motionPrompt.replace("'", "\\'").replace("\n", " ")

        val jsFlow = "(async function(){function b2f(b,fn){const bc=atob(b);const bn=new Array(bc.length);for(let i=0;i<bc.length;i++)bn[i]=bc.charCodeAt(i);return new File([new Blob([new Uint8Array(bn)],{type:'image/png'})],fn,{type:'image/png'});}const btns=Array.from(document.querySelectorAll('button,a'));const np=btns.find(b=>b.innerText&&b.innerText.toLowerCase().includes('new project'));if(np){np.click();await new Promise(r=>setTimeout(r,2500));}const fi=document.querySelector('input[type=\"file\"]');if(fi){const dt=new DataTransfer();dt.items.add(b2f('$b64','scene_${sceneId}.png'));fi.files=dt.files;fi.dispatchEvent(new Event('change',{bubbles:true}));await new Promise(r=>setTimeout(r,3000));}const pb=document.querySelector('textarea,div[contenteditable=\"true\"]');if(pb){pb.focus();if(pb.tagName==='TEXTAREA'){const s=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,'value').set;s.call(pb,'$escapedPrompt');pb.dispatchEvent(new Event('input',{bubbles:true}));}else{pb.innerText='$escapedPrompt';pb.dispatchEvent(new Event('input',{bubbles:true}));}await new Promise(r=>setTimeout(r,1000));}const gb=Array.from(document.querySelectorAll('button')).reverse().find(b=>(b.innerText&&b.innerText.toLowerCase().includes('generate'))||(b.getAttribute('aria-label')&&b.getAttribute('aria-label').toLowerCase().includes('generate')));if(gb)gb.click();})();"

        handler.postDelayed({
            webFlow.evaluateJavascript(jsFlow, null)
        }, 1500)
    }

    // ================= Flow auto-chain processor (v3.1.0) =================

    private fun startFlowProcessorIfNeeded() {
        if (flowBusy) return
        flowBusy = true
        startHeartbeat()
        flowNextJob()
        flowHandler.removeCallbacks(flowTick)
        flowHandler.postDelayed(flowTick, 5000)
    }

    private fun flowNextJob() {
        val job = flowQueue.poll()
        if (job == null) {
            flowBusy = false
            flowCurrent = null
            flowStage = "IDLE"
            tabLayout.getTabAt(0)?.select()
            setApStatus("🎬 Saare scenes ke clips Flow se wapas aa gaye hain — Step 2 khud chal jayega, final video ban raha hai...")
            return
        }
        flowCurrent = job
        flowDownloadClicked = false
        flowBaselineClips = queryClips().keys
        waitFrameThenSend(job, 0)
    }

    private fun waitFrameThenSend(job: FlowJob, tries: Int) {
        val frameFile = File(framesDir, "scene_${job.sceneId}.png")
        if (frameFile.exists()) {
            tabLayout.getTabAt(3)?.select()
            setApStatus("🎥 Scene ${job.sceneId} Flow (Veo) mein ja raha hai — video ban raha hai...")
            flowStage = "WAIT_GEN"
            flowStageSince = System.currentTimeMillis()
            injectFlowAutomation(job.sceneId, frameFile, job.prompt)
        } else if (tries < 8) {
            handler.postDelayed({ waitFrameThenSend(job, tries + 1) }, 4000)
        } else {
            setApStatus("⚠️ Scene ${job.sceneId} ka frame app mein nahi mila — ye scene skip ho raha hai.")
            flowDoneAt[job.sceneId] = System.currentTimeMillis()
            flowNextJob()
        }
    }

    private val flowTick = object : Runnable {
        override fun run() {
            if (!flowBusy) return
            try { flowStep() } catch (e: Exception) { /* agle tick par phir */ }
            if (flowBusy) flowHandler.postDelayed(this, 5000)
        }
    }

    private fun flowStep() {
        val job = flowCurrent ?: return
        val inStage = System.currentTimeMillis() - flowStageSince
        when (flowStage) {
            "WAIT_GEN" -> {
                if (inStage < 30000) return
                webFlow.evaluateJavascript(
                    "(function(){var els=Array.from(document.querySelectorAll('button,[role=\"button\"],a'));var dl=els.filter(function(e){var s=((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||'')+' '+(e.innerText||'')).toLowerCase();return s.indexOf('download')>-1;});return dl.length?'ready':'wait';})()"
                ) { res ->
                    if (flowStage != "WAIT_GEN" || flowCurrent?.sceneId != job.sceneId) return@evaluateJavascript
                    if (cleanJsResult(res) == "ready" && !flowDownloadClicked) {
                        flowDownloadClicked = true
                        webFlow.evaluateJavascript(
                            "(function(){var els=Array.from(document.querySelectorAll('button,[role=\"button\"],a'));var dl=els.filter(function(e){var s=((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('title')||'')+' '+(e.innerText||'')).toLowerCase();return s.indexOf('download')>-1;});if(dl.length){dl[dl.length-1].click();return 'clicked';}return 'none';})()",
                            null
                        )
                        setApStatus("⬇️ Scene ${job.sceneId} ka Veo clip ban gaya — download ho raha hai...")
                        flowStage = "WAIT_CLIP"
                        flowStageSince = System.currentTimeMillis()
                    } else if (inStage > 420000) {
                        setApStatus("⚠️ Scene ${job.sceneId} Flow mein bohat der se atka hai — skip kar raha hoon. Flow tab mein khud dekh lena.")
                        flowDoneAt[job.sceneId] = System.currentTimeMillis()
                        flowNextJob()
                    }
                }
            }

            "WAIT_CLIP" -> {
                val clips = queryClips()
                val newOnes = clips.keys - flowBaselineClips
                if (newOnes.isNotEmpty()) {
                    feedUri = clips[newOnes.first()]
                    flowStage = "FEED"
                    flowStageSince = System.currentTimeMillis()
                    tabLayout.getTabAt(0)?.select()
                    setApStatus("📤 Scene ${job.sceneId} ka clip dashboard mein khud lag raha hai...")
                    handler.postDelayed({ clickSceneUploader(job.sceneId) }, 1500)
                } else if (inStage > 90000) {
                    setApStatus("⚠️ Scene ${job.sceneId} ka clip download nahi mila — skip. Downloads/AIVideoStudio/2_Veo_Clips check kar lena.")
                    flowDoneAt[job.sceneId] = System.currentTimeMillis()
                    flowNextJob()
                }
            }

            "FEED" -> {
                if (inStage > 25000) {
                    if (feedUri != null) {
                        feedUri = null
                        setApStatus("⚠️ Scene ${job.sceneId} ka uploader nahi mila — skip. Dashboard mein clip hath se laga dena.")
                        flowDoneAt[job.sceneId] = System.currentTimeMillis()
                        flowNextJob()
                    } else {
                        flowStage = "CONFIRM"
                        flowStageSince = System.currentTimeMillis()
                    }
                }
            }

            "CONFIRM" -> {
                apStudioJs(
                    "(function(){var t=document.body?document.body.innerText:'';return t.indexOf('Scene ${job.sceneId} Clip Ready')>-1?'ok':'no';})()"
                ) { r ->
                    if (flowStage != "CONFIRM") return@apStudioJs
                    if (r == "ok") {
                        setApStatus("✅ Scene ${job.sceneId} ka clip lag gaya.")
                        flowDoneAt[job.sceneId] = System.currentTimeMillis()
                        flowNextJob()
                    } else if (inStage > 120000) {
                        setApStatus("⚠️ Scene ${job.sceneId} ke clip ki tasdeeq nahi ho saki — agla scene chala raha hoon.")
                        flowDoneAt[job.sceneId] = System.currentTimeMillis()
                        flowNextJob()
                    }
                }
            }
        }
    }

    private fun clickSceneUploader(sceneId: Int) {
        apStudioJs(
            "(function(){var inputs=Array.from(document.querySelectorAll('input[type=\"file\"]'));" +
                "for(var i=0;i<inputs.length;i++){var el=inputs[i],hops=0,found=false;" +
                "while(el&&hops<9){if((el.innerText||'').indexOf('Upload Veo Clip #$sceneId')>-1){found=true;break;}el=el.parentElement;hops++;}" +
                "if(found){inputs[i].click();return 'clicked';}}" +
                "return 'not-found';})()"
        )
    }

    private fun queryClips(): Map<String, Uri> {
        val map = mutableMapOf<String, Uri>()
        try {
            val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.RELATIVE_PATH
            )
            contentResolver.query(
                uri, projection, null, null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameI = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val pathI = c.getColumnIndexOrThrow(MediaStore.Video.Media.RELATIVE_PATH)
                while (c.moveToNext()) {
                    val path = c.getString(pathI) ?: continue
                    if (!path.contains("AIVideoStudio/2_Veo_Clips")) continue
                    val name = c.getString(nameI) ?: continue
                    map[name] = ContentUris.withAppendedId(uri, c.getLong(idI))
                }
            }
        } catch (e: Exception) { /* permission na ho to khali map */ }
        return map
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView, tag: String) {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.allowFileAccess = true
        s.allowContentAccess = true
        s.mediaPlaybackRequiresUserGesture = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.setSupportMultipleWindows(false)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.userAgentString = s.userAgentString.replace("; wv", "")

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.addJavascriptInterface(AndroidAutomationBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?
            ) {
                if (tag == "STUDIO" && request?.isForMainFrame == true &&
                    (errorResponse?.statusCode ?: 0) >= 400
                ) {
                    handleDeadTunnel()
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (tag == "STUDIO" && request?.isForMainFrame == true) {
                    handleDeadTunnel()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = View.GONE
                if (url == null) return
                when (tag) {
                    "COLAB" -> injectColabWatcher(webView)
                    "APIKEY" -> injectApiKeyWatcher(webView)
                    "STUDIO" -> {
                        injectStudioAutoStepWatcher(webView)
                        if (capturedApiKey.isNotEmpty()) injectApiKeyIntoStudio(capturedApiKey)
                    }
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress < 100) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = newProgress
                } else {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                // Flow chain: tayyar clip seedha Studio ke uploader ko de do
                if (this@MainActivity.feedUri != null) {
                    val u = this@MainActivity.feedUri
                    this@MainActivity.feedUri = null
                    filePathCallback?.onReceiveValue(arrayOf(u!!))
                    return true
                }
                // Auto-Pilot: Colab ke upload box ko khud notebook file de do
                if (this@MainActivity.feedingNotebook) {
                    this@MainActivity.feedingNotebook = false
                    val nb = this@MainActivity.effectiveNotebookFile()
                    if (nb != null) {
                        try {
                            val uri = FileProvider.getUriForFile(
                                this@MainActivity,
                                "${this@MainActivity.packageName}.fileprovider",
                                nb
                            )
                            filePathCallback?.onReceiveValue(arrayOf(uri))
                            this@MainActivity.setApStatus("📤 Notebook Colab par upload ho raha hai...")
                            return true
                        } catch (e: Exception) {
                            // fall through to manual chooser
                        }
                    }
                }
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                fileChooserLauncher.launch(intent)
                return true
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val targetSubFolder = when {
                    tag == "FLOW" -> "AIVideoStudio/2_Veo_Clips"
                    fileName.endsWith(".png") || fileName.endsWith(".jpg") -> "AIVideoStudio/1_Generated_Frames"
                    else -> "AIVideoStudio/3_Final_Videos"
                }
                val request = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mimeType)
                    addRequestHeader("User-Agent", userAgent)
                    setTitle(fileName)
                    setDescription("Saving to $targetSubFolder")
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "$targetSubFolder/$fileName")
                }
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                Toast.makeText(this, "Saved to Downloads/$targetSubFolder/$fileName", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun injectColabWatcher(webView: WebView) {
        val js = "(function(){if(window.__cw)return;window.__cw=true;let rc=false;setInterval(()=>{if(!rc&&!location.href.includes('accounts.google.com')){const els=Array.from(document.querySelectorAll('button,[role=\"menuitem\"],[role=\"button\"]'));const t=els.find(e=>e.innerText&&e.innerText.trim()==='Run all');if(t){t.click();rc=true;}}const txt=document.body?document.body.innerText:'';const m=txt.match(/https:\\/\\/[a-zA-Z0-9-]+\\.trycloudflare\\.com/);if(m&&m[0])AndroidBridge.reportColabUrl(m[0]);},3000);})();"
        webView.evaluateJavascript(js, null)
    }

    /**
     * Studio watcher: Step 1 mukammal hote hi Step 2 KHUD shuru — chahe Step 1
     * app ke 'Video Banao' se chala ho ya dashboard se hath se. Step 2 sirf tab
     * auto chalta hai jab kam az kam aik Veo clip mojood ho; clips na hon to
     * status mein bata deta hai aur clips aate hi khud chala deta hai.
     */
    private fun injectStudioAutoStepWatcher(webView: WebView) {
        val js = "(function(){if(window.__asw)return;window.__asw=true;window.__asNoClip=false;window.__asAllClip=false;" +
            "setInterval(function(){var t=document.body?document.body.innerText:'';" +
            "if(t.indexOf('storyboard aur consistent frames ban rahe hain')>-1){window.__asNoClip=false;window.__asAllClip=false;return;}" +
            "if(t.indexOf('render ho rahi hai')>-1)return;" +
            "if(t.indexOf('Final Video Complete')>-1)return;" +
            "if(t.indexOf('Scenes & Consistent Frames Ready')>-1){" +
            "var clips=(t.match(/Clip Ready/g)||[]).length;" +
            "if(clips===0&&!window.__asNoClip){window.__asNoClip=true;AndroidBridge.notifyAutoStep('✅ Step 1 ho gaya hai. Clips Flow se khud aa rahe hain — aakhri clip lagte hi Step 2 khud chal jayega.');}" +
            "else if(clips>0&&!window.__asAllClip){window.__asAllClip=true;AndroidBridge.notifyAutoStep('🎞️ Clips dashboard mein lag rahe hain — Step 2 khud chalne wala hai.');}" +
            "}},4000);})();"
        webView.evaluateJavascript(js, null)
    }

    private fun injectApiKeyWatcher(webView: WebView) {
        // v3.0.1: AI Studio key ko aksar CSS se chhota karke dikhata hai —
        // innerText par kata hua (masked) text milta hai aur purana watcher miss
        // kar deta tha. Ab poora DOM text (textContent) + input values bhi scan
        // hote hain, aur lambai ki sakht shart (35) hata di hai.
        val js = "(function(){if(window.__aw)return;window.__aw=true;" +
            "function test(s){if(!s)return null;var m=s.match(/AIza[0-9A-Za-z\\-_]{25,}/);return m?m[0]:null;}" +
            "function scan(){if(location.href.includes('accounts.google.com'))return;" +
            "var k=test(document.body?document.body.textContent:'');" +
            "if(!k)k=test(document.body?document.body.innerText:'');" +
            "if(!k){var els=document.querySelectorAll('input,textarea');for(var i=0;i<els.length;i++){k=test(els[i].value||'');if(k)break;}}" +
            "if(k)AndroidBridge.reportApiKey(k);}" +
            "setInterval(scan,2500);setTimeout(scan,800);})();"
        webView.evaluateJavascript(js, null)
    }
}
