package com.safdowser.gecko

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.safdowser.gecko.ui.GeckoApp
import com.safdowser.gecko.ui.theme.GeckoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Security audit 2026-11-21: FLAG_SECURE — browsing content never
        // appears in screenshots, screen recordings or the Android Recents
        // thumbnail. What happens in this browser stays in this browser.
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()
        setContent {
            GeckoTheme {
                GeckoApp()
            }
        }
    }
}
