package com.safdowser.gecko.ui

import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.safdowser.gecko.vpn.OpenVpnController
import com.safdowser.gecko.vpn.VpnServer
import com.safdowser.gecko.vpn.VpnServerRepository
import com.tim.basevpn.state.ConnectionState
import kotlinx.coroutines.launch

/**
 * VPN screen: VPN Gate server list (fetched live on the phone) + per-app
 * OpenVPN tunnel. Reuses Safdowser's tunnel service as-is — the TUN is
 * restricted to this app only (addAllowedApplication), never device-wide.
 * Gecko networking runs in the app process, so the tunnel captures it.
 */
@Composable
fun VpnScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val vpnState by OpenVpnController.state.collectAsState()
    val activeServer by OpenVpnController.activeServer.collectAsState()
    val vpnLog by OpenVpnController.logLines.collectAsState()
    val vpnError by OpenVpnController.lastError.collectAsState()

    var servers by remember { mutableStateOf<List<VpnServer>>(emptyList()) }
    var loadingServers by remember { mutableStateOf(false) }
    var serversError by remember { mutableStateOf<String?>(null) }
    var pendingServer by remember { mutableStateOf<VpnServer?>(null) }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            pendingServer?.let { OpenVpnController.connect(context, it) }
        }
        pendingServer = null
    }

    fun requestConnect(server: VpnServer) {
        val prepareIntent = VpnService.prepare(context)
        if (prepareIntent != null) {
            pendingServer = server
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            OpenVpnController.connect(context, server)
        }
    }

    val scope = rememberCoroutineScope()

    fun loadServers() {
        loadingServers = true
        serversError = null
        scope.launch {
            try {
                val list = VpnServerRepository().fetchLiveFreeVpnGateServers()
                servers = list
                if (list.isEmpty()) serversError = "No servers found — check your internet connection."
            } catch (e: Exception) {
                serversError = "Could not load the server list: ${e.message}"
            } finally {
                loadingServers = false
            }
        }
    }

    LaunchedEffect(Unit) { loadServers() }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("VPN", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            item {
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Status: ${vpnState.name}", fontWeight = FontWeight.Bold)
                        activeServer?.let {
                            Text("${it.countryName} · ${it.ipAddress}")
                        }
                        Text(
                            "Per-app VPN — the tunnel covers this browser only, " +
                                "never the whole device.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        if (vpnState == ConnectionState.CONNECTED) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(onClick = { OpenVpnController.disconnect(context) }) {
                                Text("Disconnect")
                            }
                        }
                    }
                }
            }

            if (vpnError != null) {
                item {
                    Text(
                        "Last error: $vpnError",
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "VPN Gate servers",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = { loadServers() },
                        enabled = !loadingServers
                    ) { Text("Refresh") }
                }
                if (loadingServers) Text("Loading servers…")
                serversError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }

            items(servers, key = { it.id }) { server ->
                val uptimeDays = (server.uptimeMs / 86_400_000L).toInt()
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            "${server.countryName} (${server.countryCode}) · ${server.ipAddress}",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Score ${server.score} · Ping ${server.pingMs} ms · Uptime ${uptimeDays}d",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = { requestConnect(server) },
                            enabled = vpnState != ConnectionState.CONNECTING
                        ) { Text("Connect") }
                    }
                }
            }

            if (vpnLog.isNotEmpty()) {
                item {
                    Text(
                        "Connection log",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                    )
                    vpnLog.takeLast(20).forEach { line ->
                        Text(line, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
