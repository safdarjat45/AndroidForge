package com.safdowser.gecko.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * Harrier brand palette: deep midnight navy (from the icon artwork,
 * #1A1534 family) with the hawk's amber eye as the single accent.
 * One dark scheme only — the browser always presents the same identity.
 */
private val HarrierColors = darkColorScheme(
    primary = Color(0xFFF2B33D),          // harrier amber (the eye)
    onPrimary = Color(0xFF1A1534),
    secondary = Color(0xFF8FA8C8),        // slate blue-grey (the plumage)
    onSecondary = Color(0xFF0D0B21),
    tertiary = Color(0xFF8FA8C8),
    background = Color(0xFF0D0B21),       // deepest navy
    onBackground = Color(0xFFF4F1FF),
    surface = Color(0xFF171331),
    onSurface = Color(0xFFF4F1FF),
    surfaceVariant = Color(0xFF262058),
    onSurfaceVariant = Color(0xFFB9B3D9),
    error = Color(0xFFFF6B6B),
    onError = Color(0xFF1A1534)
)

@Composable
fun GeckoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = HarrierColors,
        content = content
    )
}
