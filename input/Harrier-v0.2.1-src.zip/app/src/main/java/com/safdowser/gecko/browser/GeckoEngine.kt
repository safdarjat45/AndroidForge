package com.safdowser.gecko.browser

import android.content.Context
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import java.io.File

/**
 * The single shared GeckoRuntime for the whole app (one engine, many tabs).
 *
 * Baseline privacy settings (PLAN.md v0.1 §3):
 * - Enhanced Tracking Protection STRICT, anti-tracking STRICT, third-party
 *   tracker cookies blocked, Safe Browsing on.
 * - Locale en-US (real locale — Gecko sets Accept-Language + JS Intl properly).
 * - DNS-over-HTTPS (TRR) explicitly OFF by choice (TRR_MODE_DISABLED): the
 *   engine uses the OS resolver, which lives inside the per-app VPN tunnel
 *   when the tunnel is up. DoH with a third-party resolver would leak DNS
 *   answers outside the tunnel's DNS.
 * - Fingerprinting protection (FPP) ON. This is NOT resistFingerprinting:
 *   FPP blocks known fingerprinting scripts; it does not spoof timezone,
 *   screen size or canvas the way Safdowser's WebView JS pipeline does.
 *   There is no supported GeckoView API for timezone or fake-GPS spoofing.
 * - Web fonts on (toggle later), JavaScript on, Global Privacy Control on.
 * - extensionsWebAPIEnabled: lets addons.mozilla.org pages offer installs
 *   through the mozAddonManager web API (the Firefox-for-Android flow).
 */
object GeckoEngine {

    @Volatile
    private var runtime: GeckoRuntime? = null

    fun runtime(context: Context): GeckoRuntime {
        return runtime ?: synchronized(this) {
            runtime ?: createWithFallbacks(context.applicationContext).also {
                runtime = it
            }
        }
    }

    /**
     * Startup must never kill the app (v0.2.0 field report: "app does not
     * open"). Three attempts, most-hardened first:
     *  1. Full settings + the audit config prefs (WebRTC off etc.).
     *  2. Full settings, no config file — if the YAML or its path is the
     *     problem on a given device, the engine still starts hardened by
     *     the typed settings (ETP strict, FPP, TRR off).
     *  3. Bare engine defaults — a plain browser that OPENS is always
     *     better than a hardened one that crashes on launch.
     * If all three throw, the exception propagates to the UI, which shows
     * an error screen instead of the process dying silently.
     */
    private fun createWithFallbacks(context: Context): GeckoRuntime {
        runCatching {
            return GeckoRuntime.create(context, buildSettings(context, useConfig = true))
        }
        runCatching {
            return GeckoRuntime.create(context, buildSettings(context, useConfig = false))
        }
        return GeckoRuntime.create(context, GeckoRuntimeSettings.Builder().build())
    }

    /**
     * Copies the bundled geckoview-config.yaml (security-audit default prefs:
     * WebRTC off, HTTPS-only, geolocation off, site isolation, no telemetry)
     * from assets into app-private storage and returns its path, because
     * configFilePath needs a real filesystem path. Null on any failure —
     * the runtime then starts with engine defaults instead of crashing.
     */
    private fun configFilePath(context: Context): String? = runCatching {
        val target = File(context.filesDir, "geckoview-config.yaml")
        context.assets.open("geckoview-config.yaml").use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        }
        target.absolutePath
    }.getOrNull()

    private fun buildSettings(context: Context, useConfig: Boolean): GeckoRuntimeSettings {
        val contentBlocking = ContentBlocking.Settings.Builder()
            .build()
            .setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
            .setAntiTracking(ContentBlocking.AntiTracking.STRICT)
            .setCookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
            .setSafeBrowsing(ContentBlocking.SafeBrowsing.DEFAULT)

        val builder = GeckoRuntimeSettings.Builder()
            .javaScriptEnabled(true)
            .contentBlocking(contentBlocking)
            .locales(arrayOf("en-US"))
            // DoH explicitly off by choice — use the OS resolver inside the TUN.
            .trustedRecursiveResolverMode(GeckoRuntimeSettings.TRR_MODE_DISABLED)
            .webFontsEnabled(true)
            .extensionsWebAPIEnabled(true)
            .globalPrivacyControlEnabled(true)

        // Security-audit default prefs (WebRTC off, HTTPS-only, geo off,
        // site isolation, telemetry off) — see assets/geckoview-config.yaml.
        if (useConfig) {
            configFilePath(context)?.let { builder.configFilePath(it) }
        }

        return builder
            .build()
            // FPP is a setter on the settings object, not a Builder method.
            .setFingerprintingProtection(true)
    }
}
