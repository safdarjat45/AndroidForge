package com.safdowser.browser.vpn

import android.content.Context
import android.content.Intent
import android.os.Build
import com.tim.basevpn.state.ConnectionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * Real OpenVPN tunnel control (VPN Gate servers).
 *
 * The tunnel is provided by [SafdowserOpenVpnService], which restricts it to the
 * Safdowser app only (per-app VPN): the rest of the device is untouched, and the
 * browser — whose traffic could reveal the real IP — cannot leak outside it.
 */
object OpenVpnController {

    private val _state = MutableStateFlow(ConnectionState.DISCONNECTED)
    val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private val _activeServer = MutableStateFlow<VpnServer?>(null)
    val activeServer: StateFlow<VpnServer?> = _activeServer.asStateFlow()

    /** Called by SafdowserOpenVpnService (same process) whenever the tunnel state changes. */
    fun onTunnelState(newState: ConnectionState) {
        _state.value = newState
        if (newState == ConnectionState.DISCONNECTED) {
            _activeServer.value = null
        }
    }

    fun connect(context: Context, server: VpnServer) {
        _activeServer.value = server
        _state.value = ConnectionState.CONNECTING
        val intent = Intent(context.applicationContext, SafdowserOpenVpnService::class.java).apply {
            action = SafdowserOpenVpnService.ACTION_START
            putExtra(SafdowserOpenVpnService.EXTRA_CONFIG, sanitizeOvpnConfig(server.ovpnConfig))
            putExtra(SafdowserOpenVpnService.EXTRA_LABEL, "${server.countryName} · ${server.ipAddress}")
            putExtra(SafdowserOpenVpnService.EXTRA_USERNAME, server.username)
            putExtra(SafdowserOpenVpnService.EXTRA_PASSWORD, server.password)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.applicationContext.startForegroundService(intent)
        } else {
            context.applicationContext.startService(intent)
        }
    }

    fun disconnect(context: Context) {
        val intent = Intent(context.applicationContext, SafdowserOpenVpnService::class.java).apply {
            action = SafdowserOpenVpnService.ACTION_STOP
        }
        runCatching { context.applicationContext.startService(intent) }
        _activeServer.value = null
        _state.value = ConnectionState.DISCONNECTED
    }

    val isConnected: Boolean
        get() = _state.value == ConnectionState.CONNECTED

    /** Fetches the public exit IP as seen by websites right now (goes through the tunnel when it is up). */
    suspend fun fetchExitIp(): String? = withContext(Dispatchers.IO) {
        val endpoints = listOf("https://api.ipify.org", "https://icanhazip.com")
        for (endpoint in endpoints) {
            val ip = runCatching {
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                conn.inputStream.bufferedReader().use { it.readText() }.trim()
            }.getOrNull()
            if (!ip.isNullOrBlank() && ip.length <= 45) return@withContext ip
        }
        null
    }
}
