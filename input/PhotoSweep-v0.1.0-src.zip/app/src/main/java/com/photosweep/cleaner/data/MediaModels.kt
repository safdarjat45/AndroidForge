package com.photosweep.cleaner.data

import android.net.Uri

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val size: Long,
    val width: Int,
    val height: Int,
    val isVideo: Boolean,
    val relativePath: String,
    val dateModified: Long,
    var exactHash: String? = null,
    var pHash: Long? = null,
    var sharpness: Double = -1.0
) {
    val megapixels: Double get() = (width.toLong() * height.toLong()) / 1_000_000.0
    val isScreenshot: Boolean get() = relativePath.contains("screenshot", ignoreCase = true) ||
        name.startsWith("Screenshot", ignoreCase = true)
}

/** A group of duplicates/similar items. bestId = the copy we suggest keeping. */
data class MediaGroup(
    val key: String,
    val items: List<MediaItem>,
    val bestId: Long,
    val similar: Boolean
) {
    /** Bytes freed if every non-best copy is removed. */
    val reclaimable: Long get() = items.filter { it.id != bestId }.sumOf { it.size }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 MB"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var u = 0
    while (v >= 1024 && u < units.lastIndex) { v /= 1024; u++ }
    return String.format("%.1f %s", v, units[u])
}
