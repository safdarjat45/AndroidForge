package com.photosweep.cleaner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.photosweep.cleaner.data.MediaGroup
import com.photosweep.cleaner.data.MediaItem
import com.photosweep.cleaner.data.formatBytes
import com.photosweep.cleaner.ui.AppViewModel
import kotlin.math.roundToInt

private enum class Screen { Home, Groups, GroupDetail, Swipe, Trash, Settings, Premium }
private enum class Category { Exact, Similar, Blurry, Screenshots, LargeVideos }

private val Bg = Color(0xFF0D1B2A)
private val Surface = Color(0xFF16283D)
private val Accent = Color(0xFF4CC9F0)
private val Amber = Color(0xFFF2B33D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Surface)) {
                PhotoSweepApp()
            }
        }
    }
}

private fun mediaPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

@Composable
private fun PhotoSweepApp(vm: AppViewModel = viewModel()) {
    val context = LocalContext.current
    var screen by remember { mutableStateOf(Screen.Home) }
    var category by remember { mutableStateOf(Category.Exact) }
    var openGroup by remember { mutableStateOf<MediaGroup?>(null) }
    var hasPermission by remember {
        mutableStateOf(mediaPermissions().all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        })
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        hasPermission = res.values.any { it }
    }
    val consentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        vm.onConsentResult(res.resultCode == android.app.Activity.RESULT_OK)
    }
    LaunchedEffect(vm.pendingIntent) {
        vm.pendingIntent?.let {
            consentLauncher.launch(IntentSenderRequest.Builder(it.intentSender).build())
        }
    }

    Scaffold(containerColor = Bg) { pad ->
        Box(modifier = Modifier.padding(pad).fillMaxSize()) {
            when (screen) {
                Screen.Home -> HomeScreen(
                    vm = vm,
                    hasPermission = hasPermission,
                    onAskPermission = { permLauncher.launch(mediaPermissions()) },
                    onOpenCategory = { category = it; screen = Screen.Groups },
                    onSwipe = { screen = Screen.Swipe },
                    onTrash = { vm.loadTrash(); screen = Screen.Trash },
                    onSettings = { screen = Screen.Settings },
                    onPremium = { screen = Screen.Premium }
                )
                Screen.Groups -> GroupsScreen(
                    vm = vm, category = category,
                    onBack = { screen = Screen.Home },
                    onOpenGroup = { openGroup = it; screen = Screen.GroupDetail },
                    onClean = { screen = Screen.Home }
                )
                Screen.GroupDetail -> {
                    val g = openGroup
                    if (g == null) screen = Screen.Home else GroupDetailScreen(
                        vm = vm, group = g,
                        onBack = { screen = Screen.Groups },
                        onClean = { screen = Screen.Home }
                    )
                }
                Screen.Swipe -> SwipeScreen(vm = vm, onBack = { screen = Screen.Home }, onClean = { screen = Screen.Home })
                Screen.Trash -> TrashScreen(vm = vm, onBack = { screen = Screen.Home })
                Screen.Settings -> SettingsScreen(vm = vm, onBack = { screen = Screen.Home })
                Screen.Premium -> PremiumScreen(onBack = { screen = Screen.Home })
            }
        }
    }
}

@Composable
private fun TopBar(title: String, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        }
        Text(title, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
private fun HomeScreen(
    vm: AppViewModel,
    hasPermission: Boolean,
    onAskPermission: () -> Unit,
    onOpenCategory: (Category) -> Unit,
    onSwipe: () -> Unit,
    onTrash: () -> Unit,
    onSettings: () -> Unit,
    onPremium: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("PhotoSweep") {
            IconButton(onClick = onTrash) { Icon(Icons.Filled.Delete, "Trash", tint = Color.White) }
            IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Settings", tint = Color.White) }
        }
        if (!hasPermission) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Filled.PhotoLibrary, null, tint = Accent, modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(16.dp))
                Text("PhotoSweep needs access to your photos and videos to find duplicates. Everything stays on your phone — nothing is ever uploaded.",
                    color = Color.White, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(20.dp))
                Button(onClick = onAskPermission, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                    Text("Allow access", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
            return
        }
        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (vm.scanning) {
                            Text("Scanning your library…", color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text(vm.progressStage, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(12.dp))
                            LinearProgressIndicator(
                                progress = { if (vm.progressTotal > 0) vm.progressDone.toFloat() / vm.progressTotal else 0f },
                                modifier = Modifier.fillMaxWidth(), color = Accent
                            )
                            Spacer(Modifier.height(6.dp))
                            Text("${vm.progressDone} / ${vm.progressTotal}", color = Color.LightGray,
                                style = MaterialTheme.typography.bodySmall)
                        } else if (vm.scanDone && vm.result != null) {
                            val r = vm.result!!
                            Text("You can free up", color = Color.LightGray)
                            Text(formatBytes(r.totalReclaimable), color = Amber,
                                style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                            Text("${r.totalScanned} photos & videos scanned", color = Color.LightGray,
                                style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { vm.startScan() },
                                colors = ButtonDefaults.buttonColors(containerColor = Surface)) {
                                Text("Scan again", color = Accent)
                            }
                        } else {
                            Text("Find duplicates, similar shots, blurry photos and big videos — and free up space safely.",
                                color = Color.White, style = MaterialTheme.typography.bodyLarge)
                            vm.scanError?.let {
                                Spacer(Modifier.height(8.dp))
                                Text(it, color = Color(0xFFFF8080), style = MaterialTheme.typography.bodySmall)
                            }
                            Spacer(Modifier.height(14.dp))
                            Button(onClick = { vm.startScan() },
                                colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                                Text("Start scan", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
            val r = vm.result
            if (vm.scanDone && r != null) {
                item { CategoryCard("Exact duplicates", "${r.exactGroups.size} groups", r.exactGroups.sumOf { it.reclaimable }, Icons.Filled.CopyAll) { onOpenCategory(Category.Exact) } }
                item { CategoryCard("Similar photos", "${r.similarGroups.size} groups", r.similarGroups.sumOf { it.reclaimable }, Icons.Filled.Compare) { onOpenCategory(Category.Similar) } }
                item { CategoryCard("Blurry photos", "${r.blurry.size} photos", r.blurry.sumOf { it.size }, Icons.Filled.BlurOn) { onOpenCategory(Category.Blurry) } }
                item { CategoryCard("Screenshots", "${r.screenshots.size} photos", r.screenshots.sumOf { it.size }, Icons.Filled.Screenshot) { onOpenCategory(Category.Screenshots) } }
                item { CategoryCard("Large videos", "${r.largeVideos.size} videos", r.largeVideos.sumOf { it.size }, Icons.Filled.VideoLibrary) { onOpenCategory(Category.LargeVideos) } }
                item {
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onSwipe, modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Amber)) {
                        Icon(Icons.Filled.Swipe, null, tint = Color.Black)
                        Spacer(Modifier.width(8.dp))
                        Text("Review by swiping", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = onPremium, modifier = Modifier.fillMaxWidth()) {
                        Text("PhotoSweep Premium — honest pricing, no weekly traps", color = Amber)
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun CategoryCard(title: String, subtitle: String, bytes: Long, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() }) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
            Text(formatBytes(bytes), color = Amber, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CleanBar(vm: AppViewModel, onClean: () -> Unit) {
    if (vm.selected.isEmpty()) return
    var busy by remember { mutableStateOf(false) }
    Surface(color = Surface) {
        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("${vm.selected.size} selected", color = Color.White, fontWeight = FontWeight.Bold)
                Text(formatBytes(vm.selectedBytes) + " — goes to Trash for 30 days, restorable",
                    color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { vm.clearSelection() }) { Text("Clear", color = Color.LightGray) }
            Button(enabled = !busy, onClick = { busy = true; vm.trashSelected { busy = false; onClean() } },
                colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                Text("Clean", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun GroupsScreen(vm: AppViewModel, category: Category, onBack: () -> Unit, onOpenGroup: (MediaGroup) -> Unit, onClean: () -> Unit) {
    val r = vm.result
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(when (category) {
            Category.Exact -> "Exact duplicates"
            Category.Similar -> "Similar photos"
            Category.Blurry -> "Blurry photos"
            Category.Screenshots -> "Screenshots"
            Category.LargeVideos -> "Large videos"
        }, onBack = onBack)
        if (r == null) {
            Text("Run a scan first.", color = Color.LightGray, modifier = Modifier.padding(16.dp))
        } else when (category) {
            Category.Exact, Category.Similar -> {
                val groups = if (category == Category.Exact) r.exactGroups else r.similarGroups
                if (groups.isEmpty()) Text("Nothing found here. ", color = Color.LightGray, modifier = Modifier.padding(16.dp))
                LazyColumn(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    items(groups, key = { it.key }) { g ->
                        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onOpenGroup(g) }) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                val best = g.items.firstOrNull { it.id == g.bestId } ?: g.items.first()
                                AsyncImage(model = best.uri, contentDescription = null, contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)))
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${g.items.size} copies", color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("Keep the best, free " + formatBytes(g.reclaimable), color = Color.LightGray,
                                        style = MaterialTheme.typography.bodySmall)
                                }
                                Icon(Icons.Filled.ChevronRight, null, tint = Color.LightGray)
                            }
                        }
                    }
                }
            }
            Category.Blurry, Category.Screenshots, Category.LargeVideos -> {
                val list = when (category) {
                    Category.Blurry -> r.blurry
                    Category.Screenshots -> r.screenshots
                    else -> r.largeVideos
                }
                if (list.isEmpty()) Text("Nothing found here.", color = Color.LightGray, modifier = Modifier.padding(16.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.weight(1f).padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(list, key = { it.id }) { item -> SelectableThumb(vm, item) }
                }
            }
        }
        CleanBar(vm, onClean)
    }
}

@Composable
private fun SelectableThumb(vm: AppViewModel, item: MediaItem, bestBadge: Boolean = false) {
    val isSel = vm.selected.containsKey(item.id)
    Box(modifier = Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp))
        .background(Surface).clickable { vm.toggleSelect(item) }) {
        AsyncImage(model = item.uri, contentDescription = item.name, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize())
        if (bestBadge) {
            Text("BEST", color = Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart).background(Amber, RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 2.dp))
        }
        Box(modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)
            .background(if (isSel) Accent else Color(0x88000000), RoundedCornerShape(50))
            .size(22.dp), contentAlignment = Alignment.Center) {
            if (isSel) Icon(Icons.Filled.Check, null, tint = Color.Black, modifier = Modifier.size(14.dp))
        }
        Text(formatBytes(item.size), color = Color.White, style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.align(Alignment.BottomStart).background(Color(0x88000000)).padding(horizontal = 4.dp, vertical = 1.dp))
    }
}

@Composable
private fun GroupDetailScreen(vm: AppViewModel, group: MediaGroup, onBack: () -> Unit, onClean: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(if (group.similar) "Similar photos" else "Exact duplicates", onBack = onBack)
        Text("The BEST copy is marked — it is never pre-selected. Tap any copy to select or unselect it.",
            color = Color.LightGray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.weight(1f).padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(group.items, key = { it.id }) { item ->
                Column {
                    SelectableThumb(vm, item, bestBadge = item.id == group.bestId)
                    Text(item.name, color = Color.LightGray, style = MaterialTheme.typography.labelSmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${item.width}×${item.height} · " + formatBytes(item.size), color = Color.Gray,
                        style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        CleanBar(vm, onClean)
    }
}

@Composable
private fun SwipeScreen(vm: AppViewModel, onBack: () -> Unit, onClean: () -> Unit) {
    val r = vm.result
    val queue = remember(r) {
        val groups = (r?.exactGroups ?: emptyList()) + (r?.similarGroups ?: emptyList())
        groups.flatMap { g -> g.items.filter { it.id != g.bestId } }
    }
    var index by remember { mutableStateOf(0) }
    var offsetX by remember { mutableStateOf(0f) }
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Swipe review", onBack = onBack)
        if (r == null || queue.isEmpty() || index >= queue.size) {
            Column(modifier = Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center) {
                Text("All reviewed. 🎉", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("Swipe left = move to Trash · Swipe right = keep. Nothing is deleted without the system asking you first.",
                    color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
        } else {
            val item = queue[index]
            Text("${index + 1} of ${queue.size} — extra copies only, the best copy is never shown here",
                color = Color.LightGray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
            Spacer(Modifier.height(10.dp))
            Box(modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                AsyncImage(model = item.uri, contentDescription = item.name, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(16.dp))
                        .offset { IntOffset(offsetX.roundToInt(), 0) }
                        .pointerInput(item.id) {
                            detectHorizontalDragGestures(
                                onDragEnd = {
                                    when {
                                        offsetX < -260 -> { vm.selected[item.id] = item; index++ }
                                        offsetX > 260 -> { vm.selected.remove(item.id); index++ }
                                    }
                                    offsetX = 0f
                                },
                                onDragCancel = { offsetX = 0f }
                            ) { _, drag -> offsetX += drag }
                        })
            }
            Text(item.name + " · " + formatBytes(item.size), color = Color.LightGray,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.align(Alignment.CenterHorizontally))
            Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Button(onClick = { vm.selected[item.id] = item; index++ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE05252))) {
                    Icon(Icons.Filled.Delete, null); Spacer(Modifier.width(6.dp)); Text("Trash it")
                }
                Button(onClick = { vm.selected.remove(item.id); index++ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3FA34D))) {
                    Icon(Icons.Filled.Check, null); Spacer(Modifier.width(6.dp)); Text("Keep")
                }
            }
        }
        CleanBar(vm, onClean)
    }
}

@Composable
private fun TrashScreen(vm: AppViewModel, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Trash", onBack = onBack)
        Text("Items here are kept by Android for about 30 days. Restore anything you still need, or delete forever.",
            color = Color.LightGray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(8.dp))
        if (vm.trashItems.isEmpty()) {
            Text(if (vm.trashLoaded) "Trash is empty." else "Loading…", color = Color.LightGray, modifier = Modifier.padding(16.dp))
        }
        LazyColumn(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
            items(vm.trashItems, key = { it.id }) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(model = item.uri, contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)))
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(formatBytes(item.size), color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { vm.restoreFromTrash(listOf(item)) }) { Text("Restore", color = Accent) }
                        TextButton(onClick = { vm.deleteForever(listOf(item)) }) { Text("Delete", color = Color(0xFFFF8080)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Settings", onBack = onBack)
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Similar-photo strictness", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Lower = only near-identical shots. Higher = also catches edited and resized copies.",
                color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Slider(
                value = vm.similarityThreshold.toFloat(),
                onValueChange = { vm.setSimilarity(it.roundToInt()) },
                valueRange = 2f..14f, steps = 11, colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
            )
            Text("Current: ${vm.similarityThreshold}", color = Accent, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(24.dp))
            Text("Privacy", color = Color.White, fontWeight = FontWeight.Bold)
            Text("PhotoSweep works 100% on your phone. No account, no uploads, no tracking of your photos. Scanning covers both internal storage and SD card.",
                color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(24.dp))
            Text("PhotoSweep 0.1.0", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PremiumScreen(onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("Premium", onBack = onBack)
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Honest pricing. Always.", color = Amber, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("No weekly subscriptions. No fake free trials that charge you in secret. No ads while you clean.",
                color = Color.White, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(16.dp))
            listOf(
                "Free forever: full scan, full review, Trash & restore",
                "Premium: unlimited cleaning, scheduled auto-clean, video compression",
                "One fair yearly price — or a single lifetime payment"
            ).forEach {
                Row(modifier = Modifier.padding(vertical = 4.dp)) {
                    Icon(Icons.Filled.Check, null, tint = Accent, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(it, color = Color.LightGray, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Spacer(Modifier.height(20.dp))
            Text("Premium arrives with the Play Store release.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
}
