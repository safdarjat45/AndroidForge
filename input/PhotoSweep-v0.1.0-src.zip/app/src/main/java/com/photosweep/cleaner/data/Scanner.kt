package com.photosweep.cleaner.data

import android.content.ContentResolver
import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import kotlin.math.cos
import kotlin.math.PI
import kotlin.math.sqrt

object Scanner {

    private const val LARGE_VIDEO_BYTES = 100L * 1024 * 1024

    suspend fun loadLibrary(cr: ContentResolver, trashed: Boolean): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()
        val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.WIDTH,
            MediaStore.Files.FileColumns.HEIGHT,
            MediaStore.Files.FileColumns.MEDIA_TYPE,
            MediaStore.Files.FileColumns.RELATIVE_PATH,
            MediaStore.Files.FileColumns.DATE_MODIFIED
        )
        val selection = "${MediaStore.Files.FileColumns.IS_TRASHED} = ? AND " +
            "(${MediaStore.Files.FileColumns.MEDIA_TYPE} = ? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE} = ?)"
        val args = arrayOf(
            if (trashed) "1" else "0",
            MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
            MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
        )
        cr.query(collection, projection, selection, args, "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC")?.use { c ->
            val idI = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val nameI = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val sizeI = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            val wI = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.WIDTH)
            val hI = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.HEIGHT)
            val typeI = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
            val pathI = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.RELATIVE_PATH)
            val dateI = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
            while (c.moveToNext()) {
                val id = c.getLong(idI)
                items += MediaItem(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id),
                    name = c.getString(nameI) ?: "media",
                    size = c.getLong(sizeI),
                    width = c.getInt(wI),
                    height = c.getInt(hI),
                    isVideo = c.getInt(typeI) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO,
                    relativePath = c.getString(pathI) ?: "",
                    dateModified = c.getLong(dateI)
                )
            }
        }
        items
    }

    /** Full MD5 for images; size + head/tail MD5 for videos (fast, still reliable). */
    private fun computeExactHash(cr: ContentResolver, item: MediaItem): String? {
        return try {
            val md = MessageDigest.getInstance("MD5")
            cr.openInputStream(item.uri)?.use { input ->
                val buf = ByteArray(256 * 1024)
                if (item.isVideo) {
                    // head + tail sample is enough with the identical size
                    var read = input.read(buf)
                    if (read > 0) md.update(buf, 0, read)
                    md.update(item.size.toString().toByteArray())
                } else {
                    while (true) {
                        val read = input.read(buf)
                        if (read <= 0) break
                        md.update(buf, 0, read)
                    }
                }
            } ?: return null
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            null
        }
    }

    /** 64-bit perceptual hash from a 32x32 grayscale thumbnail (DCT based). */
    private fun computePHash(cr: ContentResolver, item: MediaItem): Long? {
        return try {
            val bmp: Bitmap = cr.loadThumbnail(item.uri, Size(32, 32), null)
            val gray = DoubleArray(32 * 32)
            val px = IntArray(32 * 32)
            val scaled = if (bmp.width == 32 && bmp.height == 32) bmp else Bitmap.createScaledBitmap(bmp, 32, 32, true)
            scaled.getPixels(px, 0, 32, 0, 0, 32, 32)
            for (i in px.indices) {
                val c = px[i]
                gray[i] = 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)
            }
            // 2D DCT, keep top-left 8x8
            val dct = DoubleArray(64)
            for (u in 0 until 8) {
                for (v in 0 until 8) {
                    var sum = 0.0
                    for (x in 0 until 32) {
                        for (y in 0 until 32) {
                            sum += gray[y * 32 + x] *
                                cos(((2 * x + 1) * u * PI) / 64.0) *
                                cos(((2 * y + 1) * v * PI) / 64.0)
                        }
                    }
                    dct[v * 8 + u] = sum
                }
            }
            val sorted = dct.copyOfRange(1, 64).sorted()
            val median = sorted[sorted.size / 2]
            var hash = 0L
            for (i in 1 until 64) {
                if (dct[i] > median) hash = hash or (1L shl (i - 1))
            }
            hash
        } catch (e: Exception) {
            null
        }
    }

    /** Laplacian variance on a small thumbnail — low value = likely blurry. */
    private fun computeSharpness(cr: ContentResolver, item: MediaItem): Double {
        return try {
            val bmp: Bitmap = cr.loadThumbnail(item.uri, Size(96, 96), null)
            val w = bmp.width; val h = bmp.height
            if (w < 8 || h < 8) return -1.0
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            fun g(x: Int, y: Int): Double {
                val c = px[y * w + x]
                return 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)
            }
            var sum = 0.0; var sumSq = 0.0; var n = 0
            for (y in 1 until h - 1) {
                for (x in 1 until w - 1) {
                    val lap = 4 * g(x, y) - g(x - 1, y) - g(x + 1, y) - g(x, y - 1) - g(x, y + 1)
                    sum += lap; sumSq += lap * lap; n++
                }
            }
            if (n == 0) -1.0 else (sumSq / n) - (sum / n) * (sum / n)
        } catch (e: Exception) {
            -1.0
        }
    }

    data class ScanResult(
        val exactGroups: List<MediaGroup>,
        val similarGroups: List<MediaGroup>,
        val blurry: List<MediaItem>,
        val screenshots: List<MediaItem>,
        val largeVideos: List<MediaItem>,
        val totalScanned: Int
    ) {
        val totalReclaimable: Long
            get() = exactGroups.sumOf { it.reclaimable } + similarGroups.sumOf { it.reclaimable } +
                screenshots.sumOf { it.size } + largeVideos.sumOf { it.size }
    }

    private fun bestOf(items: List<MediaItem>): Long =
        items.maxWithOrNull(
            compareBy<MediaItem> { it.megapixels }.thenBy { it.size }.thenBy { it.sharpness }
        )?.id ?: items.first().id

    suspend fun scan(
        cr: ContentResolver,
        similarityThreshold: Int,
        onProgress: (done: Int, total: Int, stage: String) -> Unit
    ): ScanResult = withContext(Dispatchers.Default) {
        val library = loadLibrary(cr, trashed = false)
        val images = library.filter { !it.isVideo }
        val videos = library.filter { it.isVideo }
        onProgress(0, library.size, "Reading library")

        // ---- exact duplicates: same size first, then hash
        val exactGroups = mutableListOf<MediaGroup>()
        val inExact = mutableSetOf<Long>()
        val bySize = library.groupBy { it.size }.filter { it.key > 0 && it.value.size > 1 }
        var done = 0
        for ((_, sameSize) in bySize) {
            val hashed = sameSize.groupBy { item ->
                item.exactHash = computeExactHash(cr, item)
                item.exactHash
            }
            for ((hash, dupes) in hashed) {
                if (hash != null && dupes.size > 1) {
                    exactGroups += MediaGroup("exact-$hash", dupes, bestOf(dupes), similar = false)
                    dupes.forEach { inExact += it.id }
                }
            }
            done += sameSize.size
            onProgress(done, library.size, "Finding exact duplicates")
        }

        // ---- perceptual hashes + sharpness for images not already exact-grouped
        val remaining = images.filter { it.id !in inExact }
        var i = 0
        for (item in remaining) {
            item.pHash = computePHash(cr, item)
            item.sharpness = computeSharpness(cr, item)
            i++
            if (i % 25 == 0) onProgress(i, remaining.size, "Analysing similar photos")
        }
        // also sharpness for exact-group images (blurry list + best pick already used size/MP)
        for (item in images) if (item.sharpness < 0) item.sharpness = computeSharpness(cr, item)

        // ---- similar grouping (union-find over pHash, bucketed by top bits)
        val withHash = remaining.filter { it.pHash != null }
        val parent = IntArray(withHash.size) { it }
        fun find(a: Int): Int { var r = a; while (parent[r] != r) r = parent[r]; return r }
        fun union(a: Int, b: Int) { val ra = find(a); val rb = find(b); if (ra != rb) parent[ra] = rb }
        val buckets = withHash.indices.groupBy { (withHash[it].pHash!! ushr 48).toInt() }
        for ((_, idxs) in buckets) {
            for (a in idxs.indices) {
                for (b in a + 1 until idxs.size) {
                    val d = java.lang.Long.bitCount(withHash[idxs[a]].pHash!! xor withHash[idxs[b]].pHash!!)
                    if (d <= similarityThreshold) union(idxs[a], idxs[b])
                }
            }
        }
        val similarGroups = withHash.indices.groupBy { find(it) }
            .values.filter { it.size > 1 }
            .map { idxs ->
                val groupItems = idxs.map { withHash[it] }
                MediaGroup("similar-${groupItems.first().id}", groupItems, bestOf(groupItems), similar = true)
            }
            .sortedByDescending { it.reclaimable }

        val inSimilar = similarGroups.flatMap { g -> g.items.map { it.id } }.toSet()
        val blurry = images.filter { it.id !in inSimilar && it.sharpness in 0.0..60.0 }
            .sortedBy { it.sharpness }
        val screenshots = images.filter { it.isScreenshot && it.id !in inExact && it.id !in inSimilar }
            .sortedByDescending { it.size }
        val largeVideos = videos.filter { it.size >= LARGE_VIDEO_BYTES && it.id !in inExact }
            .sortedByDescending { it.size }

        onProgress(library.size, library.size, "Done")
        ScanResult(
            exactGroups = exactGroups.sortedByDescending { it.reclaimable },
            similarGroups = similarGroups,
            blurry = blurry,
            screenshots = screenshots,
            largeVideos = largeVideos,
            totalScanned = library.size
        )
    }
}
