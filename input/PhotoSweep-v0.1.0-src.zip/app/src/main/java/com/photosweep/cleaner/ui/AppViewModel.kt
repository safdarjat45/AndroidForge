package com.photosweep.cleaner.ui

import android.app.Application
import android.app.PendingIntent
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.photosweep.cleaner.data.MediaGroup
import com.photosweep.cleaner.data.MediaItem
import com.photosweep.cleaner.data.Scanner
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("photosweep", 0)

    var similarityThreshold by mutableStateOf(prefs.getInt("similarity", 8))
        private set

    fun setSimilarity(v: Int) {
        similarityThreshold = v
        prefs.edit().putInt("similarity", v).apply()
    }

    // ---- scan state
    var scanning by mutableStateOf(false)
        private set
    var scanDone by mutableStateOf(false)
        private set
    var progressDone by mutableStateOf(0)
        private set
    var progressTotal by mutableStateOf(1)
        private set
    var progressStage by mutableStateOf("")
        private set
    var scanError by mutableStateOf<String?>(null)
        private set

    var result by mutableStateOf<Scanner.ScanResult?>(null)
        private set

    /** ids the user has marked for cleanup (non-best copies start pre-selected in groups). */
    val selected = mutableStateMapOf<Long, MediaItem>()

    fun toggleSelect(item: MediaItem) {
        if (selected.containsKey(item.id)) selected.remove(item.id) else selected[item.id] = item
    }

    fun selectGroupExtras(group: MediaGroup) {
        group.items.filter { it.id != group.bestId }.forEach { selected[it.id] = it }
    }

    fun clearSelection() = selected.clear()

    val selectedBytes: Long get() = selected.values.sumOf { it.size }

    fun startScan() {
        if (scanning) return
        scanning = true
        scanError = null
        viewModelScope.launch {
            try {
                val r = Scanner.scan(getApplication<Application>().contentResolver, similarityThreshold) { d, t, s ->
                    progressDone = d; progressTotal = t; progressStage = s
                }
                result = r
                scanDone = true
                // pre-select the extra copies in every group — the user just reviews
                (r.exactGroups + r.similarGroups).forEach { selectGroupExtras(it) }
            } catch (e: Exception) {
                scanError = "Scan failed: ${e.message ?: "unknown error"}"
            } finally {
                scanning = false
            }
        }
    }

    // ---- trash
    val trashItems = mutableStateListOf<MediaItem>()
    var trashLoaded by mutableStateOf(false)
        private set

    fun loadTrash() {
        viewModelScope.launch {
            try {
                val items = Scanner.loadLibrary(getApplication<Application>().contentResolver, trashed = true)
                trashItems.clear()
                trashItems.addAll(items)
            } catch (e: Exception) {
                // trash listing is best-effort
            } finally {
                trashLoaded = true
            }
        }
    }

    // ---- system consent plumbing (trash / restore / delete need the system dialog)
    var pendingIntent by mutableStateOf<PendingIntent?>(null)
        private set
    private var pendingOnResult: ((Boolean) -> Unit)? = null

    private fun requestConsent(intent: PendingIntent, onResult: (Boolean) -> Unit) {
        pendingOnResult = onResult
        pendingIntent = intent
    }

    fun onConsentResult(ok: Boolean) {
        pendingIntent = null
        val cb = pendingOnResult
        pendingOnResult = null
        cb?.invoke(ok)
    }

    fun trashSelected(onDone: () -> Unit) {
        val items = selected.values.toList()
        if (items.isEmpty()) { onDone(); return }
        val cr = getApplication<Application>().contentResolver
        val uris = items.map { it.uri }
        val pi = MediaStore.createTrashRequest(cr, uris, true)
        requestConsent(pi) { ok ->
            if (ok) {
                val ids = items.map { it.id }.toSet()
                selected.clear()
                result = result?.let { r ->
                    fun prune(groups: List<MediaGroup>) = groups.mapNotNull { g ->
                        val left = g.items.filter { it.id !in ids }
                        if (left.size < 2) null else g.copy(items = left)
                    }
                    r.copy(
                        exactGroups = prune(r.exactGroups),
                        similarGroups = prune(r.similarGroups),
                        blurry = r.blurry.filter { it.id !in ids },
                        screenshots = r.screenshots.filter { it.id !in ids },
                        largeVideos = r.largeVideos.filter { it.id !in ids }
                    )
                }
                loadTrash()
            }
            onDone()
        }
    }

    fun restoreFromTrash(items: List<MediaItem>) {
        if (items.isEmpty()) return
        val cr = getApplication<Application>().contentResolver
        val pi = MediaStore.createTrashRequest(cr, items.map { it.uri }, false)
        requestConsent(pi) { ok -> if (ok) loadTrash() }
    }

    fun deleteForever(items: List<MediaItem>) {
        if (items.isEmpty()) return
        val cr = getApplication<Application>().contentResolver
        val pi = MediaStore.createDeleteRequest(cr, items.map { it.uri })
        requestConsent(pi) { ok -> if (ok) loadTrash() }
    }
}
