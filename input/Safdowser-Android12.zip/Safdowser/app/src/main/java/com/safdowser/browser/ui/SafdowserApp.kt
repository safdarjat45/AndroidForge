package com.safdowser.browser.ui

import android.content.Intent
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.safdowser.browser.browser.SafdowserWebViewController
import com.safdowser.browser.data.ProfileRepository
import com.safdowser.browser.model.GeoPresets
import com.safdowser.browser.vpn.SafdowserVpnService
import com.safdowser.browser.vpn.VpnServer
import com.safdowser.browser.vpn.VpnServerRepository
import com.safdowser.browser.vpn.WebViewProxyManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafdowserApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val profileRepo = remember { ProfileRepository(context) }
    val vpnRepo = remember { VpnServerRepository() }

    var profiles by remember { mutableStateOf(profileRepo.loadProfiles()) }
    var activeProfile by remember { mutableStateOf(profiles.first()) }
    var isIncognito by remember { mutableStateOf(false) }

    var currentUrl by remember { mutableStateOf("https://browserleaks.com/javascript") }
    var addressInput by remember { mutableStateOf(currentUrl) }
    var loadProgress by remember { mutableIntStateOf(100) }

    val vpnState by SafdowserVpnService.state.collectAsState()
    var vpnServers by remember { mutableStateOf<List<VpnServer>>(emptyList()) }
    var customHost by remember { mutableStateOf("") }
    var customPort by remember { mutableStateOf("1080") }
    var customProto by remember { mutableStateOf("SOCKS5") }

    var showProfileSheet by remember { mutableStateOf(false) }
    var showGeoSheet by remember { mutableStateOf(false) }
    var showVpnSheet by remember { mutableStateOf(false) }

    val controller = remember { SafdowserWebViewController(context) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    fun connectProxy(host: String, port: Int, proto: String, country: String, code: String) {
        WebViewProxyManager.applyProxy(host, port, proto) {
            val intent = Intent(context, SafdowserVpnService::class.java).apply {
                action = SafdowserVpnService.ACTION_CONNECT
                putExtra(SafdowserVpnService.EXTRA_COUNTRY, country)
                putExtra(SafdowserVpnService.EXTRA_CODE, code)
                putExtra(SafdowserVpnService.EXTRA_CITY, "")
                putExtra(SafdowserVpnService.EXTRA_IP, host)
                putExtra(SafdowserVpnService.EXTRA_PORT, port)
                putExtra(SafdowserVpnService.EXTRA_PROTO, proto)
            }
            context.startForegroundService(intent)
        }
    }

    fun disconnectProxy() {
        WebViewProxyManager.clearProxy()
        context.startService(Intent(context, SafdowserVpnService::class.java).apply {
            action = SafdowserVpnService.ACTION_DISCONNECT
        })
    }

    fun navigateTo(raw: String) {
        val trimmed = raw.trim()
        val target = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://duckduckgo.com/?q=${trimmed.replace(" ", "+")}"
        }
        currentUrl = target
        addressInput = target
        webViewRef?.loadUrl(target)
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isIncognito) Color(0xFF1F122B) else MaterialTheme.colorScheme.surface)
                    .statusBarsPadding()
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = addressInput,
                        onValueChange = { addressInput = it },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Search or enter URL") },
                        leadingIcon = {
                            Icon(
                                if (isIncognito) Icons.Default.VisibilityOff else Icons.Default.Shield,
                                contentDescription = null,
                                tint = if (isIncognito) Color(0xFFC084FC) else MaterialTheme.colorScheme.primary
                            )
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { navigateTo(addressInput) }),
                        shape = RoundedCornerShape(24.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = {
                        isIncognito = !isIncognito
                        if (isIncognito) {
                            activeProfile = profileRepo.createIncognitoProfile(activeProfile)
                        } else {
                            controller.wipeSessionData()
                            activeProfile = profiles.first()
                        }
                    }) {
                        Icon(
                            Icons.Default.VisibilityOff,
                            contentDescription = "Incognito",
                            tint = if (isIncognito) Color(0xFFC084FC) else Color.Gray
                        )
                    }
                }

                if (loadProgress in 1..99) {
                    LinearProgressIndicator(
                        progress = { loadProgress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .height(2.dp)
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatusChip(
                        label = activeProfile.name,
                        icon = Icons.Default.Person,
                        active = true,
                        onClick = { showProfileSheet = true },
                        modifier = Modifier.weight(1f)
                    )
                    StatusChip(
                        label = activeProfile.timezoneId.substringAfter("/"),
                        icon = Icons.Default.LocationOn,
                        active = true,
                        onClick = { showGeoSheet = true },
                        modifier = Modifier.weight(1f)
                    )
                    StatusChip(
                        label = if (vpnState.isConnected) vpnState.activeServer?.countryCode ?: "PROXY" else "Direct IP",
                        icon = Icons.Default.VpnLock,
                        active = vpnState.isConnected,
                        onClick = { showVpnSheet = true },
                        modifier = Modifier.weight(0.9f)
                    )
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = false,
                    onClick = { webViewRef?.goBack() },
                    icon = { Icon(Icons.Default.ArrowBack, contentDescription = "Back") },
                    label = { Text("Back") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { webViewRef?.reload() },
                    icon = { Icon(Icons.Default.Refresh, contentDescription = "Reload") },
                    label = { Text("Reload") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { navigateTo("https://browserleaks.com/javascript") },
                    icon = { Icon(Icons.Default.Fingerprint, contentDescription = "Leak Test") },
                    label = { Text("Leak Test") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { controller.wipeSessionData(); webViewRef?.reload() },
                    icon = { Icon(Icons.Default.DeleteSweep, contentDescription = "Wipe") },
                    label = { Text("Wipe") }
                )
            }
        }
    ) { padding ->
        key(activeProfile.id, activeProfile.timezoneId, activeProfile.latitude, activeProfile.longitude) {
            AndroidView(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                factory = {
                    controller.createAndConfigure(
                        profile = activeProfile,
                        onUrlChanged = { url -> addressInput = url; currentUrl = url },
                        onProgressChanged = { p -> loadProgress = p },
                        onTitleChanged = {}
                    ).also { wv ->
                        webViewRef = wv
                        wv.loadUrl(currentUrl)
                    }
                },
                onRelease = { wv -> wv.destroy() }
            )
        }
    }

    if (showProfileSheet) {
        ModalBottomSheet(onDismissRequest = { showProfileSheet = false }) {
            Column(Modifier.padding(16.dp)) {
                Text("Anti-Detect Profiles", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                profiles.forEach { p ->
                    ListItem(
                        headlineContent = { Text(p.name) },
                        supportingContent = { Text("${p.timezoneId} · GPS ${p.latitude}, ${p.longitude}") },
                        leadingContent = {
                            RadioButton(selected = activeProfile.id == p.id, onClick = {
                                controller.wipeSessionData()
                                activeProfile = p
                                isIncognito = false
                                showProfileSheet = false
                            })
                        },
                        modifier = Modifier.clickable {
                            controller.wipeSessionData()
                            activeProfile = p
                            isIncognito = false
                            showProfileSheet = false
                        }
                    )
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showGeoSheet) {
        ModalBottomSheet(onDismissRequest = { showGeoSheet = false }) {
            Column(Modifier.padding(16.dp)) {
                Text("Fake GPS & Timezone", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    "Websites only see the timezone & coordinates below—never your device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    items(GeoPresets.all) { preset ->
                        ListItem(
                            headlineContent = { Text(preset.label) },
                            supportingContent = { Text("${preset.timezoneId} · ${preset.latitude}, ${preset.longitude}") },
                            modifier = Modifier.clickable {
                                val updated = activeProfile.copy(
                                    timezoneId = preset.timezoneId,
                                    timezoneOffsetMinutes = preset.timezoneOffsetMinutes,
                                    latitude = preset.latitude,
                                    longitude = preset.longitude,
                                    language = preset.language,
                                    languages = listOf(preset.language, "en")
                                )
                                activeProfile = updated
                                if (!updated.isIncognito) {
                                    profiles = profiles.map { if (it.id == updated.id) updated else it }
                                    profileRepo.saveProfiles(profiles)
                                }
                                showGeoSheet = false
                            }
                        )
                    }
                }
            }
        }
    }

    if (showVpnSheet) {
        ModalBottomSheet(onDismissRequest = { showVpnSheet = false }) {
            Column(Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("IP / Proxy & VPN", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Row {
                        TextButton(onClick = {
                            scope.launch { vpnServers = vpnRepo.fetchLiveFreeVpnGateServers() }
                        }) { Text("Fetch VPN Gate") }
                        if (vpnState.isConnected) {
                            TextButton(onClick = { disconnectProxy() }) { Text("Disconnect", color = Color(0xFFF87171)) }
                        }
                    }
                }
                Text(vpnState.statusText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(8.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = customHost,
                        onValueChange = { customHost = it },
                        label = { Text("Proxy IP / Host") },
                        singleLine = true,
                        modifier = Modifier.weight(1.4f)
                    )
                    OutlinedTextField(
                        value = customPort,
                        onValueChange = { customPort = it },
                        label = { Text("Port") },
                        singleLine = true,
                        modifier = Modifier.weight(0.7f)
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = customProto == "SOCKS5", onClick = { customProto = "SOCKS5" }, label = { Text("SOCKS5") })
                        FilterChip(selected = customProto == "HTTP", onClick = { customProto = "HTTP" }, label = { Text("HTTP") })
                    }
                    Button(
                        enabled = customHost.isNotBlank() && (customPort.toIntOrNull() ?: 0) > 0,
                        onClick = {
                            connectProxy(customHost.trim(), customPort.toInt(), customProto, "Custom", "PX")
                            showVpnSheet = false
                        }
                    ) { Text("Apply Proxy") }
                }

                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 260.dp)) {
                    items(vpnServers) { srv ->
                        ListItem(
                            headlineContent = { Text("${srv.countryName} (${srv.city})") },
                            supportingContent = { Text("${srv.ipAddress} · ${srv.protocol} · ${srv.pingMs}ms") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) MaterialTheme.colorScheme.surfaceVariant else Color(0xFF1F2937))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = if (active) MaterialTheme.colorScheme.primary else Color.Gray
        )
        Spacer(Modifier.width(4.dp))
        Text(
            label,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
