package com.safdowser.browser.vpn

data class VpnServer(
    val id: String,
    val countryName: String,
    val countryCode: String,
    val city: String,
    val ipAddress: String,
    val port: Int,
    val protocol: String, // "SOCKS5", "HTTP", "OPENVPN"
    val pingMs: Int = 45,
    val isFreeCommunity: Boolean = true
)
