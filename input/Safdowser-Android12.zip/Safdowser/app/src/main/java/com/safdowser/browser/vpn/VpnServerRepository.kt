package com.safdowser.browser.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class VpnServerRepository {

    /**
     * Fetches live free public volunteer relay nodes from the academic VPN Gate directory.
     */
    suspend fun fetchLiveFreeVpnGateServers(): List<VpnServer> = withContext(Dispatchers.IO) {
        val results = mutableListOf<VpnServer>()
        runCatching {
            val conn = (URL("https://www.vpngate.net/api/iphone/").openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
            }
            conn.inputStream.bufferedReader().useLines { lines ->
                lines.drop(2).take(50).forEach { line ->
                    if (line.startsWith("*")) return@forEach
                    val cols = line.split(",")
                    if (cols.size >= 7) {
                        val ip = cols[1].trim()
                        val ping = cols[3].trim().toIntOrNull() ?: 99
                        val country = cols[5].trim()
                        val code = cols[6].trim()
                        if (ip.isNotEmpty() && code.length == 2) {
                            results.add(
                                VpnServer(
                                    id = "vpngate-$code-$ip",
                                    countryName = country,
                                    countryCode = code,
                                    city = "VPN Gate Relay",
                                    ipAddress = ip,
                                    port = 443,
                                    protocol = "OPENVPN",
                                    pingMs = ping,
                                    isFreeCommunity = true
                                )
                            )
                        }
                    }
                }
            }
        }
        results
    }
}
