package com.safdowser.gecko.ui

import android.app.Activity
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.safdowser.gecko.browser.AddonsManager
import com.safdowser.gecko.browser.BrowserTab
import com.safdowser.gecko.browser.BrowserTabManager
import com.safdowser.gecko.browser.GeckoEngine
import org.mozilla.geckoview.GeckoView

private enum class Screen { Browser, Tabs, Addons, Identity, Vpn, Settings }

/**
 * Harrier's main UI. Layout (all English, brand theme):
 * - a pill address bar with back / forward / reload and a menu button,
 * - the web view,
 * - a bottom bar: Tabs (with count), New Tab, Add-ons, VPN, Identity,
 * - full-screen Tabs overview, Add-ons, Identity and VPN screens,
 * - a menu sheet and an About dialog.
 *
 * Startup is defensive: if the engine cannot be created, the app shows
 * an error screen with a restart button instead of dying silently
 * (v0.2.0 field report: "the app does not open").
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeckoApp() {
    val context = LocalContext.current

    val runtimeResult = remember { runCatching { GeckoEngine.runtime(context) } }
    val runtime = runtimeResult.getOrNull()
    if (runtime == null) {
        EngineErrorScreen(
            message = runtimeResult.exceptionOrNull()?.message
                ?: "Unknown engine error",
            onRestart = { (context as? Activity)?.recreate() }
        )
        return
    }

    val tabManager = remember { BrowserTabManager(runtime) }
    val addons = remember {
        AddonsManager(runtime) { url -> tabManager.newTab(url).session }
    }

    // Give every tab session to the add-ons manager: extension toolbar
    // actions are per-session in GeckoView, and without a session-level
    // delegate an installed add-on (e.g. Browsec) never appears on screen.
    LaunchedEffect(tabManager.tabs.map { it.id }) {
        tabManager.tabs.forEach { addons.registerSession(it.session) }
    }

    var screen by remember { mutableStateOf(Screen.Browser) }
    var addressText by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    var aboutOpen by remember { mutableStateOf(false) }

    // Anything the add-ons manager opens (popup, options, store, wake-up
    // page) must come to the front — never open silently behind a screen.
    LaunchedEffect(addons) {
        addons.onShowBrowser = { screen = Screen.Browser }
    }

    val activeTab = tabManager.activeTab

    LaunchedEffect(Unit) {
        if (tabManager.tabs.isEmpty()) tabManager.newTab()
    }

    // Keep the address bar in step with the active tab's current URL.
    LaunchedEffect(activeTab?.id, activeTab?.url) {
        val url = activeTab?.url.orEmpty()
        addressText =
            if (url.isNotEmpty() && !url.startsWith("data:") && !url.startsWith("about:")) url
            else ""
    }

    BackHandler {
        when {
            menuOpen -> menuOpen = false
            screen != Screen.Browser -> screen = Screen.Browser
            activeTab?.canGoBack == true -> activeTab?.goBack()
            else -> (context as? Activity)?.finish()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        when (screen) {
            Screen.Browser -> {
                TabStrip(
                    tabManager = tabManager,
                    onSelect = { tabManager.selectTab(it) },
                    onClose = { tab -> tabManager.closeTab(tab) },
                    onNewTab = { tabManager.newTab() }
                )

                AddressBar(
                    text = addressText,
                    onTextChange = { addressText = it },
                    onGo = { activeTab?.load(addressText) },
                    canGoBack = activeTab?.canGoBack == true,
                    canGoForward = activeTab?.canGoForward == true,
                    onBack = { activeTab?.goBack() },
                    onForward = { activeTab?.goForward() },
                    onReload = { activeTab?.reload() },
                    onMenu = { menuOpen = true },
                    onSettings = { screen = Screen.Settings }
                )

                // Add-on status line, visible HERE on the browser screen
                // (in v0.2.2 it only existed on the Add-ons screen, so
                // messages about opening an add-on were never seen).
                if (addons.status != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(start = 12.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            addons.status!!,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { addons.clearStatus() }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Filled.Close, contentDescription = "Dismiss", modifier = Modifier.size(14.dp))
                        }
                    }
                }

                if (activeTab?.loading == true) {
                    LinearProgressIndicator(
                        progress = { (activeTab?.progress ?: 0) / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Installed-extension buttons. Sourced from the installed
                // list itself (not only from reported actions), so an
                // installed add-on is ALWAYS visible and tappable here —
                // tapping opens its panel (e.g. Browsec's connect screen).
                if (addons.installed.isNotEmpty()) {
                    LazyRow(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(addons.installed, key = { it.id }) { ext ->
                            val action = addons.browserActions[ext.id]
                            val label = buildString {
                                append(action?.title ?: ext.metaData.name ?: ext.id)
                                action?.badgeText?.let { append(" ($it)") }
                            }
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.clickable { addons.openExtension(ext) }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    val iconBmp = addons.actionIcons[ext.id]
                                    if (iconBmp != null) {
                                        Image(
                                            bitmap = iconBmp.asImageBitmap(),
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }
                                    Text(
                                        label,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                }
                            }
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    val tab = activeTab
                    if (tab != null) {
                        key(tab.id) {
                            AndroidView(
                                factory = { ctx ->
                                    GeckoView(ctx).apply { setSession(tab.session) }
                                },
                                onRelease = { view -> view.releaseSession() },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) { Text("Opening tab…") }
                    }
                }

                BottomBar(
                    tabCount = tabManager.tabs.size,
                    onTabs = { screen = Screen.Tabs },
                    onNewTab = { tabManager.newTab() },
                    onAddons = { screen = Screen.Addons },
                    onVpn = { screen = Screen.Vpn },
                    onIdentity = { screen = Screen.Identity }
                )
            }

            Screen.Tabs -> TabsScreen(
                tabManager = tabManager,
                onBack = { screen = Screen.Browser },
                onSelect = { id ->
                    tabManager.selectTab(id)
                    screen = Screen.Browser
                }
            )

            Screen.Addons -> AddonsScreen(
                addons = addons,
                onBack = { screen = Screen.Browser },
                onStoreOpened = { screen = Screen.Browser }
            )

            Screen.Identity -> IdentityScreen(
                tab = activeTab,
                onBack = { screen = Screen.Browser }
            )

            Screen.Vpn -> VpnScreen(onBack = { screen = Screen.Browser })

            Screen.Settings -> SettingsScreen(
                onBack = { screen = Screen.Browser },
                onClearData = {
                    runCatching {
                        runtime.storageController.clearData(
                            org.mozilla.geckoview.StorageController.ClearFlags.ALL
                        )
                    }
                }
            )
        }
    }

    if (menuOpen) {
        val sheetState = rememberModalBottomSheetState()
        ModalBottomSheet(
            onDismissRequest = { menuOpen = false },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.navigationBarsPadding()) {
                MenuItem("New tab", Icons.Filled.Add) {
                    tabManager.newTab(); menuOpen = false; screen = Screen.Browser
                }
                MenuItem("Tabs", Icons.Filled.Layers) {
                    menuOpen = false; screen = Screen.Tabs
                }
                MenuItem("Add-ons", Icons.Filled.Extension) {
                    menuOpen = false; screen = Screen.Addons
                }
                MenuItem("VPN & Proxy", Icons.Filled.VpnKey) {
                    menuOpen = false; screen = Screen.Vpn
                }
                MenuItem("Identity — what websites see", Icons.Filled.Shield) {
                    menuOpen = false; screen = Screen.Identity
                }
                MenuItem("Settings", Icons.Filled.Settings) {
                    menuOpen = false; screen = Screen.Settings
                }
                MenuItem("About Harrier", Icons.Filled.Info) {
                    menuOpen = false; aboutOpen = true
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    if (aboutOpen) {
        AlertDialog(
            onDismissRequest = { aboutOpen = false },
            title = { Text("Harrier") },
            text = {
                Text(
                    "Version 0.2.3 · Firefox engine (GeckoView)\n\n" +
                        "A private browser. It holds no location, camera, microphone " +
                        "or storage permissions, blocks trackers on Strict, keeps " +
                        "WebRTC off, and never sends your browsing anywhere."
                )
            },
            confirmButton = {
                TextButton(onClick = { aboutOpen = false }) { Text("OK") }
            }
        )
    }

    // ---- Extension install permission dialog ----
    val prompt = addons.pendingPrompt
    if (prompt != null) {
        AlertDialog(
            onDismissRequest = { addons.respondToPrompt(false) },
            title = { Text("Install this add-on?") },
            text = {
                Column {
                    Text(
                        text = prompt.extension.metaData.name ?: prompt.extension.id,
                        fontWeight = FontWeight.Bold
                    )
                    Text(prompt.extension.metaData.description ?: "")
                    if (prompt.permissions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Permissions:", fontWeight = FontWeight.Bold)
                        prompt.permissions.forEach { Text("• $it") }
                    }
                    if (prompt.origins.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Sites:", fontWeight = FontWeight.Bold)
                        prompt.origins.forEach { Text("• $it") }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "This add-on is Mozilla-signed (from AMO). Add-ons run their " +
                            "own code — their own leak points (for example WebRTC or " +
                            "direct connections) are outside Harrier's control.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                Button(onClick = { addons.respondToPrompt(true) }) { Text("Install") }
            },
            dismissButton = {
                TextButton(onClick = { addons.respondToPrompt(false) }) { Text("Cancel") }
            }
        )
    }

    // ---- Extension popup (e.g. Browsec connect panel) ----
    val popup = addons.popupRequest
    if (popup != null) {
        Dialog(onDismissRequest = { addons.dismissPopup() }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(480.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = popup.extension.metaData.name ?: popup.extension.id,
                        modifier = Modifier.weight(1f),
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { addons.dismissPopup() }) {
                        Icon(Icons.Filled.Close, contentDescription = "Close popup")
                    }
                }
                // Key on the session object itself: a second popup from the
                // same extension gets a fresh session and must re-run factory.
                key(popup.session) {
                    AndroidView(
                        factory = { ctx ->
                            GeckoView(ctx).apply { setSession(popup.session) }
                        },
                        onRelease = { view -> view.releaseSession() },
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    )
                }
            }
        }
    }
}

/** Shown when the browsing engine cannot start — never a silent death. */
@Composable
private fun EngineErrorScreen(message: String, onRestart: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Filled.Shield,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(56.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "Harrier could not start",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "The browsing engine failed to start on this device. " +
                "Restarting the app usually fixes it.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(onClick = onRestart) { Text("Restart Harrier") }
    }
}

@Composable
private fun AddressBar(
    text: String,
    onTextChange: (String) -> Unit,
    onGo: () -> Unit,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReload: () -> Unit,
    onMenu: () -> Unit,
    onSettings: () -> Unit
) {
    val keyboard = LocalSoftwareKeyboardController.current
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack, enabled = canGoBack, modifier = Modifier.size(38.dp)) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", modifier = Modifier.size(20.dp))
        }
        IconButton(onClick = onForward, enabled = canGoForward, modifier = Modifier.size(38.dp)) {
            Icon(Icons.Filled.ArrowForward, contentDescription = "Forward", modifier = Modifier.size(20.dp))
        }
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.weight(1f).height(40.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 14.dp)
            ) {
                Icon(
                    Icons.Filled.Shield,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                BasicTextField(
                    value = text,
                    onValueChange = onTextChange,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = {
                        keyboard?.hide()
                        onGo()
                    }),
                    decorationBox = { inner ->
                        if (text.isEmpty()) {
                            Text(
                                "Search or enter address",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        inner()
                    },
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onReload, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Filled.Refresh,
                        contentDescription = "Reload",
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
        // Harrier's OWN settings button, always visible — the browser's
        // settings live here, not inside any search engine's page menu.
        IconButton(onClick = onSettings, modifier = Modifier.size(38.dp)) {
            Icon(Icons.Filled.Settings, contentDescription = "Settings", modifier = Modifier.size(20.dp))
        }
        IconButton(onClick = onMenu, modifier = Modifier.size(38.dp)) {
            Icon(Icons.Filled.MoreVert, contentDescription = "Menu", modifier = Modifier.size(20.dp))
        }
    }
}

/**
 * Tab strip at the very top (v0.2.2 — the user asked for visible tabs to
 * switch with one tap, like other browsers, instead of only the overview
 * screen). Active tab is highlighted; each chip carries its own close
 * button; "+" opens a new tab.
 */
@Composable
private fun TabStrip(
    tabManager: BrowserTabManager,
    onSelect: (Long) -> Unit,
    onClose: (BrowserTab) -> Unit,
    onNewTab: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LazyRow(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(tabManager.tabs, key = { it.id }) { tab ->
                val active = tab.id == tabManager.activeTab?.id
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (active) MaterialTheme.colorScheme.surfaceVariant
                    else MaterialTheme.colorScheme.surface,
                    modifier = Modifier.clickable { onSelect(tab.id) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 10.dp, end = 2.dp, top = 3.dp, bottom = 3.dp)
                    ) {
                        Text(
                            tab.title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (active) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.widthIn(max = 110.dp)
                        )
                        IconButton(onClick = { onClose(tab) }, modifier = Modifier.size(22.dp)) {
                            Icon(
                                Icons.Filled.Close,
                                contentDescription = "Close tab",
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
            }
        }
        IconButton(onClick = onNewTab, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Filled.Add, contentDescription = "New tab", modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun BottomBar(
    tabCount: Int,
    onTabs: () -> Unit,
    onNewTab: () -> Unit,
    onAddons: () -> Unit,
    onVpn: () -> Unit,
    onIdentity: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            BottomBarItem(
                label = "Tabs",
                onClick = onTabs
            ) {
                BadgedBox(badge = {
                    if (tabCount > 0) Badge { Text(tabCount.toString()) }
                }) {
                    Icon(Icons.Filled.Layers, contentDescription = "Tabs")
                }
            }
            BottomBarItem(label = "New Tab", onClick = onNewTab) {
                Icon(Icons.Filled.Add, contentDescription = "New tab")
            }
            BottomBarItem(label = "Add-ons", onClick = onAddons) {
                Icon(Icons.Filled.Extension, contentDescription = "Add-ons")
            }
            BottomBarItem(label = "VPN", onClick = onVpn) {
                Icon(Icons.Filled.VpnKey, contentDescription = "VPN")
            }
            BottomBarItem(label = "Identity", onClick = onIdentity) {
                Icon(Icons.Filled.Shield, contentDescription = "Identity")
            }
        }
    }
}

@Composable
private fun BottomBarItem(
    label: String,
    onClick: () -> Unit,
    icon: @Composable () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        icon()
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun MenuItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(16.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun TabsScreen(
    tabManager: BrowserTabManager,
    onBack: () -> Unit,
    onSelect: (Long) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                "Tabs",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { tabManager.newTab(); onBack() }) {
                Icon(Icons.Filled.Add, contentDescription = "New tab")
            }
        }
        if (tabManager.tabs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No tabs open")
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(tabManager.tabs, key = { it.id }) { tab ->
                    TabCard(
                        tab = tab,
                        active = tab.id == tabManager.activeTab?.id,
                        onClick = { onSelect(tab.id) },
                        onClose = { tabManager.closeTab(tab) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TabCard(
    tab: BrowserTab,
    active: Boolean,
    onClick: () -> Unit,
    onClose: () -> Unit
) {
    val host = remember(tab.url) {
        if (tab.url.isBlank()) "Start page"
        else runCatching { Uri.parse(tab.url).host }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: tab.url
    }
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = if (active) MaterialTheme.colorScheme.surfaceVariant
            else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().height(110.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    tab.title,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = "Close tab", modifier = Modifier.size(16.dp))
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                host,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (active) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "Active tab",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
