package com.safdowser.gecko.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.safdowser.gecko.browser.AddonsManager
import com.safdowser.gecko.browser.PRESEEDED_ADDONS

/**
 * Add-ons screen: installed add-ons FIRST (v0.2.1 buried them at the
 * bottom, so an installed extension looked invisible), each with an Open
 * button that raises its panel (e.g. Browsec's connect screen), an
 * enable/disable switch, Options and Uninstall. Then one-tap installs,
 * then the store.
 *
 * AMO only — Chrome Web Store extensions cannot run on this engine, and
 * the screen never suggests otherwise. Urban VPN / Green VPN are called
 * out as unavailable here, not hidden.
 */
@Composable
fun AddonsScreen(
    addons: AddonsManager,
    onBack: () -> Unit,
    /** Called after the store/search tab is opened, so the UI can switch to it. */
    onStoreOpened: () -> Unit = {}
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Add-ons", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            if (addons.status != null) {
                item {
                    Text(
                        text = addons.status!!,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
            }

            item {
                Text(
                    "Installed (${addons.installed.size})",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
            }

            if (addons.installed.isEmpty()) {
                item {
                    Text(
                        "No add-ons installed yet. Install Browsec or uBlock Origin below.",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
            }

            items(addons.installed, key = { it.id }) { ext ->
                val meta = ext.metaData
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(meta.name ?: ext.id, fontWeight = FontWeight.Bold)
                                Text("v${meta.version}", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(
                                checked = meta.enabled,
                                onCheckedChange = { addons.setEnabled(ext, it) }
                            )
                        }
                        meta.description?.let {
                            Text(it, style = MaterialTheme.typography.bodyMedium)
                        }
                        Row(modifier = Modifier.padding(top = 8.dp)) {
                            Button(
                                onClick = { addons.openExtension(ext) },
                                enabled = meta.enabled
                            ) {
                                Text("Open")
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            if (meta.optionsPageUrl != null) {
                                OutlinedButton(onClick = { addons.openOptionsPage(ext) }) {
                                    Text("Options")
                                }
                            }
                            OutlinedButton(onClick = { addons.uninstall(ext) }) {
                                Text("Uninstall")
                            }
                        }
                        Text(
                            "Tip: an enabled add-on also gets a button above the " +
                                "address bar — tap it to open its panel (for Browsec, " +
                                "that is where you connect and disconnect).",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }

            item {
                Text(
                    "Recommended",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                )
            }

            items(PRESEEDED_ADDONS, key = { it.slug }) { addon ->
                val alreadyInstalled = addons.installed.any {
                    it.metaData.name?.contains(addon.name, ignoreCase = true) == true
                }
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(addon.name, fontWeight = FontWeight.Bold)
                        Text(addon.blurb, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { addons.installFromAmo(addon.slug) },
                            enabled = !addons.installing && !alreadyInstalled
                        ) {
                            Text(
                                when {
                                    alreadyInstalled -> "Installed"
                                    addons.installing -> "Installing…"
                                    else -> "Install"
                                }
                            )
                        }
                    }
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Mozilla Add-ons Store", fontWeight = FontWeight.Bold)
                        Text(
                            "To find and install any add-on yourself, open the official store. " +
                                "Type a name and tap Search — the store page opens in a new tab, " +
                                "and tapping \"Add to Firefox\" there brings the permission " +
                                "dialog up here in this app. Only add-ons made for Firefox " +
                                "for Android will install.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        var storeQuery by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = storeQuery,
                            onValueChange = { storeQuery = it },
                            label = { Text("Add-on name, e.g. vpn, blocker, dark reader") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row {
                            Button(onClick = {
                                addons.searchAddonStore(storeQuery)
                                onStoreOpened()
                            }) {
                                Text("Search")
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = {
                                addons.openAddonStore()
                                onStoreOpened()
                            }) {
                                Text("Open full store")
                            }
                        }
                    }
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("What about Urban VPN and Green VPN?", fontWeight = FontWeight.Bold)
                        Text(
                            "Neither can be installed on Firefox for Android — in any browser. " +
                                "Urban VPN is not listed on AMO for Android, and Green VPN has no " +
                                "Firefox add-on at all (Chrome only). Browsec above works instead.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            item {
                Text(
                    "Note: an add-on runs its own code — its own leak points (WebRTC, " +
                        "direct connections) are outside Harrier's control. The " +
                        "\"no detection\" promise covers only the built-in behaviour.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        }
    }
}
