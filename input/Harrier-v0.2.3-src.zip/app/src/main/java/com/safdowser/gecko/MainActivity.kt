package com.safdowser.gecko

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.safdowser.gecko.browser.AppSettings
import com.safdowser.gecko.ui.GeckoApp
import com.safdowser.gecko.ui.theme.GeckoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppSettings.load(this)
        // Screenshot protection (Settings toggle, default ON): FLAG_SECURE
        // keeps browsing content out of screenshots, screen recordings and
        // the Android Recents thumbnail. The user asked for an off switch
        // (v0.2.1 field report: he could not take screenshots at all), so
        // the flag is applied only while the setting is on.
        if (AppSettings.screenshotProtection(this)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
        enableEdgeToEdge()
        setContent {
            GeckoTheme {
                GeckoApp()
            }
        }
    }
}
