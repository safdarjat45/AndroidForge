package com.safdowser.gecko.ui

import android.app.Activity
import android.view.WindowManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.safdowser.gecko.browser.AppSettings
import com.safdowser.gecko.browser.SearchEngine

/**
 * Settings (new in v0.2.2 — v0.2.1 had none, and its always-on screenshot
 * block could not be turned off). Everything here takes effect
 * immediately and is remembered between launches.
 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onClearData: () -> Unit
) {
    val context = LocalContext.current
    var screenshotProtection by remember {
        mutableStateOf(AppSettings.screenshotProtection(context))
    }
    var searchEngine by remember { mutableStateOf(AppSettings.searchEngine) }
    var clearStatus by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text("Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            item {
                Text(
                    "Privacy",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Screenshot protection", fontWeight = FontWeight.Bold)
                        Text(
                            "On: Harrier stays out of screenshots, screen recordings " +
                                "and the Recents preview. Off: you can take screenshots " +
                                "of pages (for example, to share what you see).",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Switch(
                        checked = screenshotProtection,
                        onCheckedChange = { enabled ->
                            screenshotProtection = enabled
                            AppSettings.setScreenshotProtection(context, enabled)
                            val window = (context as? Activity)?.window
                            if (enabled) {
                                window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                            } else {
                                window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                            }
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    "Search engine",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    "Used when you type words instead of an address.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            items(SearchEngine.values().size) { index ->
                val engine = SearchEngine.values()[index]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            searchEngine = engine
                            AppSettings.setSearchEngine(context, engine)
                        }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = searchEngine == engine,
                        onClick = {
                            searchEngine = engine
                            AppSettings.setSearchEngine(context, engine)
                        }
                    )
                    Text(engine.label, style = MaterialTheme.typography.bodyLarge)
                }
            }

            item {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    "Browsing data",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    "Deletes cookies, site data, caches and saved logins for " +
                        "every site, in every tab.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    onClearData()
                    clearStatus = "Browsing data cleared."
                }) {
                    Text("Clear browsing data")
                }
                clearStatus?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "Harrier 0.2.3 · Firefox engine (GeckoView)",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
