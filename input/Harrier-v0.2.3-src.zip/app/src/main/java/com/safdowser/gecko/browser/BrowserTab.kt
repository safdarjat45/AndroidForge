package com.safdowser.gecko.browser

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.WebRequestError
import org.mozilla.geckoview.GeckoResult
import java.net.URLEncoder

/**
 * One browser tab = one GeckoSession on the shared GeckoRuntime.
 *
 * URL tracking deliberately uses ProgressDelegate.onPageStart (stable
 * 2-arg signature) instead of NavigationDelegate.onLocationChange, whose
 * 4-arg form differs between GeckoView releases.
 *
 * All session calls here must run on the UI thread (GeckoSession.open and
 * the delegate setters are @UiThread); tabs are always created from
 * Compose UI callbacks, so that holds.
 */
class BrowserTab(
    val id: Long,
    private val runtime: GeckoRuntime
) {
    val session: GeckoSession = GeckoSession()

    var title by mutableStateOf("New tab")
        private set
    var url by mutableStateOf("")
        private set
    var progress by mutableIntStateOf(0)
        private set
    var loading by mutableStateOf(false)
        private set
    var canGoBack by mutableStateOf(false)
        private set
    var canGoForward by mutableStateOf(false)
        private set

    init {
        session.setNavigationDelegate(object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                this@BrowserTab.canGoBack = canGoBack
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                this@BrowserTab.canGoForward = canGoForward
            }

            override fun onLoadError(
                session: GeckoSession,
                uri: String?,
                error: WebRequestError
            ): GeckoResult<String>? {
                // Null = show Gecko's built-in error page.
                return null
            }
        })
        session.setProgressDelegate(object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                this@BrowserTab.url = url
                loading = true
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                loading = false
                progress = 100
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                this@BrowserTab.progress = progress
            }
        })
        session.setContentDelegate(object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                if (!title.isNullOrBlank()) this@BrowserTab.title = title
            }
        })
        // No PermissionDelegate is set on purpose: with no delegate, content
        // permission requests (including geolocation) are denied by default,
        // so the real location is never handed to a site in v0.1.
        // No session PromptDelegate is set either: JS alert()/confirm() calls
        // are auto-dismissed (known v0.1 limitation, see STATE.md).
        session.open(runtime)
    }

    fun loadStartPage() {
        title = "Harrier"
        url = ""
        session.load(GeckoSession.Loader().data(StartPage.HTML, "text/html"))
    }

    fun load(input: String) {
        session.loadUri(normalizeInput(input))
    }

    fun goBack() = session.goBack()
    fun goForward() = session.goForward()
    fun reload() = session.reload()

    fun close() {
        runCatching { session.close() }
    }

    companion object {
        /**
         * Bare words become a search on the engine chosen in Settings
         * (Startpage by default — no sign-in wall; changeable in Settings);
         * anything that looks like a host becomes https://host.
         */
        fun normalizeInput(input: String): String {
            val engine = AppSettings.searchEngine
            val text = input.trim()
            if (text.isEmpty()) return engine.home
            if (text.startsWith("http://") || text.startsWith("https://") ||
                text.startsWith("about:") || text.startsWith("resource://")
            ) return text
            val looksLikeHost = !text.contains(" ") && text.contains(".") &&
                text.substringAfterLast(".").length in 2..6 &&
                text.all { it.isLetterOrDigit() || it in ".-" }
            return if (looksLikeHost) "https://$text"
            else engine.template + URLEncoder.encode(text, "UTF-8")
        }
    }
}

class BrowserTabManager(private val runtime: GeckoRuntime) {

    private var nextId = 1L

    val tabs: SnapshotStateList<BrowserTab> = mutableStateListOf()

    var activeTabId by mutableStateOf<Long?>(null)
        private set

    val activeTab: BrowserTab?
        get() = tabs.firstOrNull { it.id == activeTabId }

    /** Creates a tab and returns its session (used by extension TabDelegate). */
    fun newTab(url: String? = null): BrowserTab {
        val tab = BrowserTab(nextId++, runtime)
        tabs.add(tab)
        activeTabId = tab.id
        if (url.isNullOrBlank()) tab.loadStartPage() else tab.load(url)
        return tab
    }

    fun selectTab(id: Long) {
        if (tabs.any { it.id == id }) activeTabId = id
    }

    fun closeTab(tab: BrowserTab) {
        val index = tabs.indexOf(tab)
        if (index < 0) return
        tabs.removeAt(index)
        tab.close()
        if (activeTabId == tab.id) {
            activeTabId = when {
                tabs.isEmpty() -> null
                index < tabs.size -> tabs[index].id
                else -> tabs.last().id
            }
        }
        if (tabs.isEmpty()) newTab()
    }
}
