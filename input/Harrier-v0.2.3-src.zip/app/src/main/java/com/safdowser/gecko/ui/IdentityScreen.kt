package com.safdowser.gecko.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.safdowser.gecko.browser.BrowserTab
import com.safdowser.gecko.vpn.OpenVpnController
import java.util.Locale
import java.util.TimeZone

/**
 * Identity page: shows what websites see right now — exit IP, user agent,
 * locale, timezone, WebRTC and DNS posture. Honest about the engine's
 * limits: timezone and GPS are NOT spoofed (no supported GeckoView API),
 * so the page shows the real device timezone and says so.
 *
 * v0.2.2 hardening (v0.2.1 field report: this page rendered blank black):
 * nothing outside plain local state is touched during composition — the
 * VPN state, exit IP and user agent are fetched in effects wrapped in
 * runCatching, and every failure lands as visible text in its row instead
 * of taking the whole screen down.
 */
@Composable
fun IdentityScreen(
    tab: BrowserTab?,
    onBack: () -> Unit
) {
    var exitIp by remember { mutableStateOf("Checking…") }
    var userAgent by remember { mutableStateOf("Checking…") }
    var vpnState by remember { mutableStateOf("Checking…") }
    var refreshTick by remember { mutableStateOf(0) }

    LaunchedEffect(refreshTick) {
        exitIp = "Checking…"
        exitIp = runCatching { OpenVpnController.fetchExitIp() }.fold(
            onSuccess = { it ?: "Could not be measured (no connection?)" },
            onFailure = { "Could not be measured: ${it.message}" }
        )
    }

    LaunchedEffect(refreshTick) {
        runCatching {
            OpenVpnController.state.collect { vpnState = it.name }
        }
    }

    LaunchedEffect(tab?.id, refreshTick) {
        userAgent = "Checking…"
        val session = tab?.session
        if (session == null) {
            userAgent = "No tab open"
        } else {
            runCatching {
                session.getUserAgent().accept(
                    { ua -> userAgent = ua ?: "User agent unavailable" },
                    { userAgent = "User agent unavailable" }
                )
            }.onFailure { userAgent = "User agent unavailable: ${it.message}" }
        }
    }

    val rows = listOf(
        "Exit IP (what websites see)" to exitIp,
        "VPN tunnel" to vpnState,
        "User agent" to userAgent,
        "Locale (Accept-Language)" to Locale.getDefault().toLanguageTag(),
        "Timezone (JavaScript)" to (TimeZone.getDefault().id + " — your REAL device timezone; the Firefox engine offers no supported way to spoof it"),
        "GPS / location" to "No fake GPS — location requests are always denied, so your real location never reaches a website",
        "WebRTC" to "Disabled in the engine configuration — it cannot leak your real IP address",
        "DNS (DoH)" to "Off by choice — the system resolver is used, which stays inside the VPN tunnel",
        "Fingerprinting protection (FPP)" to "On — known fingerprinting scripts are blocked (this is not full resistFingerprinting)",
        "Tracking protection" to "Strict — trackers, cryptominers and fingerprinting categories are blocked"
    )

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                "Identity",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { refreshTick++ }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Refresh")
            }
        }
        Text(
            "What websites see when this browser visits them:",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            items(rows) { (label, value) ->
                Column(modifier = Modifier.padding(vertical = 8.dp)) {
                    Text(
                        label,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        value,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }
    }
}
